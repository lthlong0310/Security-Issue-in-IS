------->Login sec_admin voi service name la PDB
/*--------------------------------------------------------------PHUONG--------------------------------------------------------------*/
--Tao view cho giao vu va sinh vien xem danh sach dang ky mon hoc
create or replace view dangky as
select d.mssv, d.malop, d.mamonhoc, d.hocky, d.namhoc
from sec_admin.diem d 
where d.diemgiuaky is null and d.diemcuoiky is null and d.diemkhac is null and d.diemtong is null;

--user sec grant select, insert, delete with grant option cho user gvu
grant select, insert, delete on sec_admin.dangky to gvu_ntmthu with grant option;
/
--user gvu grant select cho svien khi mo dang ky
--grant select on sec_admin.monhocduocmo to svien
--cai nay lam tren giao dien

--user gvu revoke select cua svien khi dong dang ky
--revoke select on sec_admin.monhocduocmo from svien
--cai nay lam tren giao dien

--Tao chinh sach sinh vien chi duoc xem, them, xoa cac dang ky cua chinh minh 
create or replace function thaotac_dangky (p_schema varchar2, p_obj varchar2)
return  varchar2
as utype varchar2(32);
begin
    select usertype into utype from sec_admin.taikhoan where upper(username) = user;
    if (utype = 'svien')
        then return 'upper(mssv) = user';
    elsif(utype = 'gvu')
        then return '1 != 0';
    else return '1 = 0';
    end if;
end;
/

BEGIN 
DBMS_RLS.add_policy 
(object_schema => 'sec_admin',
object_name => 'dangky',
policy_name => 'vpd_thaotac_dangky',
policy_function => 'thaotac_dangky',
statement_types => 'select, insert, delete',
update_check => true);
END;
/

/*

BEGIN 
DBMS_RLS.drop_policy 
(object_schema => 'sec_admin',
object_name => 'dangky',
policy_name => 'vpd_thaotac_dangky');
END;
/
*/
--Tao view cho giao vu va sinh vien xem danh sach cac mon hoc duoc mo
create or replace view monhocduocmo as
select tkb.malop, tkb.mamonhoc, mh.tenmonhoc, tkb.hocky, tkb.namhoc, tkb.phonghoc, gv.hoten_giaovien, mh.sotinchi, tkb.sosinhvientoida, count(d.mssv) as sosvhientai
from sec_admin.thoikhoabieu tkb join sec_admin.monhoc mh on mh.mamonhoc= tkb.mamonhoc join giaovien gv on tkb.giaoviengiangday = gv.magiaovien
                        left join sec_admin.diem d on (tkb.malop = d.malop and tkb.mamonhoc = d.mamonhoc and tkb.hocky = d.hocky and tkb.namhoc = d.namhoc)
group by tkb.malop, tkb.mamonhoc, mh.tenmonhoc, tkb.hocky, tkb.namhoc, tkb.phonghoc, gv.hoten_giaovien, mh.sotinchi, tkb.sosinhvientoida
order by tkb.malop, tkb.mamonhoc, tkb.hocky, tkb.namhoc asc;


grant select, insert, delete, update(phonghoc, giaoviengiangday, sosinhvientoida) on sec_admin.thoikhoabieu to gvu;
/
--user sec grant select with grant option cho user gvu
grant select on sec_admin.monhocduocmo to gvu_ntmthu with grant option;







--user gvu grant select, insert, update tren dangky cho svien khi mo dang ky
--grant select, insert, delete on sec_admin.dangky to svien;
--cai nay lam tren giao dien

--user gvu revoke select, insert, update tren dangky cua svien khi dong dang ky
--revoke select, insert, delete on sec_admin.dangky from svien;
--cai nay lam tren giao dien





/*--------------------------------------------------------------LONG--------------------------------------------------------------*/
/*giao vu, giaovien co the xem va chinh sua cac thong tin lien quan den minh (ngoai tru magiaovien, mabomon, truongkhoa, loaigiaovien)*/
grant select on sec_admin.giaovien to gvu;
grant update on sec_admin.giaovien to gvu;
grant select on sec_admin.giaovien to gvien;
grant update on sec_admin.giaovien to gvien;
--Store procedure CapNhatThongTin_GiaoVien
create or replace procedure sp_CapNhatThongTin_GiaoVien(magv in varchar2, hoten in nvarchar2, diachi in nvarchar2, gioitinh in nchar, cmnd in varchar2, sdt in char, email in varchar2)
is
begin
    update sec_admin.giaovien
    set HoTen_GiaoVien = hoten, diachi_GV = diachi, GioiTinh_GV = gioitinh, cmnd_GV = cmnd, sdt_GV = sdt, email_GV = email
    where magiaovien =  magv;
    commit;
end;
/
grant EXECUTE  on sec_admin.sp_CapNhatThongTin_GiaoVien to gvu;
grant EXECUTE  on sec_admin.sp_CapNhatThongTin_GiaoVien to gvien;
/*Test
EXECUTE sec_admin.sp_CapNhatThongTin_GiaoVien('gvu_ntmthu', 'Khang', '161 Nguyen Hue', 'Nu', '366220163', '09123456', 'khang@gmail.com');


*/

alter session set "_ORACLE_SCRIPT"=true;
/*--------------------------------------------------------------OLS--------------------------------------------------------------*/
--Sau do Login sys nhung nho chuyen sang service name la pdb
/*Mo khoa user lbacsys*/
ALTER USER lbacsys IDENTIFIED BY lbacsys ACCOUNT UNLOCK; 
-- QUOTAS
ALTER USER "LBACSYS" QUOTA UNLIMITED ON "SYSTEM";

--Check if OLS is enabled from sqlplus:
SELECT VALUE FROM V$OPTION WHERE PARAMETER = 'Oracle Label Security';

--Check if OLS is configured
select name, status, description from dba_ols_status;

--Log into the database instance as user SYS 
--If OLS is not yet configured, run the following procedure to configure OLS:
EXEC LBACSYS.CONFIGURE_OLS;
--Run the following procedure to enable OLS:
EXEC LBACSYS.OLS_ENFORCEMENT.ENABLE_OLS;

--->>>Login sys voi pluggable : pdb

/*user sec_mgr tao chinh sach*/

--->>>Login sec_admin

create table ThongBao
(
    TinNhan varchar2(4000)
);
insert into ThongBao values('Thong bao den truong khoa');
insert into ThongBao values('Thong bao den trgbm_khmt');
insert into ThongBao values('Thong bao den trgbm_httt');
insert into ThongBao values('Thong bao den trgbm_ktpm');
insert into ThongBao values('Thong bao den tat ca giao vien');
insert into ThongBao values('Thong bao den gvhttt');
insert into ThongBao values('Thong bao den gvktpm');
insert into ThongBao values('Thong bao den gvkhmt');
insert into ThongBao values('Thong bao den tat ca sinh vien');
select * from thongbao;
grant select on sec_admin.thongbao to svien, gvien, trgbm, trgkhoa;
  

--->>>Login lbacsys/lbacsys 
---1). Tao chinh sach OLS
begin
sa_sysdba.create_policy(policy_name => 'XemThongBao', column_name => 'rowlabel', default_options => 'no_control');
end;
/
/*Cap role XemThongBao_dba cho sec_admin*/
grant XemThongBao_dba to sec_admin;
/*Cap quyen tao cac thanh phan label*/
 GRANT EXECUTE ON sa_components TO sec_admin; 
/*Cap quyen tao cac label*/
 GRANT EXECUTE ON sa_label_admin TO sec_admin;
/*Cap quyen gan label cho user*/
GRANT EXECUTE ON sa_user_admin TO sec_admin;
/*Quyen chuyen ky tu cua label sang dang so*/
GRANT EXECUTE ON char_to_label TO sec_admin;        
---2.1) Dinh nghia cac thanh phan cua nhan
--->>>Login vao sec_admin
/*Truong khoa*/
begin
sa_components.create_level
(policy_name => 'XemThongBao',
long_name => 'TruongKhoa',
short_name => 'trgkhoa',
level_num => 5000);
end;
/
/*Truong bo mon*/
begin
sa_components.create_level
(policy_name => 'XemThongBao',
long_name => 'Truongbomon',
short_name => 'trgbm',
level_num => 4000);
end;
/
/*Giao vien*/
begin
sa_components.create_level
(policy_name => 'XemThongBao',
long_name => 'Giaovien',
short_name => 'gv',
level_num => 3000);
end;
/
/*Sinh vien*/
begin
sa_components.create_level
(policy_name => 'XemThongBao',
long_name => 'Sinhvien',
short_name => 'sv',
level_num => 1000);
end;
/
---2.2) Dinh nghia cac comparment

BEGIN     
sa_components.create_compartment 
(policy_name   => 'XemThongBao', 
long_name      =>'HeThongThongTin', 
short_name     => 'httt', 
comp_num       => 500); 
END; 
/

BEGIN     
sa_components.create_compartment 
(policy_name   => 'XemThongBao', 
long_name      =>'KyThuatPhanMem', 
short_name     => 'ktpm', 
comp_num       => 400); 
END; 
/

BEGIN     
sa_components.create_compartment 
(policy_name   => 'XemThongBao', 
long_name      =>'KhoaHocMayTinh', 
short_name     => 'khmt', 
comp_num       => 300); 
END; 
/

---3.1) Dinh nghia cac nhan

begin
sa_label_admin.create_label (policy_name => 'XemThongBao', label_tag => 5000, label_value => 'trgkhoa');
end;
/


begin
sa_label_admin.create_label (policy_name => 'XemThongBao', label_tag => 4500, label_value => 'trgbm:httt');
end;
/
begin
sa_label_admin.create_label (policy_name => 'XemThongBao', label_tag => 4400, label_value => 'trgbm:ktpm');
end;
/
begin
sa_label_admin.create_label (policy_name => 'XemThongBao', label_tag => 4300, label_value => 'trgbm:khmt');
end;
/

begin
sa_label_admin.create_label (policy_name => 'XemThongBao', label_tag => 2000, label_value => 'gv');
end;
/

begin
sa_label_admin.create_label (policy_name => 'XemThongBao', label_tag => 1500, label_value => 'gv:httt');
end;
/
begin
sa_label_admin.create_label (policy_name => 'XemThongBao', label_tag => 1400, label_value => 'gv:ktpm');
end;
/
begin
sa_label_admin.create_label (policy_name => 'XemThongBao', label_tag => 1300, label_value => 'gv:khmt');
end;
/
begin
sa_label_admin.create_label (policy_name => 'XemThongBao', label_tag => 100, label_value => 'sv');
end;
/
---4.1) Ap dung chinh sach
begin
sa_policy_admin.apply_table_policy 
(policy_name => 'XemThongBao',
schema_name => 'sec_admin', 
table_name => 'ThongBao', 
table_options => 'NO_CONTROL');
end;
/

grant select on sec_admin.ThongBao to svien, gvien, trgbm, trgkhoa;
---Gan nhan cho du lieu va nguoi dung

---Set all records to lowest level
/*Sinh vien*/
select * from thongbao;

update ThongBao
set rowlabel = char_to_label('XemThongBao','sv')
where upper(TinNhan) like '%SINH VIEN%';

---Increase level for Giaovien khmt records

update ThongBao
set rowlabel = char_to_label('XemThongBao','gv:khmt')
where upper(TinNhan) like '%GVKHMT%';
/

---Increase level for Giaovien ktpm records

update ThongBao
set rowlabel = char_to_label('XemThongBao','gv:ktpm')
where upper(TinNhan) like '%GVKTPM%';
/
---Increase level for Giaovien httt records

update ThongBao
set rowlabel = char_to_label('XemThongBao','gv:httt')
where upper(TinNhan) like '%GVHTTT%';
/
---Increase level for Giaovien records

update ThongBao
set rowlabel = char_to_label('XemThongBao','gv')
where upper(TinNhan) like '%GIAO VIEN%';
/

---Increase level for Truong bo mon KHMT records
update ThongBao
set rowlabel = char_to_label('XemThongBao','trgbm:khmt')
where upper(TinNhan) like '%TRGBM_KHMT%';
/

---Increase level for Truong bo mon ktpm records
update ThongBao
set rowlabel = char_to_label('XemThongBao','trgbm:ktpm')
where upper(TinNhan) like '%TRGBM_KTPM%';
/

---Increase level for Truong bo mon httt records
update ThongBao
set rowlabel = char_to_label('XemThongBao','trgbm:httt')
where upper(TinNhan) like '%TRGBM_HTTT%';
/

---Increase level for Truong khoa records
update ThongBao
set rowlabel = char_to_label('XemThongBao','trgkhoa')
where upper(TinNhan) like '%TRUONG KHOA%';
/

---B5.1) Gan nhan cho nguoi dung
/*---------------------------------------------------------User Sinh vien-----------------------------------------------------*/
begin
sa_user_admin.set_user_labels (policy_name => 'XemThongBao', user_name => 'sv3', max_read_label => 'sv');
end;
/
/*---------------------------------------------------------User Giao vien-----------------------------------------------------*/

begin
sa_user_admin.set_user_labels (policy_name => 'XemThongBao', user_name => 'gvktpm_lbluan', max_read_label => 'gv:ktpm');
end;
/
/*
begin
sa_user_admin.set_user_labels (policy_name => 'XemThongBao', user_name => 'gvkhmt_ltlinh', max_read_label => 'gv:khmt');
end;
/

begin
sa_user_admin.set_user_labels (policy_name => 'XemThongBao', user_name => 'gvhttt_nahoang', max_read_label => 'gv:httt');
end;
/
*/
/*---------------------------------------------------------User tat ca gv-----------------------------------------------------*/
/*
begin
sa_user_admin.set_user_labels (policy_name => 'XemThongBao', user_name => 'gvktpm_lbluan', max_read_label => 'gv');
end;
/

begin
sa_user_admin.set_user_labels (policy_name => 'XemThongBao', user_name => 'gvhttt_nahoang', max_read_label => 'gv');
end;
/


begin
sa_user_admin.set_user_labels (policy_name => 'XemThongBao', user_name => 'gvkhmt_ltlinh', max_read_label => 'gv');
end;
/
*/
/*---------------------------------------------------------User tat ca trgbm-----------------------------------------------------*/


begin
sa_user_admin.set_user_labels (policy_name => 'XemThongBao', user_name => 'trgbm_ktpm', max_read_label => 'trgbm:ktpm');
end;
/

begin
sa_user_admin.set_user_labels (policy_name => 'XemThongBao', user_name => 'trgbm_khmt', max_read_label => 'trgbm:khmt');
end;
/

begin
sa_user_admin.set_user_labels (policy_name => 'XemThongBao', user_name => 'trgbm_httt', max_read_label => 'trgbm:httt');
end;
/

begin
sa_user_admin.set_user_labels (policy_name => 'XemThongBao', user_name => 'trgkhoa', max_read_label => 'trgkhoa');
end;
/


----Chuyen sang Read_control
begin
sa_policy_admin.remove_table_policy (policy_name => 'XemThongBao', schema_name => 'sec_admin', table_name => 'ThongBao');
end;
/
begin
sa_policy_admin.apply_table_policy (policy_name => 'XemThongBao', schema_name => 'sec_admin', table_name => 'ThongBao', table_options => 'READ_CONTROL');
end;
/


/*Drop policy OLS
begin
  SA_SYSDBA.DROP_POLICY(policy_name => 'XemThongBao', drop_column => true);
end;
/
*/





/*--------------------------------------------------------------QUANG--------------------------------------------------------------*/


/*--------------------------------------------------------------VY--------------------------------------------------------------*/
---Tao view XemThongTinCaNhan cua sinh vien
create or replace view XemThongTinCaNhan as
select * from sec_admin.sinhvien
where upper(mssv) = USER;
/
grant select on sec_admin.sinhvien to svien;
grant select on sec_admin.XemThongTinCaNhan to svien;
----Cap nhat thong tin sinh vien
create or replace procedure sp_CapNhatThongTin_SinhVien(mssvien in varchar2, hoten in nvarchar2, diachi in nvarchar2, gioitinh in nchar, cmnd in varchar2, sdt in char, email in varchar2)
is
begin
    update sec_admin.sinhvien
    set hoten_sinhvien = hoten, diachi_SV = diachi, GioiTinh_SV = gioitinh, cmnd_SV = cmnd, sdt_SV = sdt, email_SV = email
    where MSSV =  mssvien;
    commit;
end;
/
grant update on sec_admin.sinhvien to svien;
grant EXECUTE  on sec_admin.sp_CapNhatThongTin_SinhVien to svien;
grant select on sec_admin.diem to svien;
grant select on sec_admin.monhoc to svien;
/*Test
EXECUTE  sec_admin.sp_CapNhatThongTin_SinhVien('sv1', 'Ly Thanh', '161 Nguyen Hue', 'Nam', '366220164', '09123456', 'ltl@gmail.com');
*/
create or replace function Access_Diem
(
p_schema in varchar2 default null,
p_object in varchar2 default null
)
return varchar2
as
utype varchar2(32);
begin
    select usertype into utype from sec_admin.taikhoan where upper(username) = user;
    if (utype = 'svien')
        then return 'upper(mssv) = user';
    elsif(utype = 'gvu')
        then return '1 != 0';
    else
        return '1 = 0';
    end if;
end;
/

begin
dbms_rls.add_policy(
object_schema => 'sec_admin',
object_name   => 'diem',
policy_name   => 'VPD_Access_Diem',
policy_function => 'Access_Diem',
statement_types => 'select');
end;
/

--- drop policy
begin
    DBMS_RLS.Drop_Policy(
    object_schema => 'sec_admin',
    object_name   => 'diem',
    policy_name   => 'VPD_Access_Diem');
end;

create or replace view DiemSinhVien as
select mh.mamonhoc, mh.tenmonhoc, d.hocky, d.diemgiuaky, d.diemcuoiky, d.diemkhac, d.diemtong
from sec_admin.diem d join sec_admin.monhoc mh on d.mamonhoc = mh.mamonhoc;
grant select on sec_admin.DiemSinhVien to svien;

select * from diem;
/*--------------------------------------------------------------PHUNG--------------------------------------------------------------*/
--Demo duoi DB ko len giao dien
CREATE OR REPLACE EDITIONABLE PACKAGE NV_ENCRYPT IS
  FUNCTION ENCRYPT_(inputData IN VARCHAR2) RETURN RAW DETERMINISTIC;
  FUNCTION DECRYPT_(inputEncryptData IN RAW) RETURN VARCHAR2 DETERMINISTIC;
END;
/
  CREATE OR REPLACE EDITIONABLE PACKAGE BODY NV_ENCRYPT IS 
    encrypt_Type PLS_INTEGER :=DBMS_CRYPTO.ENCRYPT_DES
							+DBMS_CRYPTO.CHAIN_CBC
							+DBMS_CRYPTO.PAD_PKCS5;
    Mykey VARCHAR2(100) := 'AHIHIHIHI';
  FUNCTION ENCRYPT_(inputData IN VARCHAR2) RETURN RAW DETERMINISTIC
  IS
  	encrypted_raw raw(1000);
    
  BEGIN
       encrypted_raw := dbms_crypto.encrypt(
          src => utl_raw.cast_to_raw(inputData),
          typ => encrypt_Type,
          key => utl_raw.cast_to_raw(Mykey)
      );
      return encrypted_raw;
  END ENCRYPT_;

  FUNCTION DECRYPT_(inputEncryptData IN RAW) RETURN VARCHAR2 DETERMINISTIC
  IS
    decrypted_raw raw(1000);
  BEGIN
       decrypted_raw := dbms_crypto.decrypt(
          src => inputEncryptData,
          typ => encrypt_Type,
          key => utl_raw.cast_to_raw(Mykey)
      );
      return  utl_raw.cast_to_VARCHAR2(decrypted_raw);
  END DECRYPT_;

END NV_Encrypt;
/


--testing
BEGIN 
    FOR STT IN(SELECT COUNT(MAGIAOVIEN)FROM GIAOVIEN)
    LOOP
        UPDATE GIAOVIEN SET EMAIL_GV = NV_ENCRYPT.ENCRYPT_(EMAIL_GV);
    END LOOP;
END;
--TEST DATA ENCRYPTED
SELECT * FROM GIAOVIEN;

SELECT MAGIAOVIEN, NV_ENCRYPT.DECRYPT_(EMAIL_GV) as EMAIL_GV FROM GIAOVIEN;

--DROP TABLE SINHVIEN;
--/
--CREATE TABLE SINHVIEN(
--    MSSV NUMBER(*,0),
--    HOTENSINHVIEN VARCHAR2(100),
--    DTB NUMBER(*,0)
--);
--/
--INSERT INTO SINHVIEN(MSSV, HOTENSINHVIEN, DTB) VALUES(1, 'NGUYEN A', 10);
--INSERT INTO SINHVIEN(MSSV, HOTENSINHVIEN, DTB) VALUES(2, 'NGUYEN B', 9);
--INSERT INTO SINHVIEN(MSSV, HOTENSINHVIEN, DTB) VALUES(3, 'NGUYEN C', 8);
--INSERT INTO SINHVIEN(MSSV, HOTENSINHVIEN, DTB) VALUES(4, 'NGUYEN D', 7);
--INSERT INTO SINHVIEN(MSSV, HOTENSINHVIEN, DTB) VALUES(5, 'NGUYEN E', 6);
--/