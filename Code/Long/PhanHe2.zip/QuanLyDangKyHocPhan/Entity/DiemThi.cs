﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class DiemThi
    {
        public DiemThi() { }
        public DiemThi(string mmh, string tmh, string hk, string dgk, string dck, string dk, string dt)
        {
            MaMonHoc = mmh;
            TenMonHoc = tmh;
            HocKy = hk;
            DiemGiuaKy = dgk;
            DiemCuoiKy = dck;
            DiemKhac = dk;
            DiemTong = dt;
        }
        public string MaMonHoc { get; set; }
        public string TenMonHoc { get; set; }
        public string HocKy { get; set; }
        public string DiemGiuaKy { get; set; }
        public string DiemCuoiKy { get; set; }
        public string DiemKhac { get; set; }
        public string DiemTong { get; set; }
    }
}
