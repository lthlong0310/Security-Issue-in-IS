﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class ThongBao
    {
        public string tinnhan { get; set; }
        public ThongBao() { }
        public ThongBao(string tn)
        {
            tinnhan = tn;
        }
       
    }
}
