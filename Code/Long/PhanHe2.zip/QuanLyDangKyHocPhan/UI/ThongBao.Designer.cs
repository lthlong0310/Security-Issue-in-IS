﻿namespace UI
{
    partial class ThongBao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.titlelb = new System.Windows.Forms.Label();
            this.listView_TinNhan = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // titlelb
            // 
            this.titlelb.AutoSize = true;
            this.titlelb.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titlelb.Location = new System.Drawing.Point(141, 22);
            this.titlelb.Name = "titlelb";
            this.titlelb.Size = new System.Drawing.Size(180, 39);
            this.titlelb.TabIndex = 1;
            this.titlelb.Text = "Thông báo";
            this.titlelb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // listView_TinNhan
            // 
            this.listView_TinNhan.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1});
            this.listView_TinNhan.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView_TinNhan.HideSelection = false;
            this.listView_TinNhan.Location = new System.Drawing.Point(31, 82);
            this.listView_TinNhan.Name = "listView_TinNhan";
            this.listView_TinNhan.Size = new System.Drawing.Size(452, 189);
            this.listView_TinNhan.TabIndex = 2;
            this.listView_TinNhan.UseCompatibleStateImageBehavior = false;
            this.listView_TinNhan.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Tin nhắn";
            this.columnHeader1.Width = 416;
            // 
            // ThongBao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(528, 308);
            this.Controls.Add(this.listView_TinNhan);
            this.Controls.Add(this.titlelb);
            this.Name = "ThongBao";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ThongBao";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titlelb;
        private System.Windows.Forms.ListView listView_TinNhan;
        private System.Windows.Forms.ColumnHeader columnHeader1;
    }
}