﻿using Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace UI
{
    public partial class ThongBao : Form
    {
        User current_user;

        public ThongBao(User curuser)
        {
            InitializeComponent();
            current_user = curuser;
            LoadThongBao();
        }
        private void LoadThongBao()
        {
            BLL.BLL bll = new BLL.BLL();
            var dsthongbao = bll.Lay_ThongBao(current_user);
            foreach(var tb in dsthongbao)
            {
                String[] thbao = new String[1];
                thbao[0] = tb.tinnhan;
                ListViewItem item = new ListViewItem(thbao);
                this.listView_TinNhan.Items.Add(item);
            }
        }      
    }
}
