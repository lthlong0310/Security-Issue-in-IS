﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity;

namespace UI
{
    public partial class XemKetQuaHocPhanForm : Form
    {
        User current_user;
        clsResize _form_resize;
        public XemKetQuaHocPhanForm(User curuser)
        {
            InitializeComponent();
            current_user = curuser;
            Load_Diem();
            _form_resize = new clsResize(this);
            this.Load += _Load;
            this.Resize += _Resize;
        }

        private void _Load(object sender, EventArgs e)
        {
            _form_resize._get_initial_size();
        }

        private void _Resize(object sender, EventArgs e)
        {
            _form_resize._resize();
        }

        private void Load_Diem()
        {
            BLL.BLL bll = new BLL.BLL();
            var diemthi = bll.Lay_Diem(current_user);
            ListDiem_To_ListView(listView_Diem, diemthi);
        }
        private void ListDiem_To_ListView(ListView listView_Diem, List<DiemThi> diemthi)
        {
            listView_Diem.Items.Clear();
            foreach(var diem in diemthi)
            {
                ListViewItem item = new ListViewItem();
                item.Text = diem.MaMonHoc;
                item.SubItems.Add(diem.TenMonHoc);
                item.SubItems.Add(diem.HocKy.ToString());
                item.SubItems.Add(diem.DiemGiuaKy.ToString());
                item.SubItems.Add(diem.DiemCuoiKy.ToString());
                item.SubItems.Add(diem.DiemKhac.ToString());
                item.SubItems.Add(diem.DiemTong.ToString());
                listView_Diem.Items.Add(item);
                item.Tag = diem;
            
            }
        }
        

        private void XemKetQuaHocPhanForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            SinhVienMenuForm svmenu = new SinhVienMenuForm(current_user);
            svmenu.ShowDialog();
            this.Close();
        }
    }
}
