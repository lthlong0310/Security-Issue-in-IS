﻿namespace UI
{
    partial class MoMonHocForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dsmonhoclv = new System.Windows.Forms.ListView();
            this.dsmonhocmodklv = new System.Windows.Forms.ListView();
            this.modangkybttn = new System.Windows.Forms.Button();
            this.huymomondkbttn = new System.Windows.Forms.Button();
            this.dongdkbttn = new System.Windows.Forms.Button();
            this.giaoviencb = new System.Windows.Forms.ComboBox();
            this.lopcb = new System.Windows.Forms.ComboBox();
            this.hockycb = new System.Windows.Forms.ComboBox();
            this.namhoccb = new System.Windows.Forms.ComboBox();
            this.loplb = new System.Windows.Forms.Label();
            this.giaovienlb = new System.Windows.Forms.Label();
            this.namhoclb = new System.Windows.Forms.Label();
            this.hockylb = new System.Windows.Forms.Label();
            this.phongtb = new System.Windows.Forms.TextBox();
            this.phonglb = new System.Windows.Forms.Label();
            this.svtoidalb = new System.Windows.Forms.Label();
            this.svtoidatb = new System.Windows.Forms.TextBox();
            this.momondkbttn = new System.Windows.Forms.Button();
            this.dieuchinhhocphanbttn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // dsmonhoclv
            // 
            this.dsmonhoclv.HideSelection = false;
            this.dsmonhoclv.Location = new System.Drawing.Point(54, 131);
            this.dsmonhoclv.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dsmonhoclv.Name = "dsmonhoclv";
            this.dsmonhoclv.Size = new System.Drawing.Size(320, 283);
            this.dsmonhoclv.TabIndex = 0;
            this.dsmonhoclv.UseCompatibleStateImageBehavior = false;
            this.dsmonhoclv.SelectedIndexChanged += new System.EventHandler(this.dsmonhoclv_SelectedIndexChanged);
            // 
            // dsmonhocmodklv
            // 
            this.dsmonhocmodklv.HideSelection = false;
            this.dsmonhocmodklv.Location = new System.Drawing.Point(455, 131);
            this.dsmonhocmodklv.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dsmonhocmodklv.Name = "dsmonhocmodklv";
            this.dsmonhocmodklv.Size = new System.Drawing.Size(578, 283);
            this.dsmonhocmodklv.TabIndex = 1;
            this.dsmonhocmodklv.UseCompatibleStateImageBehavior = false;
            // 
            // modangkybttn
            // 
            this.modangkybttn.Location = new System.Drawing.Point(54, 438);
            this.modangkybttn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.modangkybttn.Name = "modangkybttn";
            this.modangkybttn.Size = new System.Drawing.Size(144, 34);
            this.modangkybttn.TabIndex = 2;
            this.modangkybttn.Text = "Mở đăng ký";
            this.modangkybttn.UseVisualStyleBackColor = true;
            this.modangkybttn.Click += new System.EventHandler(this.modangkybttn_Click);
            // 
            // huymomondkbttn
            // 
            this.huymomondkbttn.Location = new System.Drawing.Point(863, 438);
            this.huymomondkbttn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.huymomondkbttn.Name = "huymomondkbttn";
            this.huymomondkbttn.Size = new System.Drawing.Size(170, 34);
            this.huymomondkbttn.TabIndex = 3;
            this.huymomondkbttn.Text = "Hủy mở môn đăng ký";
            this.huymomondkbttn.UseVisualStyleBackColor = true;
            this.huymomondkbttn.Click += new System.EventHandler(this.huymomondkbttn_Click);
            // 
            // dongdkbttn
            // 
            this.dongdkbttn.Location = new System.Drawing.Point(455, 438);
            this.dongdkbttn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dongdkbttn.Name = "dongdkbttn";
            this.dongdkbttn.Size = new System.Drawing.Size(150, 34);
            this.dongdkbttn.TabIndex = 4;
            this.dongdkbttn.Text = "Đỏng đăng ký";
            this.dongdkbttn.UseVisualStyleBackColor = true;
            this.dongdkbttn.Click += new System.EventHandler(this.dongdkbttn_Click);
            // 
            // giaoviencb
            // 
            this.giaoviencb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.giaoviencb.FormattingEnabled = true;
            this.giaoviencb.Location = new System.Drawing.Point(408, 32);
            this.giaoviencb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.giaoviencb.Name = "giaoviencb";
            this.giaoviencb.Size = new System.Drawing.Size(311, 24);
            this.giaoviencb.TabIndex = 5;
            // 
            // lopcb
            // 
            this.lopcb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lopcb.FormattingEnabled = true;
            this.lopcb.Location = new System.Drawing.Point(112, 32);
            this.lopcb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lopcb.Name = "lopcb";
            this.lopcb.Size = new System.Drawing.Size(126, 24);
            this.lopcb.TabIndex = 6;
            // 
            // hockycb
            // 
            this.hockycb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.hockycb.FormattingEnabled = true;
            this.hockycb.Location = new System.Drawing.Point(112, 78);
            this.hockycb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.hockycb.Name = "hockycb";
            this.hockycb.Size = new System.Drawing.Size(108, 24);
            this.hockycb.TabIndex = 7;
            this.hockycb.SelectedIndexChanged += new System.EventHandler(this.hockycb_SelectedIndexChanged);
            // 
            // namhoccb
            // 
            this.namhoccb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.namhoccb.FormattingEnabled = true;
            this.namhoccb.Location = new System.Drawing.Point(408, 74);
            this.namhoccb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.namhoccb.Name = "namhoccb";
            this.namhoccb.Size = new System.Drawing.Size(206, 24);
            this.namhoccb.TabIndex = 8;
            this.namhoccb.SelectedIndexChanged += new System.EventHandler(this.namhoccb_SelectedIndexChanged);
            // 
            // loplb
            // 
            this.loplb.AutoSize = true;
            this.loplb.Location = new System.Drawing.Point(51, 34);
            this.loplb.Name = "loplb";
            this.loplb.Size = new System.Drawing.Size(40, 17);
            this.loplb.TabIndex = 9;
            this.loplb.Text = "Lớp: ";
            // 
            // giaovienlb
            // 
            this.giaovienlb.AutoSize = true;
            this.giaovienlb.Location = new System.Drawing.Point(268, 34);
            this.giaovienlb.Name = "giaovienlb";
            this.giaovienlb.Size = new System.Drawing.Size(138, 17);
            this.giaovienlb.TabIndex = 10;
            this.giaovienlb.Text = "Giáo viên giảng dạy:";
            // 
            // namhoclb
            // 
            this.namhoclb.AutoSize = true;
            this.namhoclb.Location = new System.Drawing.Point(269, 81);
            this.namhoclb.Name = "namhoclb";
            this.namhoclb.Size = new System.Drawing.Size(68, 17);
            this.namhoclb.TabIndex = 11;
            this.namhoclb.Text = "Năm học:";
            // 
            // hockylb
            // 
            this.hockylb.AutoSize = true;
            this.hockylb.Location = new System.Drawing.Point(52, 81);
            this.hockylb.Name = "hockylb";
            this.hockylb.Size = new System.Drawing.Size(55, 17);
            this.hockylb.TabIndex = 12;
            this.hockylb.Text = "Học kỳ:";
            // 
            // phongtb
            // 
            this.phongtb.Location = new System.Drawing.Point(892, 32);
            this.phongtb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.phongtb.Name = "phongtb";
            this.phongtb.Size = new System.Drawing.Size(141, 22);
            this.phongtb.TabIndex = 13;
            // 
            // phonglb
            // 
            this.phonglb.AutoSize = true;
            this.phonglb.Location = new System.Drawing.Point(758, 34);
            this.phonglb.Name = "phonglb";
            this.phonglb.Size = new System.Drawing.Size(80, 17);
            this.phonglb.TabIndex = 14;
            this.phonglb.Text = "Phòng học:";
            // 
            // svtoidalb
            // 
            this.svtoidalb.AutoSize = true;
            this.svtoidalb.Location = new System.Drawing.Point(758, 81);
            this.svtoidalb.Name = "svtoidalb";
            this.svtoidalb.Size = new System.Drawing.Size(128, 17);
            this.svtoidalb.TabIndex = 15;
            this.svtoidalb.Text = "Số sinh viên tối đa:";
            // 
            // svtoidatb
            // 
            this.svtoidatb.Location = new System.Drawing.Point(892, 78);
            this.svtoidatb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.svtoidatb.Name = "svtoidatb";
            this.svtoidatb.Size = new System.Drawing.Size(127, 22);
            this.svtoidatb.TabIndex = 16;
            // 
            // momondkbttn
            // 
            this.momondkbttn.Location = new System.Drawing.Point(229, 438);
            this.momondkbttn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.momondkbttn.Name = "momondkbttn";
            this.momondkbttn.Size = new System.Drawing.Size(144, 34);
            this.momondkbttn.TabIndex = 17;
            this.momondkbttn.Text = "Mở môn đăng ký";
            this.momondkbttn.UseVisualStyleBackColor = true;
            this.momondkbttn.Click += new System.EventHandler(this.momondkbttn_Click);
            // 
            // dieuchinhhocphanbttn
            // 
            this.dieuchinhhocphanbttn.Location = new System.Drawing.Point(641, 438);
            this.dieuchinhhocphanbttn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dieuchinhhocphanbttn.Name = "dieuchinhhocphanbttn";
            this.dieuchinhhocphanbttn.Size = new System.Drawing.Size(183, 34);
            this.dieuchinhhocphanbttn.TabIndex = 18;
            this.dieuchinhhocphanbttn.Text = "Điều chỉnh học phần";
            this.dieuchinhhocphanbttn.UseVisualStyleBackColor = true;
            this.dieuchinhhocphanbttn.Click += new System.EventHandler(this.dieuchinhhocphanbttn_Click);
            // 
            // MoMonHocForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1070, 498);
            this.Controls.Add(this.dieuchinhhocphanbttn);
            this.Controls.Add(this.momondkbttn);
            this.Controls.Add(this.svtoidatb);
            this.Controls.Add(this.svtoidalb);
            this.Controls.Add(this.phonglb);
            this.Controls.Add(this.phongtb);
            this.Controls.Add(this.hockylb);
            this.Controls.Add(this.namhoclb);
            this.Controls.Add(this.giaovienlb);
            this.Controls.Add(this.loplb);
            this.Controls.Add(this.namhoccb);
            this.Controls.Add(this.hockycb);
            this.Controls.Add(this.lopcb);
            this.Controls.Add(this.giaoviencb);
            this.Controls.Add(this.dongdkbttn);
            this.Controls.Add(this.huymomondkbttn);
            this.Controls.Add(this.modangkybttn);
            this.Controls.Add(this.dsmonhocmodklv);
            this.Controls.Add(this.dsmonhoclv);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "MoMonHocForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mở học phần";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MoMonHocForm_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView dsmonhoclv;
        private System.Windows.Forms.ListView dsmonhocmodklv;
        private System.Windows.Forms.Button modangkybttn;
        private System.Windows.Forms.Button huymomondkbttn;
        private System.Windows.Forms.Button dongdkbttn;
        private System.Windows.Forms.ComboBox giaoviencb;
        private System.Windows.Forms.ComboBox lopcb;
        private System.Windows.Forms.ComboBox hockycb;
        private System.Windows.Forms.ComboBox namhoccb;
        private System.Windows.Forms.Label loplb;
        private System.Windows.Forms.Label giaovienlb;
        private System.Windows.Forms.Label namhoclb;
        private System.Windows.Forms.Label hockylb;
        private System.Windows.Forms.TextBox phongtb;
        private System.Windows.Forms.Label phonglb;
        private System.Windows.Forms.Label svtoidalb;
        private System.Windows.Forms.TextBox svtoidatb;
        private System.Windows.Forms.Button momondkbttn;
        private System.Windows.Forms.Button dieuchinhhocphanbttn;
    }
}