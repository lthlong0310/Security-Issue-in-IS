﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity;
namespace UI
{
    public partial class ThongTinCaNhan_SV : Form
    {
        private SinhVien sv = null;
        User current_user;
        public ThongTinCaNhan_SV(User curuser)
        {
            current_user = curuser;
            InitializeComponent();
            LoadThongTin_SinhVien();
        }
        private void LoadThongTin_SinhVien()
        {
            BLL.BLL bll = new BLL.BLL();
            var tt = bll.LayTTSinhVien(current_user);
            label_MSSV.Text = tt.mssv;
            textBox_HoTenSV.Text = tt.hotensv;
            textBox_DiaChi_SV.Text = tt.diachisv;
            textBox_GioiTinh.Text = tt.gioitinhsv;
            textBox_CMND.Text = tt.cmndsv;
            textBox_SDT.Text = tt.sdtsv;
            textBox_Email.Text = tt.emailsv;
            NgaySinh.Value = DateTime.Parse(tt.dobsv);
        }

        private void button_CapNhat_Click(object sender, EventArgs e)
        {
            var capnhat_tt = new SinhVien();
            capnhat_tt.mssv = label_MSSV.Text;
            capnhat_tt.hotensv = textBox_HoTenSV.Text;
            capnhat_tt.dobsv = NgaySinh.Value.ToString();
            capnhat_tt.diachisv = textBox_DiaChi_SV.Text;
            capnhat_tt.gioitinhsv = textBox_GioiTinh.Text;
            capnhat_tt.cmndsv = textBox_CMND.Text;
            capnhat_tt.sdtsv = textBox_SDT.Text;
            capnhat_tt.emailsv = textBox_Email.Text;
            var servise = new BLL.BLL();
            sv = servise.CapNhat_TT_SinhVien(current_user, capnhat_tt);
            MessageBox.Show("Cập nhật thành công", "THÔNG BÁO");
        }

        private void ThongTinCaNhan_SV_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            Form f = new SinhVienMenuForm(current_user);
            f.ShowDialog();
            this.Close();
        }
    }
}
