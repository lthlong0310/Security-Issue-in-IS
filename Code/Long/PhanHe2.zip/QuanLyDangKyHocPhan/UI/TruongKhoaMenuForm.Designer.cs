﻿namespace UI
{
    partial class TruongKhoaMenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.logoutbttn = new System.Windows.Forms.Button();
            this.button_XemThongBao = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // logoutbttn
            // 
            this.logoutbttn.Location = new System.Drawing.Point(51, 191);
            this.logoutbttn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.logoutbttn.Name = "logoutbttn";
            this.logoutbttn.Size = new System.Drawing.Size(119, 36);
            this.logoutbttn.TabIndex = 5;
            this.logoutbttn.Text = "Logout";
            this.logoutbttn.UseVisualStyleBackColor = true;
            this.logoutbttn.Click += new System.EventHandler(this.logoutbttn_Click);
            // 
            // button_XemThongBao
            // 
            this.button_XemThongBao.Location = new System.Drawing.Point(29, 115);
            this.button_XemThongBao.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_XemThongBao.Name = "button_XemThongBao";
            this.button_XemThongBao.Size = new System.Drawing.Size(174, 53);
            this.button_XemThongBao.TabIndex = 6;
            this.button_XemThongBao.Text = "Xem thông báo";
            this.button_XemThongBao.UseVisualStyleBackColor = true;
            this.button_XemThongBao.Click += new System.EventHandler(this.button_XemThongBao_Click);
            // 
            // TruongKhoaMenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(232, 262);
            this.Controls.Add(this.button_XemThongBao);
            this.Controls.Add(this.logoutbttn);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "TruongKhoaMenuForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TruongKhoaMenuForm";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button logoutbttn;
        private System.Windows.Forms.Button button_XemThongBao;
    }
}