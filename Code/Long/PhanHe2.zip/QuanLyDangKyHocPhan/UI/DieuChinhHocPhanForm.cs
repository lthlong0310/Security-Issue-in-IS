﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using Entity;

namespace UI
{
    public partial class DieuChinhHocPhanForm : Form
    {
        clsResize _form_resize;
        ThoiKhoaBieu hocphan;
        User current_user;

        public DieuChinhHocPhanForm(User cur_user, ThoiKhoaBieu hp)
        {
            InitializeComponent();

            hocphan = hp;
            current_user = cur_user;
            LoadHocPhan();
            _form_resize = new clsResize(this);
            this.Load += _Load;
            this.Resize += _Resize;
        }

        private void _Load(object sender, EventArgs e)
        {
            _form_resize._get_initial_size();
        }

        private void _Resize(object sender, EventArgs e)
        {
            _form_resize._resize();
        }

        private void LoadHocPhan()
        {
            lopdatalb.Text = hocphan.malop;
            giaoviendatalb.Text = hocphan.giaoviengiangday;
            hockydatalb.Text = hocphan.hocky.ToString();
            namhocdatalb.Text = hocphan.namhoc;
            monhocdatalb.Text = hocphan.tenmonhoc;
            phongtb.Text = hocphan.phonghoc;
            if (hocphan.sosvtoida < 0)
                svtoidatb.Text = "";
            else svtoidatb.Text = hocphan.sosvtoida.ToString();

        }

        private void huybttn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dieuchinhbttn_Click(object sender, EventArgs e)
        {
            hocphan.phonghoc = phongtb.Text;
            try
            {
                hocphan.sosvtoida = Int32.Parse(svtoidatb.Text);
            }
            catch (Exception)
            {
                hocphan.sosvtoida = -1;
            }
            var dieuchinh = new BLL.BLL().DieuChinhHocPhan(current_user, hocphan);

            if (dieuchinh)
            {
                MessageBox.Show("Điều chỉnh học phần thành công");
                this.Close();
            }
            else MessageBox.Show("Điều chỉnh học phần không thành công");
            

        }
    }
}
