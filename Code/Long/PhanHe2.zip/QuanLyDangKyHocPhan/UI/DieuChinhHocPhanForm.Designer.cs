﻿namespace UI
{
    partial class DieuChinhHocPhanForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.svtoidatb = new System.Windows.Forms.TextBox();
            this.svtoidalb = new System.Windows.Forms.Label();
            this.phonglb = new System.Windows.Forms.Label();
            this.phongtb = new System.Windows.Forms.TextBox();
            this.hockylb = new System.Windows.Forms.Label();
            this.namhoclb = new System.Windows.Forms.Label();
            this.giaovienlb = new System.Windows.Forms.Label();
            this.loplb = new System.Windows.Forms.Label();
            this.monhoclb = new System.Windows.Forms.Label();
            this.lopdatalb = new System.Windows.Forms.Label();
            this.hockydatalb = new System.Windows.Forms.Label();
            this.giaoviendatalb = new System.Windows.Forms.Label();
            this.namhocdatalb = new System.Windows.Forms.Label();
            this.monhocdatalb = new System.Windows.Forms.Label();
            this.dieuchinhbttn = new System.Windows.Forms.Button();
            this.huybttn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // svtoidatb
            // 
            this.svtoidatb.Location = new System.Drawing.Point(436, 171);
            this.svtoidatb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.svtoidatb.Name = "svtoidatb";
            this.svtoidatb.Size = new System.Drawing.Size(127, 22);
            this.svtoidatb.TabIndex = 28;
            // 
            // svtoidalb
            // 
            this.svtoidalb.AutoSize = true;
            this.svtoidalb.Location = new System.Drawing.Point(292, 174);
            this.svtoidalb.Name = "svtoidalb";
            this.svtoidalb.Size = new System.Drawing.Size(128, 17);
            this.svtoidalb.TabIndex = 27;
            this.svtoidalb.Text = "Số sinh viên tối đa:";
            // 
            // phonglb
            // 
            this.phonglb.AutoSize = true;
            this.phonglb.Location = new System.Drawing.Point(32, 176);
            this.phonglb.Name = "phonglb";
            this.phonglb.Size = new System.Drawing.Size(80, 17);
            this.phonglb.TabIndex = 26;
            this.phonglb.Text = "Phòng học:";
            // 
            // phongtb
            // 
            this.phongtb.Location = new System.Drawing.Point(118, 171);
            this.phongtb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.phongtb.Name = "phongtb";
            this.phongtb.Size = new System.Drawing.Size(141, 22);
            this.phongtb.TabIndex = 25;
            // 
            // hockylb
            // 
            this.hockylb.AutoSize = true;
            this.hockylb.Location = new System.Drawing.Point(32, 129);
            this.hockylb.Name = "hockylb";
            this.hockylb.Size = new System.Drawing.Size(55, 17);
            this.hockylb.TabIndex = 24;
            this.hockylb.Text = "Học kỳ:";
            // 
            // namhoclb
            // 
            this.namhoclb.AutoSize = true;
            this.namhoclb.Location = new System.Drawing.Point(293, 129);
            this.namhoclb.Name = "namhoclb";
            this.namhoclb.Size = new System.Drawing.Size(68, 17);
            this.namhoclb.TabIndex = 23;
            this.namhoclb.Text = "Năm học:";
            // 
            // giaovienlb
            // 
            this.giaovienlb.AutoSize = true;
            this.giaovienlb.Location = new System.Drawing.Point(293, 49);
            this.giaovienlb.Name = "giaovienlb";
            this.giaovienlb.Size = new System.Drawing.Size(138, 17);
            this.giaovienlb.TabIndex = 22;
            this.giaovienlb.Text = "Giáo viên giảng dạy:";
            // 
            // loplb
            // 
            this.loplb.AutoSize = true;
            this.loplb.Location = new System.Drawing.Point(32, 49);
            this.loplb.Name = "loplb";
            this.loplb.Size = new System.Drawing.Size(40, 17);
            this.loplb.TabIndex = 21;
            this.loplb.Text = "Lớp: ";
            // 
            // monhoclb
            // 
            this.monhoclb.AutoSize = true;
            this.monhoclb.Location = new System.Drawing.Point(32, 92);
            this.monhoclb.Name = "monhoclb";
            this.monhoclb.Size = new System.Drawing.Size(66, 17);
            this.monhoclb.TabIndex = 33;
            this.monhoclb.Text = "Môn học:";
            // 
            // lopdatalb
            // 
            this.lopdatalb.AutoSize = true;
            this.lopdatalb.Location = new System.Drawing.Point(116, 49);
            this.lopdatalb.Name = "lopdatalb";
            this.lopdatalb.Size = new System.Drawing.Size(0, 17);
            this.lopdatalb.TabIndex = 34;
            // 
            // hockydatalb
            // 
            this.hockydatalb.AutoSize = true;
            this.hockydatalb.Location = new System.Drawing.Point(115, 129);
            this.hockydatalb.Name = "hockydatalb";
            this.hockydatalb.Size = new System.Drawing.Size(0, 17);
            this.hockydatalb.TabIndex = 35;
            // 
            // giaoviendatalb
            // 
            this.giaoviendatalb.AutoSize = true;
            this.giaoviendatalb.Location = new System.Drawing.Point(447, 49);
            this.giaoviendatalb.Name = "giaoviendatalb";
            this.giaoviendatalb.Size = new System.Drawing.Size(0, 17);
            this.giaoviendatalb.TabIndex = 36;
            // 
            // namhocdatalb
            // 
            this.namhocdatalb.AutoSize = true;
            this.namhocdatalb.Location = new System.Drawing.Point(446, 129);
            this.namhocdatalb.Name = "namhocdatalb";
            this.namhocdatalb.Size = new System.Drawing.Size(0, 17);
            this.namhocdatalb.TabIndex = 37;
            // 
            // monhocdatalb
            // 
            this.monhocdatalb.AutoSize = true;
            this.monhocdatalb.Location = new System.Drawing.Point(104, 92);
            this.monhocdatalb.Name = "monhocdatalb";
            this.monhocdatalb.Size = new System.Drawing.Size(0, 17);
            this.monhocdatalb.TabIndex = 38;
            // 
            // dieuchinhbttn
            // 
            this.dieuchinhbttn.Location = new System.Drawing.Point(103, 276);
            this.dieuchinhbttn.Name = "dieuchinhbttn";
            this.dieuchinhbttn.Size = new System.Drawing.Size(157, 34);
            this.dieuchinhbttn.TabIndex = 39;
            this.dieuchinhbttn.Text = "Điều chỉnh";
            this.dieuchinhbttn.UseVisualStyleBackColor = true;
            this.dieuchinhbttn.Click += new System.EventHandler(this.dieuchinhbttn_Click);
            // 
            // huybttn
            // 
            this.huybttn.Location = new System.Drawing.Point(356, 276);
            this.huybttn.Name = "huybttn";
            this.huybttn.Size = new System.Drawing.Size(157, 34);
            this.huybttn.TabIndex = 40;
            this.huybttn.Text = "Hủy";
            this.huybttn.UseVisualStyleBackColor = true;
            this.huybttn.Click += new System.EventHandler(this.huybttn_Click);
            // 
            // DieuChinhHocPhanForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(618, 335);
            this.Controls.Add(this.huybttn);
            this.Controls.Add(this.dieuchinhbttn);
            this.Controls.Add(this.monhocdatalb);
            this.Controls.Add(this.namhocdatalb);
            this.Controls.Add(this.giaoviendatalb);
            this.Controls.Add(this.hockydatalb);
            this.Controls.Add(this.lopdatalb);
            this.Controls.Add(this.monhoclb);
            this.Controls.Add(this.svtoidatb);
            this.Controls.Add(this.svtoidalb);
            this.Controls.Add(this.phonglb);
            this.Controls.Add(this.phongtb);
            this.Controls.Add(this.hockylb);
            this.Controls.Add(this.namhoclb);
            this.Controls.Add(this.giaovienlb);
            this.Controls.Add(this.loplb);
            this.Name = "DieuChinhHocPhanForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DieuChinhHocPhanForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox svtoidatb;
        private System.Windows.Forms.Label svtoidalb;
        private System.Windows.Forms.Label phonglb;
        private System.Windows.Forms.TextBox phongtb;
        private System.Windows.Forms.Label hockylb;
        private System.Windows.Forms.Label namhoclb;
        private System.Windows.Forms.Label giaovienlb;
        private System.Windows.Forms.Label loplb;
        private System.Windows.Forms.Label monhoclb;
        private System.Windows.Forms.Label lopdatalb;
        private System.Windows.Forms.Label hockydatalb;
        private System.Windows.Forms.Label giaoviendatalb;
        private System.Windows.Forms.Label namhocdatalb;
        private System.Windows.Forms.Label monhocdatalb;
        private System.Windows.Forms.Button dieuchinhbttn;
        private System.Windows.Forms.Button huybttn;
    }
}