﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity;

namespace UI
{
    public partial class XemDanhSachSinhVienForm : Form
    {
        User current_user;
        clsResize _form_resize;
        public XemDanhSachSinhVienForm(User curuser)
        {
            InitializeComponent();
            current_user = curuser;
            LoadLopCB();
            LoadDSSinhVien();

            _form_resize = new clsResize(this);
            this.Load += _Load;
            this.Resize += _Resize;
        }

        private void _Load(object sender, EventArgs e)
        {
            _form_resize._get_initial_size();
        }

        private void _Resize(object sender, EventArgs e)
        {
            _form_resize._resize();
        }

        private void LoadDSSinhVien()
        {
            this.dssinhvienlv.BeginUpdate();
            this.dssinhvienlv.Clear();

            this.dssinhvienlv.Columns.Add("MSSV", 150);
            this.dssinhvienlv.Columns.Add("Họ tên", 400);
            this.dssinhvienlv.Columns.Add("Lớp", 150);
            //this.dssinhvienlv.Columns.Add("Ngày sinh", 200);
            //this.dssinhvienlv.Columns.Add("Địa chỉ", 300);
            //this.dssinhvienlv.Columns.Add("Giới tính", 150);
            //this.dssinhvienlv.Columns.Add("CMND", 150);
            //this.dssinhvienlv.Columns.Add("Số điện thoại", 150);
            //this.dssinhvienlv.Columns.Add("Email", 150);



            var dssv = new BLL.BLL().LayDSSinhVien(current_user);

            foreach (var sinhvien in dssv)
            {
                String[] sv = new String[3];
                sv[0] = sinhvien.mssv;
                sv[1] = sinhvien.hotensv;
                sv[2] = sinhvien.lopsv;
                //sv[3] = sinhvien.dobsv;
                //sv[4] = sinhvien.diachisv;
                //sv[5] = sinhvien.gioitinhsv;
                //sv[6] = sinhvien.cmndsv;
                //sv[7] = sinhvien.sdtsv;
                //sv[8] = sinhvien.emailsv;
                ListViewItem item = new ListViewItem(sv);
                this.dssinhvienlv.Items.Add(item);
            }

            this.dssinhvienlv.View = View.Details;
            this.dssinhvienlv.FullRowSelect = true;
            this.dssinhvienlv.EndUpdate();
        }

        private void LoadLopCB()
        {
            this.lopcb.BeginUpdate();
            var dslop = new BLL.BLL().LayDSLop(current_user);
            foreach (var lop in dslop)
            {
                this.lopcb.Items.Add(lop.malop);
            }
            this.lopcb.EndUpdate();
        }

        private void lopcb_SelectedIndexChanged(object sender, EventArgs e)
        {
            ReLoadDSSinhVien();
        }

        private void ReLoadDSSinhVien()
        {
            this.dssinhvienlv.BeginUpdate();
            this.dssinhvienlv.Items.Clear();

            //this.dssinhvienlv.Columns.Add("MSSV", 150);
            //this.dssinhvienlv.Columns.Add("Họ tên", 300);
            //this.dssinhvienlv.Columns.Add("Lớp", 150);
            //this.dssinhvienlv.Columns.Add("Ngày sinh", 200);
            //this.dssinhvienlv.Columns.Add("Địa chỉ", 300);
            //this.dssinhvienlv.Columns.Add("Giới tính", 150);
            //this.dssinhvienlv.Columns.Add("CMND", 150);
            //this.dssinhvienlv.Columns.Add("Số điện thoại", 150);
            //this.dssinhvienlv.Columns.Add("Email", 150);

            var dssv = new BLL.BLL().LayDSSinhVien(current_user, lopcb.Text);

            foreach (var sinhvien in dssv)
            {
                String[] sv = new String[3];
                sv[0] = sinhvien.mssv;
                sv[1] = sinhvien.hotensv;
                sv[2] = sinhvien.lopsv;
                //sv[3] = sinhvien.dobsv;
                //sv[4] = sinhvien.diachisv;
                //sv[5] = sinhvien.gioitinhsv;
                //sv[6] = sinhvien.cmndsv;
                //sv[7] = sinhvien.sdtsv;
                //sv[8] = sinhvien.emailsv;

                ListViewItem item = new ListViewItem(sv);
                this.dssinhvienlv.Items.Add(item);
            }

            this.dssinhvienlv.View = View.Details;
            this.dssinhvienlv.FullRowSelect = true;
            this.dssinhvienlv.EndUpdate();
        }
    }
}
