﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity;

namespace UI
{
    public partial class GiaoVuMenuForm : Form
    {
        User current_user;
        public GiaoVuMenuForm(User curuser)
        {
            current_user = curuser;
            InitializeComponent();
        }

       
        private void dssvbttn_Click(object sender, EventArgs e)
        {
            this.Hide();
            XemDanhSachSinhVienForm dssv = new XemDanhSachSinhVienForm(current_user);
            dssv.ShowDialog();
            this.Close();
        }

        private void modkmhbttn_Click(object sender, EventArgs e)
        {
            this.Hide();
            MoMonHocForm momonhoc = new MoMonHocForm(current_user);
            momonhoc.ShowDialog();
            this.Close();
        }

        private void dsdkmhbttn_Click(object sender, EventArgs e)
        {
            this.Hide();
            XemDanhSachDangKyMonHocForm dsdkmh = new XemDanhSachDangKyMonHocForm(current_user);
            dsdkmh.ShowDialog();
            this.Close();
        }

        private void logoutbttn_Click(object sender, EventArgs e)
        {
            current_user.ClearUser();
            this.Hide();
            LoginForm login = new LoginForm();
            login.ShowDialog();
            this.Close();
        }

        private void ttcanhanbttn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form ThongTin = new ThongTinCaNhan_GiaoVu(current_user);
            ThongTin.ShowDialog();
            this.Close();
        }

        private void GiaoVuMenuForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            Form GiaoVu = new GiaoVuMenuForm(current_user);
            GiaoVu.ShowDialog();
            this.Close();
        }
    }
}
