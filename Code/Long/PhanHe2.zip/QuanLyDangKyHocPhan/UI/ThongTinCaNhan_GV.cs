﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity;
using BLL;
namespace UI
{
    public partial class ThongTinCaNhan_GV : Form
    {
        private GiaoVien gv = null;
        User current_user;
        clsResize _form_resize;
        public ThongTinCaNhan_GV(User curuser)
        {
            InitializeComponent();
            current_user = curuser;
            LoadThongTin_GiaoVu();
            _form_resize = new clsResize(this);
            this.Load += _Load;
            this.Resize += _Resize;
        }

        private void _Load(object sender, EventArgs e)
        {
            _form_resize._get_initial_size();
        }

        private void _Resize(object sender, EventArgs e)
        {
            _form_resize._resize();
        }

        private void LoadThongTin_GiaoVu()
        {
            BLL.BLL bll = new BLL.BLL();
            var tt = bll.LayDSGiaoVu_Theo_MaGV(current_user);
            label_MaGV.Text = tt.magv;
            label_MaBoMon.Text = tt.bomon;
            textBox_HoTenGV.Text = tt.tengv;
            textBox_DiaChi_GV.Text = tt.diachigv;
            textBox_GioiTinh.Text = tt.gioitinhgv;
            textBox_CMND.Text = tt.cmndgv;
            textBox_SDT.Text = tt.sdtgv;
            textBox_Email.Text = tt.emailgv;
            NgaySinh.Value = DateTime.Parse(tt.dobgv);
        }
        private void button_CapNhat_Click(object sender, EventArgs e)
        {
            var capnhat_tt = new GiaoVien();
            capnhat_tt.magv = label_MaGV.Text;
            capnhat_tt.tengv = textBox_HoTenGV.Text;
            capnhat_tt.dobgv = NgaySinh.Value.ToString();
            capnhat_tt.diachigv = textBox_DiaChi_GV.Text;
            capnhat_tt.gioitinhgv = textBox_GioiTinh.Text;
            capnhat_tt.cmndgv = textBox_CMND.Text;
            capnhat_tt.sdtgv = textBox_SDT.Text;
            capnhat_tt.emailgv = textBox_Email.Text;
            var servise = new BLL.BLL();
            gv = servise.CapNhat_TT_GiaoVien(current_user, capnhat_tt);
            MessageBox.Show("Cập nhật thành công", "THÔNG BÁO");
        }

        private void ThongTinCaNhan_GV_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            Form GiaoVi = new GiaoVienMenuForm(current_user);
            GiaoVi.ShowDialog();
            this.Close();
        }
    }
}
