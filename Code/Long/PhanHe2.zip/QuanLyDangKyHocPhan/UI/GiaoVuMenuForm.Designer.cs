﻿namespace UI
{
    partial class GiaoVuMenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dssvbttn = new System.Windows.Forms.Button();
            this.modkmhbttn = new System.Windows.Forms.Button();
            this.dsdkmhbttn = new System.Windows.Forms.Button();
            this.ttcanhanbttn = new System.Windows.Forms.Button();
            this.logoutbttn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // dssvbttn
            // 
            this.dssvbttn.Location = new System.Drawing.Point(34, 38);
            this.dssvbttn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dssvbttn.Name = "dssvbttn";
            this.dssvbttn.Size = new System.Drawing.Size(185, 53);
            this.dssvbttn.TabIndex = 0;
            this.dssvbttn.Text = "Xem danh sách sinh viên";
            this.dssvbttn.UseVisualStyleBackColor = true;
            this.dssvbttn.Click += new System.EventHandler(this.dssvbttn_Click);
            // 
            // modkmhbttn
            // 
            this.modkmhbttn.Location = new System.Drawing.Point(34, 125);
            this.modkmhbttn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.modkmhbttn.Name = "modkmhbttn";
            this.modkmhbttn.Size = new System.Drawing.Size(185, 53);
            this.modkmhbttn.TabIndex = 1;
            this.modkmhbttn.Text = "Mở đăng ký môn học";
            this.modkmhbttn.UseVisualStyleBackColor = true;
            this.modkmhbttn.Click += new System.EventHandler(this.modkmhbttn_Click);
            // 
            // dsdkmhbttn
            // 
            this.dsdkmhbttn.Location = new System.Drawing.Point(256, 38);
            this.dsdkmhbttn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dsdkmhbttn.Name = "dsdkmhbttn";
            this.dsdkmhbttn.Size = new System.Drawing.Size(185, 53);
            this.dsdkmhbttn.TabIndex = 2;
            this.dsdkmhbttn.Text = "Xem danh sách đăng ký môn học";
            this.dsdkmhbttn.UseVisualStyleBackColor = true;
            this.dsdkmhbttn.Click += new System.EventHandler(this.dsdkmhbttn_Click);
            // 
            // ttcanhanbttn
            // 
            this.ttcanhanbttn.Location = new System.Drawing.Point(484, 38);
            this.ttcanhanbttn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ttcanhanbttn.Name = "ttcanhanbttn";
            this.ttcanhanbttn.Size = new System.Drawing.Size(185, 53);
            this.ttcanhanbttn.TabIndex = 3;
            this.ttcanhanbttn.Text = "Xem thông tin cá nhân";
            this.ttcanhanbttn.UseVisualStyleBackColor = true;
            this.ttcanhanbttn.Click += new System.EventHandler(this.ttcanhanbttn_Click);
            // 
            // logoutbttn
            // 
            this.logoutbttn.Location = new System.Drawing.Point(289, 202);
            this.logoutbttn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.logoutbttn.Name = "logoutbttn";
            this.logoutbttn.Size = new System.Drawing.Size(119, 36);
            this.logoutbttn.TabIndex = 4;
            this.logoutbttn.Text = "Logout";
            this.logoutbttn.UseVisualStyleBackColor = true;
            this.logoutbttn.Click += new System.EventHandler(this.logoutbttn_Click);
            // 
            // GiaoVuMenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 261);
            this.Controls.Add(this.logoutbttn);
            this.Controls.Add(this.ttcanhanbttn);
            this.Controls.Add(this.dsdkmhbttn);
            this.Controls.Add(this.modkmhbttn);
            this.Controls.Add(this.dssvbttn);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "GiaoVuMenuForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.GiaoVuMenuForm_FormClosing);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button dssvbttn;
        private System.Windows.Forms.Button modkmhbttn;
        private System.Windows.Forms.Button dsdkmhbttn;
        private System.Windows.Forms.Button ttcanhanbttn;
        private System.Windows.Forms.Button logoutbttn;
    }
}