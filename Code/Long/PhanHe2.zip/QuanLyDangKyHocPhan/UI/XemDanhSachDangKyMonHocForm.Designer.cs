﻿namespace UI
{
    partial class XemDanhSachDangKyMonHocForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.monhoccb = new System.Windows.Forms.ComboBox();
            this.lopcb = new System.Windows.Forms.ComboBox();
            this.loplb = new System.Windows.Forms.Label();
            this.monlb = new System.Windows.Forms.Label();
            this.dsdangkylv = new System.Windows.Forms.ListView();
            this.hockylb = new System.Windows.Forms.Label();
            this.namhoclb = new System.Windows.Forms.Label();
            this.namhoccb = new System.Windows.Forms.ComboBox();
            this.hockycb = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // monhoccb
            // 
            this.monhoccb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.monhoccb.FormattingEnabled = true;
            this.monhoccb.Location = new System.Drawing.Point(109, 31);
            this.monhoccb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.monhoccb.Name = "monhoccb";
            this.monhoccb.Size = new System.Drawing.Size(200, 24);
            this.monhoccb.TabIndex = 0;
            this.monhoccb.SelectedIndexChanged += new System.EventHandler(this.monhoccb_SelectedIndexChanged);
            // 
            // lopcb
            // 
            this.lopcb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lopcb.FormattingEnabled = true;
            this.lopcb.Location = new System.Drawing.Point(367, 31);
            this.lopcb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lopcb.Name = "lopcb";
            this.lopcb.Size = new System.Drawing.Size(119, 24);
            this.lopcb.TabIndex = 1;
            this.lopcb.SelectedIndexChanged += new System.EventHandler(this.lopcb_SelectedIndexChanged);
            // 
            // loplb
            // 
            this.loplb.AutoSize = true;
            this.loplb.Location = new System.Drawing.Point(326, 34);
            this.loplb.Name = "loplb";
            this.loplb.Size = new System.Drawing.Size(36, 17);
            this.loplb.TabIndex = 2;
            this.loplb.Text = "Lớp:";
            // 
            // monlb
            // 
            this.monlb.AutoSize = true;
            this.monlb.Location = new System.Drawing.Point(30, 34);
            this.monlb.Name = "monlb";
            this.monlb.Size = new System.Drawing.Size(66, 17);
            this.monlb.TabIndex = 3;
            this.monlb.Text = "Môn học:";
            // 
            // dsdangkylv
            // 
            this.dsdangkylv.HideSelection = false;
            this.dsdangkylv.Location = new System.Drawing.Point(11, 95);
            this.dsdangkylv.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dsdangkylv.Name = "dsdangkylv";
            this.dsdangkylv.Size = new System.Drawing.Size(990, 359);
            this.dsdangkylv.TabIndex = 4;
            this.dsdangkylv.UseCompatibleStateImageBehavior = false;
            // 
            // hockylb
            // 
            this.hockylb.AutoSize = true;
            this.hockylb.Location = new System.Drawing.Point(515, 34);
            this.hockylb.Name = "hockylb";
            this.hockylb.Size = new System.Drawing.Size(55, 17);
            this.hockylb.TabIndex = 16;
            this.hockylb.Text = "Học kỳ:";
            // 
            // namhoclb
            // 
            this.namhoclb.AutoSize = true;
            this.namhoclb.Location = new System.Drawing.Point(704, 34);
            this.namhoclb.Name = "namhoclb";
            this.namhoclb.Size = new System.Drawing.Size(68, 17);
            this.namhoclb.TabIndex = 15;
            this.namhoclb.Text = "Năm học:";
            // 
            // namhoccb
            // 
            this.namhoccb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.namhoccb.FormattingEnabled = true;
            this.namhoccb.Location = new System.Drawing.Point(777, 31);
            this.namhoccb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.namhoccb.Name = "namhoccb";
            this.namhoccb.Size = new System.Drawing.Size(206, 24);
            this.namhoccb.TabIndex = 14;
            this.namhoccb.SelectedIndexChanged += new System.EventHandler(this.namhoccb_SelectedIndexChanged);
            // 
            // hockycb
            // 
            this.hockycb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.hockycb.FormattingEnabled = true;
            this.hockycb.Location = new System.Drawing.Point(574, 31);
            this.hockycb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.hockycb.Name = "hockycb";
            this.hockycb.Size = new System.Drawing.Size(108, 24);
            this.hockycb.TabIndex = 13;
            this.hockycb.SelectedIndexChanged += new System.EventHandler(this.hockycb_SelectedIndexChanged);
            // 
            // XemDanhSachDangKyMonHocForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1011, 481);
            this.Controls.Add(this.hockylb);
            this.Controls.Add(this.namhoclb);
            this.Controls.Add(this.namhoccb);
            this.Controls.Add(this.hockycb);
            this.Controls.Add(this.dsdangkylv);
            this.Controls.Add(this.monlb);
            this.Controls.Add(this.loplb);
            this.Controls.Add(this.lopcb);
            this.Controls.Add(this.monhoccb);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "XemDanhSachDangKyMonHocForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "XemDanhSachDangKyMonHoc";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.XemDanhSachDangKyMonHocForm_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox monhoccb;
        private System.Windows.Forms.ComboBox lopcb;
        private System.Windows.Forms.Label loplb;
        private System.Windows.Forms.Label monlb;
        private System.Windows.Forms.ListView dsdangkylv;
        private System.Windows.Forms.Label hockylb;
        private System.Windows.Forms.Label namhoclb;
        private System.Windows.Forms.ComboBox namhoccb;
        private System.Windows.Forms.ComboBox hockycb;
    }
}