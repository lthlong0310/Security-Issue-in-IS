-------------->>Phan he 2
------->>> Login vao sys voi SID: xe
/*--------------------------------------------------------------Tao 1 plugge database moi--------------------------------------------------------------*/

CREATE PLUGGABLE DATABASE "PDB" ADMIN USER "Admin" IDENTIFIED BY "admin"
  FILE_NAME_CONVERT=(
    'C:\USERS\DATABASE\ORACLE\SETUPORACLE\PRODUCT\18.0.0\ORADATA\XE\PDBSEED\SYSTEM01.DBF', 'C:\USERS\DATABASE\ORACLE\SETUPORACLE\PRODUCT\18.0.0\ORADATA\XE\NEW_PDB\SYSTEM01.DBF',
    'C:\USERS\DATABASE\ORACLE\SETUPORACLE\PRODUCT\18.0.0\ORADATA\XE\PDBSEED\SYSAUX01.DBF', 'C:\USERS\DATABASE\ORACLE\SETUPORACLE\PRODUCT\18.0.0\ORADATA\XE\NEW_PDB\SYSAUX01.DBF',
    'C:\USERS\DATABASE\ORACLE\SETUPORACLE\PRODUCT\18.0.0\ORADATA\XE\PDBSEED\UNDOTBS01.DBF', 'C:\USERS\DATABASE\ORACLE\SETUPORACLE\PRODUCT\18.0.0\ORADATA\XE\NEW_PDB\UNDOTBS01.DBF',
    'C:\USERS\DATABASE\ORACLE\SETUPORACLE\PRODUCT\18.0.0\ORADATA\XE\PDBSEED\TEMP012020-03-19_22-04-47-660-PM.DBF', 'C:\USERS\DATABASE\ORACLE\SETUPORACLE\PRODUCT\18.0.0\ORADATA\XE\NEW_PDB\TEMP012020-03-19_22-04-47-660-PM.DBF'
  )
  STORAGE UNLIMITED TEMPFILE REUSE;
/
/*--------------------------------------------------------------Tao 2 use sec_admin va sec_mgr--------------------------------------------------------------*/
------->LOGIN SYS voi service name la PDB
/*Tao 2 user
User sec_admin: user de tao bang, tao user
User sec_mgr: user de tao chinh sach bao mat */
alter session set "_ORACLE_SCRIPT"=true;
/*Open database pdb*/
ALTER DATABASE OPEN;
create user sec_admin identified by sec_admin;

ALTER USER "SEC_ADMIN" QUOTA UNLIMITED ON "SYSTEM";  

create user sec_mgr identified by sec_mgr;
ALTER USER "SEC_MGR" QUOTA UNLIMITED ON "SYSTEM";  
/
/*--------------------------------------------------------------Cap quyen cho user sec_admin va sec_mgr--------------------------------------------------------------*/
/*user sec_admin*/        
grant create session, 
create any table ,insert any table, update any table, select any table, alter any table,drop any table,
create user, drop user, alter user,
create role, drop any role,
alter any procedure, create any procedure,drop any procedure, execute any procedure,
create view , drop any view
to sec_admin with admin option;
grant execute on DBMS_RLS to sec_admin;

/*user sec_mgr*/        
grant create session,
alter any procedure, create any procedure,drop any procedure, execute any procedure,
create view , drop any view
to sec_mgr with admin option;

grant create any CONTEXT to SEC_MGR; 
grant EXECUTE on DBMS_SESSION to SEC_MGR;
grant create any trigger to sec_mgr;
grant execute on DBMS_RLS to sec_mgr;
/*--------------------------------------------------------------Tao bang--------------------------------------------------------------*/
------->Login sec_admin voi service name la PDB
CREATE TABLE taikhoan (
    username  VARCHAR2(32),
    usertype  VARCHAR2(32) --svien, gvien, gvu, trgbm, trgkhoa
);
/
ALTER TABLE taikhoan ADD CONSTRAINT taikhoan_pk PRIMARY KEY ( username );
/
CREATE TABLE lop (
    malop   VARCHAR2(10) NOT NULL,
    tenlop  NVARCHAR2(50)
);
/
ALTER TABLE lop ADD CONSTRAINT lop_pk PRIMARY KEY ( malop );
/
CREATE TABLE sinhvien (
    mssv               VARCHAR2(10) NOT NULL,
    hoten_sinhvien     NVARCHAR2(50),
    lop              VARCHAR2(10) NOT NULL,
    ngaysinh_sv  DATE,
    diachi_sv    NVARCHAR2(150),
    gioitinh_sv  NCHAR(3),
    cmnd_sv     VARCHAR2(11),
    sdt_sv     CHAR(10),
    email_sv     VARCHAR2(50)
);
/

ALTER TABLE sinhvien ADD CONSTRAINT sinhvien_pk PRIMARY KEY ( mssv );
/

CREATE TABLE giaovien (
    magiaovien         VARCHAR2(15) NOT NULL,
    hoten_giaovien     NVARCHAR2(50),
    ngaysinh_gv  DATE,
    diachi_gv    NVARCHAR2(150),
    gioitinh_gv  NCHAR(3),
    cmnd_gv      VARCHAR2(11),
    sdt_gv     CHAR(10),
    email_gv     VARCHAR2(50),
    mabomon            VARCHAR2(10),
    truongkhoa         CHAR(1),
    loaigiaovien       CHAR(1)
    
);
/

ALTER TABLE giaovien ADD CONSTRAINT giaovien_pk PRIMARY KEY ( magiaovien );
/

CREATE TABLE bomon (
    mabomon      VARCHAR2(10) NOT NULL,
    tenbomon     NVARCHAR2(50),
    truongbomon  VARCHAR2(15)
);
/

ALTER TABLE bomon ADD CONSTRAINT bomon_pk PRIMARY KEY ( mabomon );
/

CREATE TABLE monhoc (
    mamonhoc       VARCHAR2(10) NOT NULL,
    tenmonhoc      NVARCHAR2(50),
    mabomon  	   VARCHAR2(10),
    sotinchi       NUMBER
);
/

ALTER TABLE monhoc ADD CONSTRAINT monhoc_pk PRIMARY KEY ( mamonhoc );
/

CREATE TABLE thoikhoabieu (
    malop                VARCHAR2(10) NOT NULL,
    mamonhoc             VARCHAR2(10) NOT NULL,
    hocky                NUMBER NOT NULL,
    namhoc               CHAR(9) NOT NULL,
    phonghoc             VARCHAR2(10),
    giaoviengiangday  VARCHAR2(15),
    sosinhvientoida	 NUMBER
    
);
/

ALTER TABLE thoikhoabieu
    ADD CONSTRAINT thoikhoabieu_pk PRIMARY KEY (malop , mamonhoc, hocky, namhoc);
                                                 

CREATE TABLE diem (
    mssv      VARCHAR2(10) NOT NULL,
    malop     VARCHAR2(10) NOT NULL,
    mamonhoc  VARCHAR2(10) NOT NULL,
    hocky     NUMBER(1) NOT NULL,
    namhoc    CHAR(9) NOT NULL,
    diemgiuaky    varchar2(20),
    diemcuoiky    varchar2(20),
    diemkhac  varchar2(20),
    diemtong  varchar2(20)
);

ALTER TABLE diem
    ADD CONSTRAINT diem_pk PRIMARY KEY ( mssv, malop, mamonhoc, hocky, namhoc);

ALTER TABLE bomon
    ADD CONSTRAINT bomon_giaovien_fk FOREIGN KEY ( truongbomon )
        REFERENCES giaovien ( magiaovien );

ALTER TABLE diem
    ADD CONSTRAINT diem_sinhvien_fk FOREIGN KEY ( mssv )
        REFERENCES sinhvien ( mssv );

ALTER TABLE diem
    ADD CONSTRAINT diem_thoikhoabieu_fk FOREIGN KEY ( malop, mamonhoc, hocky, namhoc )
        REFERENCES thoikhoabieu ( malop, mamonhoc, hocky, namhoc );

ALTER TABLE giaovien
    ADD CONSTRAINT giaovien_bomon_fk FOREIGN KEY ( mabomon )
        REFERENCES bomon ( mabomon );


ALTER TABLE monhoc
    ADD CONSTRAINT monhoc_bomon_fk FOREIGN KEY ( mabomon )
        REFERENCES bomon ( mabomon );

ALTER TABLE sinhvien
    ADD CONSTRAINT sinhvien_lop_fk FOREIGN KEY ( lop )
        REFERENCES lop ( malop );

ALTER TABLE thoikhoabieu
    ADD CONSTRAINT thoikhoabieu_giaovien_fk FOREIGN KEY ( giaoviengiangday )
        REFERENCES giaovien ( magiaovien );

ALTER TABLE thoikhoabieu
    ADD CONSTRAINT thoikhoabieu_lop_fk FOREIGN KEY ( malop )
        REFERENCES lop ( malop );

ALTER TABLE thoikhoabieu
    ADD CONSTRAINT thoikhoabieu_monhoc_fk FOREIGN KEY ( mamonhoc )
        REFERENCES monhoc ( mamonhoc );
        
/*--------------------------------------------------------------Tao user--------------------------------------------------------------*/
----Tao user sinhvien, giaovu, giaovien
alter session set "_ORACLE_SCRIPT"=true;
/

--User : SinhVien
create user sv1 identified by sv1;
ALTER USER "SV1" QUOTA UNLIMITED ON "SYSTEM";  

/

create user sv2 identified by sv2;
ALTER USER "SV2" QUOTA UNLIMITED ON "SYSTEM";  

/

create user sv3 identified by sv3;
ALTER USER "SV3" QUOTA UNLIMITED ON "SYSTEM";  

/

create user sv4 identified by sv4;
ALTER USER "SV4" QUOTA UNLIMITED ON "SYSTEM";  

/

create user sv5 identified by sv5;
ALTER USER "SV5" QUOTA UNLIMITED ON "SYSTEM";  

/
--User: GiaoVu

create user gvu_ntmthu identified by gvu_ntmthu;
ALTER USER "GVU_NTMTHU" QUOTA UNLIMITED ON "SYSTEM";  


--User: GiaoVien
create user gvktpm_lbluan identified by lbluan;
ALTER USER "GVKTPM_LBLUAN" QUOTA UNLIMITED ON "SYSTEM";  


create user gvhttt_nahoang identified by nahoang;
ALTER USER "GVHTTT_NAHOANG" QUOTA UNLIMITED ON "SYSTEM";  


create user gvkhmt_ltlinh identified by ltlinh;
ALTER USER "GVKHMT_LTLINH" QUOTA UNLIMITED ON "SYSTEM";  

--User truong bo mon
create user trgbm_httt identified by trgbm_httt;
ALTER USER "TRGBM_HTTT" QUOTA UNLIMITED ON "SYSTEM";  

create user trgbm_khmt identified by trgbm_khmt;
ALTER USER "TRGBM_KHMT" QUOTA UNLIMITED ON "SYSTEM";  

create user trgbm_ktpm identified by trgbm_ktpm;
ALTER USER "TRGBM_KTPM" QUOTA UNLIMITED ON "SYSTEM";  

--User truong khoa
create user trgkhoa identified by trgkhoa;
ALTER USER "TRGKHOA" QUOTA UNLIMITED ON "SYSTEM";  

/*Tao role sinh vien, giao vien, giao vu, truong bo mon, truong khoa*/

create role svien;
/

create role gvien;
/

create role gvu;
/

create role trgbm;
/




/*--------------------------------------------------------------Du lieu--------------------------------------------------------------*/
--Tai khoan
insert into taikhoan values ('sv1', 'svien');
/
insert into taikhoan values ('sv2', 'svien');
/
insert into taikhoan values ('sv3', 'svien');
/
insert into taikhoan values ('sv4', 'svien');
/
insert into taikhoan values ('sv5', 'svien');
/
insert into taikhoan values ('gvktpm_lbluan', 'gvien');
/
insert into taikhoan values ('gvhttt_nahoang', 'gvien');
/
insert into taikhoan values ('gvkhmt_ltlinh', 'gvien');
/
insert into taikhoan values ('gvu_ntmthu', 'gvu');
/
insert into taikhoan values ('trgbm_httt', 'trgbm_httt');
insert into taikhoan values ('trgbm_ktmt', 'trgbm_khmt');
insert into taikhoan values ('trgbm_ktpm', 'trgbm_ktpm');
insert into taikhoan values ('trgkhoa', 'trgkhoa');

---Lop
insert into Lop values('17CLC', 'Chat luong cao');
insert into Lop values('17VP', 'Viet phap');
/

--BoMon
insert into bomon values('httt', N'He thong thong tin', NULL);
insert into bomon values('ktpm', N'Ky thuat phan mem', NULL);
insert into bomon values('khmt', N'Khoa hoc may tinh', NULL);
/

---GiaoVien
insert into Giaovien values('gvhttt_nahoang', N'Nguyen Anh Hoang', to_date('02-11-1960', 'dd-mm-yyyy'),N'332 Nguyen Thai Hoc, Tp HCM', 'Nam', '123456781', '987654321', 'hoang@gmail.com', 'httt', '0', '1' );
insert into GiaoVien values('gvu_ntmthu', N'Nguyen Tuan My Thu', to_date('08-02-1962','dd-mm-yyyy'), N'80 Le Hong Phong, Tp HCM', 'Nam', '123456123', '987654322', 'khai@gmail.com', NULL, '0', '0');
insert into GiaoVien values('gvktpm_lbluan', N'Ly Ba Luan', to_date('02-01-1967','dd-mm-yyyy'), N'34 Mai Thi Lu, Tp HCM', 'Nam', '123456124', '987654323', 'luan@gmail.com', 'ktpm', '0', '1');
insert into GiaoVien values('gvkhmt_ltlinh', N'Ly Tu Linh', to_date('03-04-1967','dd-mm-yyyy'), N'95 Ba ria Vung Tau', 'Nam', '123456125', '987654324', 'linh@gmail.com', 'khmt', '0', '1');
insert into GiaoVien values('trgbm_httt', N'Nguyen Tran Khanh', to_date('03-04-1867','dd-mm-yyyy'), N'167 Nguyen Hue', 'Nam', '3332161125', '013654324', 'khanh@gmail.com', 'httt', '0', '1');
insert into GiaoVien values('trgbm_khmt', N'Tran Anh Duy', to_date('01-01-1990','dd-mm-yyyy'), N'421 Nguyen Hue', 'Nam', '3999332125', '023654324', 'duy@gmail.com', 'khmt', '0', '1');
insert into GiaoVien values('trgbm_ktpm', N'Dinh Ba Tien', to_date('03-04-1887','dd-mm-yyyy'), N'167 Nguyen Hue', 'Nam', '37732161125', '023654324', 'tien@gmail.com', 'ktpm', '0', '1');
insert into GiaoVien values('trgkhoa', N'Ma Binh', to_date('05-05-1967','dd-mm-yyyy'), N'16D Tran Phu', 'Nam', '3132161125', '014654324', 'binh@gmail.com', NULL, '1', '1');
/

---Mon hoc
insert into monhoc values('CSC1',	'An toan bao mat', 'httt', 	4);
insert into monhoc values('CSC2','Ky thuat lap trinh',	'ktpm',	5);
insert into monhoc values('CSC3','Nhap mon lap trinh','ktpm',4);
insert into monhoc values('CSC4','He thong nhung','khmt',	4);

insert into monhoc values('CSC5','Co so du lieu','httt',	4);
insert into monhoc values('CSC6','Co so du lieu nang cao','httt',	3);
insert into monhoc values('CSC7','Nhap mon du lieu','khmt',	4);
insert into monhoc values('CSC8','Lap trinh Java','ktpm',	3);
insert into monhoc values('CSC9','Lap trinh Website','ktpm',	4);


/

---Thoi khoa bieu
insert into thoikhoabieu values('17CLC',	'CSC1',	1,	'2019','I.12', 'gvhttt_nahoang',	30);
insert into thoikhoabieu values('17CLC',	'CSC2'	,1,	'2019','I.13','gvktpm_lbluan', 30);


insert into thoikhoabieu values('17CLC',	'CSC3',	1,	'2020','C.22', 'gvktpm_lbluan',	30);
insert into thoikhoabieu values('17CLC',	'CSC4'	,1,	'2020','C.23', 'gvkhmt_ltlinh', 30);

/

---Sinh vien
insert into sinhvien  values ('sv1','Ly Thanh Long',  '17CLC', to_date('01-01-1999', 'dd-mm-yyyy'), '123 Phan Boi Chau', 'Nam', '366220123', '091234567', 'ltlong@gmail.com');
insert into sinhvien  values ('sv2','Nguyen Phuong',  '17CLC', to_date('02-02-1999', 'dd-mm-yyyy'), '332 Ta Quang Buu', 'Nu', '36612123', '034534567', 'nphuong@gmail.com');
insert into sinhvien  values ('sv3','Phung Nguyen',  '17CLC', to_date('03-03-1999', 'dd-mm-yyyy'), '456 Nguyen Trai', 'Nam', '336220123', '021234567', 'ltlong@gmail.com');
insert into sinhvien  values ('sv4','Vy Thuy',  '17CLC', to_date('04-04-1999', 'dd-mm-yyyy'), '12 Phan Chau Trinh', 'Nam', '31220123', '083234567', 'vthuy@gmail.com');
insert into sinhvien  values ('sv5','Quang Dien',  '17CLC', to_date('05-05-1999', 'dd-mm-yyyy'), '227 Nguyen Van Cuu', 'Nu', '316220125', '011234567', 'qdien@gmail.com');
/

---Diem
insert into diem values ('sv1', '17CLC',	'CSC1',	1,	'2019', 9, 10, 1, 10);
insert into diem values ('sv2', '17CLC',	'CSC1',	1,	'2019', 8, 8 , 0, 8);
insert into diem values ('sv3', '17CLC',	'CSC1',	1,	'2019', 7, 6, 2, 10);
insert into diem values ('sv4', '17CLC',	'CSC1',	1,	'2019', 9, 9, 0 ,9);
insert into diem values ('sv5', '17CLC',	'CSC1',	1,	'2019', 9, 7, 5, 10);
insert into diem values ('sv1', '17CLC',	'CSC2',	1,	'2019', 10, 10, 1, 10);
insert into diem values ('sv2', '17CLC',	'CSC2',	1,	'2019', 10, 10, 1, 9);
insert into diem values ('sv3', '17CLC',	'CSC2',	1,	'2019', 6, 6, 1, 7);

insert into diem (mssv, malop, mamonhoc, hocky, namhoc) values ('sv3', '17CLC',	'CSC3',	1,	'2020');
insert into diem (mssv, malop, mamonhoc, hocky, namhoc) values ('sv4', '17CLC',	'CSC3',	1,	'2020');
insert into diem (mssv, malop, mamonhoc, hocky, namhoc) values ('sv5', '17CLC',	'CSC3',	1,	'2020');

insert into diem values ('sv1', '17CLC',	'CSC3',	1,	'2020', NULL, NULL, NULL, NULL);

/
select * from diem;
select d.mssv, d.malop, d.mamonhoc, d.hocky, d.namhoc
from sec_admin.diem d
where d.diemgiuaky = null and d.diemcuoiky = null and d.diemkhac = null and d.diemtong = null;
/*Update lai truong bo mon*/

update bomon
set truongbomon = 'trgbm_httt'
where mabomon = 'httt';
/
update bomon
set truongbomon = 'trgbm_ktpm'
where mabomon = 'ktpm';
/
update bomon
set truongbomon = 'trgbm_khmt'
where mabomon = 'khmt';
/
/*--------------------------------------------------------------Phan quyen--------------------------------------------------------------*/

grant create session to svien, gvien, gvu, trgbm, trgkhoa;
/
grant select on sec_admin.taikhoan to svien, gvien, gvu, trgbm, trgkhoa;
/
grant svien to sv1, sv2, sv3, sv4, sv5;
/
grant gvien to gvktpm_lbluan, gvhttt_nahoang, gvkhmt_ltlinh;
/
grant gvu to gvu_ntmthu;
/
grant trgbm to trgbm_httt, trgbm_khmt, trgbm_ktpm;
/

grant select on sec_admin.lop to gvu;
/
grant select on sec_admin.monhoc to gvu;
/
grant select on sec_admin.giaovien to gvu;
/
grant select on sec_admin.bomon to gvu;
/
grant select on sec_admin.sinhvien to gvu;
/
grant select on sec_admin.diem to gvu;
/

grant select on sec_admin.lop to svien;
/
grant select on sec_admin.monhoc to svien;
/

/*--------------------------------------------------------------Drop bang--------------------------------------------------------------*/

/*
Drop table
drop table taikhoan;
drop table diem;
drop table thoikhoabieu;
drop table monhoc;
drop table sinhvien;
drop table lop;
drop table giaovien;
drop table bomon;
*/