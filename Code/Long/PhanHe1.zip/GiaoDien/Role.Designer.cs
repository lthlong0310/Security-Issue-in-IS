﻿namespace GiaoDien
{
    partial class Role
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Role));
            this.label2 = new System.Windows.Forms.Label();
            this.button_CapQuyenUser = new System.Windows.Forms.Button();
            this.button_XemDsRole = new System.Windows.Forms.Button();
            this.button_XoaRole = new System.Windows.Forms.Button();
            this.button_TaoRole = new System.Windows.Forms.Button();
            this.button_ThongTinVeQuyenUser = new System.Windows.Forms.Button();
            this.button_ThongTinQuyenCuaRole = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Maroon;
            this.label2.Location = new System.Drawing.Point(215, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(294, 58);
            this.label2.TabIndex = 32;
            this.label2.Text = "Quản lý role";
            // 
            // button_CapQuyenUser
            // 
            this.button_CapQuyenUser.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_CapQuyenUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_CapQuyenUser.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_CapQuyenUser.Image = ((System.Drawing.Image)(resources.GetObject("button_CapQuyenUser.Image")));
            this.button_CapQuyenUser.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_CapQuyenUser.Location = new System.Drawing.Point(473, 122);
            this.button_CapQuyenUser.Name = "button_CapQuyenUser";
            this.button_CapQuyenUser.Size = new System.Drawing.Size(181, 147);
            this.button_CapQuyenUser.TabIndex = 34;
            this.button_CapQuyenUser.Text = "Cấp/thu hồi quyền của role";
            this.button_CapQuyenUser.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_CapQuyenUser.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_CapQuyenUser.UseMnemonic = false;
            this.button_CapQuyenUser.UseVisualStyleBackColor = false;
            this.button_CapQuyenUser.Click += new System.EventHandler(this.button_CapQuyenUser_Click);
            // 
            // button_XemDsRole
            // 
            this.button_XemDsRole.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_XemDsRole.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_XemDsRole.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_XemDsRole.Image = ((System.Drawing.Image)(resources.GetObject("button_XemDsRole.Image")));
            this.button_XemDsRole.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_XemDsRole.Location = new System.Drawing.Point(12, 122);
            this.button_XemDsRole.Name = "button_XemDsRole";
            this.button_XemDsRole.Size = new System.Drawing.Size(184, 147);
            this.button_XemDsRole.TabIndex = 33;
            this.button_XemDsRole.Text = "Xem ds role";
            this.button_XemDsRole.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_XemDsRole.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_XemDsRole.UseMnemonic = false;
            this.button_XemDsRole.UseVisualStyleBackColor = false;
            this.button_XemDsRole.Click += new System.EventHandler(this.button_XemDsRole_Click);
            // 
            // button_XoaRole
            // 
            this.button_XoaRole.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_XoaRole.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_XoaRole.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_XoaRole.Image = ((System.Drawing.Image)(resources.GetObject("button_XoaRole.Image")));
            this.button_XoaRole.Location = new System.Drawing.Point(251, 306);
            this.button_XoaRole.Name = "button_XoaRole";
            this.button_XoaRole.Size = new System.Drawing.Size(184, 147);
            this.button_XoaRole.TabIndex = 31;
            this.button_XoaRole.Text = "Xóa role";
            this.button_XoaRole.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_XoaRole.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_XoaRole.UseMnemonic = false;
            this.button_XoaRole.UseVisualStyleBackColor = false;
            this.button_XoaRole.Click += new System.EventHandler(this.button_XoaRole_Click);
            // 
            // button_TaoRole
            // 
            this.button_TaoRole.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_TaoRole.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_TaoRole.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_TaoRole.Image = ((System.Drawing.Image)(resources.GetObject("button_TaoRole.Image")));
            this.button_TaoRole.Location = new System.Drawing.Point(251, 122);
            this.button_TaoRole.Name = "button_TaoRole";
            this.button_TaoRole.Size = new System.Drawing.Size(184, 147);
            this.button_TaoRole.TabIndex = 28;
            this.button_TaoRole.Text = "Tạo role mới";
            this.button_TaoRole.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_TaoRole.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_TaoRole.UseMnemonic = false;
            this.button_TaoRole.UseVisualStyleBackColor = false;
            this.button_TaoRole.Click += new System.EventHandler(this.button_TaoRole_Click);
            // 
            // button_ThongTinVeQuyenUser
            // 
            this.button_ThongTinVeQuyenUser.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_ThongTinVeQuyenUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ThongTinVeQuyenUser.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_ThongTinVeQuyenUser.Image = ((System.Drawing.Image)(resources.GetObject("button_ThongTinVeQuyenUser.Image")));
            this.button_ThongTinVeQuyenUser.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_ThongTinVeQuyenUser.Location = new System.Drawing.Point(12, 306);
            this.button_ThongTinVeQuyenUser.Name = "button_ThongTinVeQuyenUser";
            this.button_ThongTinVeQuyenUser.Size = new System.Drawing.Size(184, 147);
            this.button_ThongTinVeQuyenUser.TabIndex = 35;
            this.button_ThongTinVeQuyenUser.Text = "Thông tin về role của user";
            this.button_ThongTinVeQuyenUser.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_ThongTinVeQuyenUser.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_ThongTinVeQuyenUser.UseMnemonic = false;
            this.button_ThongTinVeQuyenUser.UseVisualStyleBackColor = false;
            this.button_ThongTinVeQuyenUser.Click += new System.EventHandler(this.button_ThongTinVeQuyenUser_Click);
            // 
            // button_ThongTinQuyenCuaRole
            // 
            this.button_ThongTinQuyenCuaRole.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_ThongTinQuyenCuaRole.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ThongTinQuyenCuaRole.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_ThongTinQuyenCuaRole.Image = ((System.Drawing.Image)(resources.GetObject("button_ThongTinQuyenCuaRole.Image")));
            this.button_ThongTinQuyenCuaRole.Location = new System.Drawing.Point(473, 306);
            this.button_ThongTinQuyenCuaRole.Name = "button_ThongTinQuyenCuaRole";
            this.button_ThongTinQuyenCuaRole.Size = new System.Drawing.Size(181, 147);
            this.button_ThongTinQuyenCuaRole.TabIndex = 36;
            this.button_ThongTinQuyenCuaRole.Text = "Thông tin quyền của role";
            this.button_ThongTinQuyenCuaRole.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_ThongTinQuyenCuaRole.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_ThongTinQuyenCuaRole.UseMnemonic = false;
            this.button_ThongTinQuyenCuaRole.UseVisualStyleBackColor = false;
            this.button_ThongTinQuyenCuaRole.Click += new System.EventHandler(this.button_ThongTinQuyenCuaRole_Click);
            // 
            // Role
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(672, 466);
            this.Controls.Add(this.button_ThongTinQuyenCuaRole);
            this.Controls.Add(this.button_ThongTinVeQuyenUser);
            this.Controls.Add(this.button_CapQuyenUser);
            this.Controls.Add(this.button_XemDsRole);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button_XoaRole);
            this.Controls.Add(this.button_TaoRole);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Role";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Role";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Role_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_TaoRole;
        private System.Windows.Forms.Button button_XoaRole;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button_XemDsRole;
        private System.Windows.Forms.Button button_CapQuyenUser;
        private System.Windows.Forms.Button button_ThongTinVeQuyenUser;
        private System.Windows.Forms.Button button_ThongTinQuyenCuaRole;
    }
}