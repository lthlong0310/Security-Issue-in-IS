﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity;

namespace UI
{
    public partial class MoMonHocForm : Form
    {
        User current_user;
        clsResize _form_resize;
        public MoMonHocForm(User curuser)
        {
            InitializeComponent();
            current_user = curuser;
            LoadHockyCB();
            LoadLopCB();
            LoadNamhocCB();
            LoadDSMonHoc();
            LoadDSMonHocDuoCMo();

            _form_resize = new clsResize(this);
            this.Load += _Load;
            this.Resize += _Resize;
        }

        private void _Load(object sender, EventArgs e)
        {
            _form_resize._get_initial_size();
        }

        private void _Resize(object sender, EventArgs e)
        {
            _form_resize._resize();
        }

        private void MoMonHocForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            GiaoVuMenuForm gvumenu = new GiaoVuMenuForm(current_user);
            gvumenu.ShowDialog();
            this.Close();
        }

        private void LoadHockyCB()
        {
            int[] hocky = { 1, 2, 3 };
            this.hockycb.BeginUpdate();
            foreach (var hk in hocky)
            {
                this.hockycb.Items.Add(hk);
            }
            this.hockycb.EndUpdate();
        }

        private void LoadLopCB()
        {
            this.lopcb.BeginUpdate();
            var dslop = new BLL.BLL().LayDSLop(current_user);
            foreach (var lop in dslop)
            {
                this.lopcb.Items.Add(lop.malop);
            }
            this.lopcb.EndUpdate();
        }

        private void LoadNamhocCB()
        {
            DateTime basedate = DateTime.Now;
            List<String> nam = new List<String>();
            nam.Add(basedate.Year.ToString());
            for (int i = - 1; i >= -10; i--)
            { 
                nam.Add(basedate.AddYears(i).Year.ToString());
            }
            nam.Reverse();
            /*for (int i = 0; i < nam.Count() - 1; i++)
            {
                nam[i] = nam[i] + "-" + nam[i + 1];
            }
            nam.RemoveAt(nam.Count() - 1);
            */
            this.namhoccb.BeginUpdate();
            foreach(var namhoc in nam)
            {
                namhoccb.Items.Add(namhoc);
            }
            this.namhoccb.EndUpdate();
        }

        private void LoadGiaovienCB(String bm)
        {
            this.giaoviencb.BeginUpdate();
            this.giaoviencb.Items.Clear();
            var dsgvien = new BLL.BLL().LayDSGiaoVienBoMon(current_user, bm);
            foreach(var gvien in dsgvien)
            {
                giaoviencb.Items.Add(gvien.tengv);
            }

            this.giaoviencb.EndUpdate();
        }

        private void LoadDSMonHoc()
        {
            this.dsmonhoclv.BeginUpdate();
            this.dsmonhoclv.Clear();

            this.dsmonhoclv.Columns.Add("Mã môn học", 150);
            this.dsmonhoclv.Columns.Add("Tên môn học", 350);
            this.dsmonhoclv.Columns.Add("Bộ môn", 250);
            this.dsmonhoclv.Columns.Add("Số tín chỉ", 150);

            var dsmh = new BLL.BLL().LayDSMonHoc(current_user);
            foreach(var mh in dsmh)
            {
                String[] mon = new String[4];
                mon[0] = mh.mamonhoc;
                mon[1] = mh.tenmonhoc;
                mon[2] = mh.bomon;
                if (mh.sotinchi > 0)
                    mon[3] = mh.sotinchi.ToString();
                else mon[3] = "";

                ListViewItem item = new ListViewItem(mon);
                item.Tag = mh;
                dsmonhoclv.Items.Add(item);
            }

            this.dsmonhoclv.View = View.Details;
            this.dsmonhoclv.FullRowSelect = true;
            this.dsmonhoclv.EndUpdate();
        }

        public void LoadDSMonHocDuoCMo()
        {
            this.dsmonhocmodklv.BeginUpdate();
            this.dsmonhocmodklv.Clear();

            this.dsmonhocmodklv.Columns.Add("Mã lớp", 100);
            this.dsmonhocmodklv.Columns.Add("Mã môn học", 150);
            this.dsmonhocmodklv.Columns.Add("Tên môn học", 250);
            this.dsmonhocmodklv.Columns.Add("Giáo viên giảng dạy", 250);
            this.dsmonhocmodklv.Columns.Add("Phòng học", 150);
            this.dsmonhocmodklv.Columns.Add("Số tín chỉ", 150);
            this.dsmonhocmodklv.Columns.Add("Số sinh viên tối đa", 150);

            var dshocphan = new BLL.BLL().LayDSMonhocDuocmo(current_user);
            foreach (var hocphan in dshocphan)
            {
                String[] hp = new String[7];
                hp[0] = hocphan.malop;
                hp[1] = hocphan.mamonhoc;
                hp[2] = hocphan.tenmonhoc;
                hp[3] = hocphan.giaoviengiangday;
                hp[4] = hocphan.phonghoc;
                if (hocphan.sotinchi > 0)
                    hp[5] = hocphan.sotinchi.ToString();
                else hp[5] = "";
                if (hocphan.sosvtoida > 0)
                    hp[6] = hocphan.sosvtoida.ToString();
                else hp[6] = "";

                ListViewItem item = new ListViewItem(hp);
                item.Tag = hocphan;
                this.dsmonhocmodklv.Items.Add(item);
            }


            this.dsmonhocmodklv.View = View.Details;
            this.dsmonhocmodklv.FullRowSelect = true;
            this.dsmonhocmodklv.EndUpdate();
        }

        private void dsmonhoclv_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.dsmonhoclv.SelectedItems.Count > 0)
            {
                var mh = (MonHoc)dsmonhoclv.SelectedItems[0].Tag;
                LoadGiaovienCB(mh.bomon);
            }
        }

        private void hockycb_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.dsmonhocmodklv.BeginUpdate();
            this.dsmonhocmodklv.Items.Clear();
            int hk = Int32.Parse(hockycb.SelectedItem.ToString());
            String nam = namhoccb.Text;
            var dsmonhocmo = new BLL.BLL().LayDSMonhocDuocmo(current_user, hk, nam);
            foreach(var hocphan in dsmonhocmodklv.Items)
            {
                var hp = (ThoiKhoaBieu)hocphan;
                if (hp.hocky == hk)
                    dsmonhocmo.Add(hp);
            }
            this.dsmonhocmodklv.Items.Clear();
            foreach (var hocphan in dsmonhocmo)
            {
                String[] hp = new String[7];
                hp[0] = hocphan.malop;
                hp[1] = hocphan.mamonhoc;
                hp[2] = hocphan.tenmonhoc;
                hp[3] = hocphan.giaoviengiangday;
                hp[4] = hocphan.phonghoc;
                if (hocphan.sotinchi > 0)
                    hp[5] = hocphan.sotinchi.ToString();
                else hp[5] = "";
                if (hocphan.sosvtoida > 0)
                    hp[6] = hocphan.sosvtoida.ToString();
                else hp[6] = "";

                ListViewItem item = new ListViewItem(hp);
                item.Tag = hocphan;
                this.dsmonhocmodklv.Items.Add(item);
            }


            this.dsmonhocmodklv.View = View.Details;
            this.dsmonhocmodklv.FullRowSelect = true;
            this.dsmonhocmodklv.EndUpdate();
        }

        private void namhoccb_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.dsmonhocmodklv.BeginUpdate();
            
            String nam = namhoccb.SelectedItem.ToString();
            int hk;
            if (hockycb.Text != "")
                hk = Int32.Parse(hockycb.Text);
            else hk = -1;
            var dsmonhocmo = new BLL.BLL().LayDSMonhocDuocmo(current_user, hk, nam);
            /*foreach (ListViewItem hocphan in dsmonhocmodklv.Items)
            {
                var hp = (ThoiKhoaBieu)hocphan.Tag;
                if (hp.namhoc == nam)
                    dsmonhocmo.Add(hp);
            }*/
            this.dsmonhocmodklv.Items.Clear();
            foreach (var hocphan in dsmonhocmo)
            {
                String[] hp = new String[7];
                hp[0] = hocphan.malop;
                hp[1] = hocphan.mamonhoc;
                hp[2] = hocphan.tenmonhoc;
                hp[3] = hocphan.giaoviengiangday;
                hp[4] = hocphan.phonghoc;
                if (hocphan.sotinchi > 0)
                    hp[5] = hocphan.sotinchi.ToString();
                else hp[5] = "";
                if (hocphan.sosvtoida > 0)
                    hp[6] = hocphan.sosvtoida.ToString();
                else hp[6] = "";

                ListViewItem item = new ListViewItem(hp);
                item.Tag = hocphan;
                this.dsmonhocmodklv.Items.Add(item);
            }


            this.dsmonhocmodklv.View = View.Details;
            this.dsmonhocmodklv.FullRowSelect = true;
            this.dsmonhocmodklv.EndUpdate();
        }

        private void ReloadDSMonhocMoDangky()
        {
            this.dsmonhocmodklv.BeginUpdate();
            String nam = namhoccb.Text;
            int hk;
            if (hockycb.Text != "")
                hk = Int32.Parse(hockycb.Text);
            else hk = -1;
            var dsmonhocmo = new BLL.BLL().LayDSMonhocDuocmo(current_user, hk, nam);
            /*foreach (var hocphan in dsmonhocmodklv.Items)
            {
                var hp = (ThoiKhoaBieu)hocphan;
                if (hp.namhoc == nam)
                    dsmonhocmo.Add(hp);
            }*/
            this.dsmonhocmodklv.Items.Clear();
            foreach (var hocphan in dsmonhocmo)
            {
                String[] hp = new String[7];
                hp[0] = hocphan.malop;
                hp[1] = hocphan.mamonhoc;
                hp[2] = hocphan.tenmonhoc;
                hp[3] = hocphan.giaoviengiangday;
                hp[4] = hocphan.phonghoc;
                if (hocphan.sotinchi > 0)
                    hp[5] = hocphan.sotinchi.ToString();
                else hp[5] = "";
                if (hocphan.sosvtoida > 0)
                    hp[6] = hocphan.sosvtoida.ToString();
                else hp[6] = "";

                ListViewItem item = new ListViewItem(hp);
                item.Tag = hocphan;
                this.dsmonhocmodklv.Items.Add(item);
            }


            this.dsmonhocmodklv.View = View.Details;
            this.dsmonhocmodklv.FullRowSelect = true;
            this.dsmonhocmodklv.EndUpdate();
        }

        private void momondkbttn_Click(object sender, EventArgs e)
        {
            if (this.dsmonhoclv.SelectedItems.Count > 0)
            {
                if (lopcb.Text == "" || hockycb.Text == "" || namhoccb.Text == "" || giaoviencb.Text == "")
                {
                    MessageBox.Show("Không đủ thông  tin");
                    return;
                }
                var mh = (MonHoc)dsmonhoclv.SelectedItems[0].Tag;
                int svtoida;
                if (svtoidatb.Text == "")
                    svtoida = -1;
                else svtoida = Int32.Parse(svtoidatb.Text);
                var hp = new ThoiKhoaBieu(lopcb.SelectedItem.ToString(), mh.mamonhoc, mh.tenmonhoc, Int32.Parse(hockycb.SelectedItem.ToString()), namhoccb.SelectedItem.ToString(), phongtb.Text, giaoviencb.SelectedItem.ToString(), mh.sotinchi, svtoida);
                var momonhoc = new BLL.BLL().MoHocPhanDangky(current_user, hp);
                if (momonhoc)
                {
                    ReloadDSMonhocMoDangky();
                    MessageBox.Show("Mở môn học thành công");
                }
                else MessageBox.Show("Mở môn học không thành công. Vui lòng thử lại");
            }
            else MessageBox.Show("Vui lòng chọn môn học để mở đăng ký");
        }

        private void modangkybttn_Click(object sender, EventArgs e)
        {
            var modangky = new BLL.BLL().MoDangky(current_user);
            if (modangky)
                MessageBox.Show("Mở đăng ký thành công");
            else MessageBox.Show("Mở đăng ký không thành công");
        }

        private void huymomondkbttn_Click(object sender, EventArgs e)
        {
            if (this.dsmonhocmodklv.SelectedItems.Count > 0)
            {
                var hp = (ThoiKhoaBieu)dsmonhocmodklv.SelectedItems[0].Tag;
                var huymomonhoc = new BLL.BLL().HuyMoHocPhanDangky(current_user, hp);
                if (huymomonhoc)
                {
                    ReloadDSMonhocMoDangky();
                    MessageBox.Show("Huỷ mở môn học thành công");
                }
                else MessageBox.Show("Hủy mở môn học không thành công. Vui lòng thử lại");
            }
            else MessageBox.Show("Vui lòng chọn môn học để hủy mở đăng ký");
        }

        private void dongdkbttn_Click(object sender, EventArgs e)
        {
            var dongdangky = new BLL.BLL().DongDangky(current_user);
            if (dongdangky)
                MessageBox.Show("Đóng đăng ký thành công");
            else MessageBox.Show("Đóng đăng ký không thành công");
        }
    }
}
