﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity;

namespace UI
{
    public partial class TruongBoMonMenuForm : Form
    {
        User current_user;
        public TruongBoMonMenuForm(User curuser)
        {
            current_user = curuser;

            InitializeComponent();

        }


        private void logoutbttn_Click(object sender, EventArgs e)
        {
            current_user.ClearUser();
            this.Hide();
            LoginForm login = new LoginForm();
            login.ShowDialog();
            this.Close();
        }
    }
}
