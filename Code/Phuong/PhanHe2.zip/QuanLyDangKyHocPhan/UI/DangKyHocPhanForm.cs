﻿using Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class DangKyHocPhanForm : Form
    {
        clsResize _form_resize;
        User current_user;
        public DangKyHocPhanForm(User curuser)
        {
            InitializeComponent();
            current_user = curuser;
            LoadDSHocPhanListView();
            LoadDSHocPhanDangkyListView();
            LoadNamhocCB();
            LoadHockyCB();

            _form_resize = new clsResize(this);
            this.Load += _Load;
            this.Resize += _Resize;
        }

        private void _Load(object sender, EventArgs e)
        {
            _form_resize._get_initial_size();
        }

        private void _Resize(object sender, EventArgs e)
        {
            _form_resize._resize();
        }

        private void DangKyHocPhanForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            SinhVienMenuForm svmenu = new SinhVienMenuForm(current_user);
            svmenu.ShowDialog();
            this.Close();
        }

        private void LoadDSHocPhanListView()
        {
            this.dshocphanlv.BeginUpdate();
            this.dshocphanlv.Clear();

            this.dshocphanlv.Columns.Add("Mã lớp", 100);
            this.dshocphanlv.Columns.Add("Mã môn học", 150);
            this.dshocphanlv.Columns.Add("Tên môn học", 250);
            this.dshocphanlv.Columns.Add("Học kỳ", 150);
            this.dshocphanlv.Columns.Add("Năm học", 200);
            this.dshocphanlv.Columns.Add("Giáo viên giảng dạy", 250);
            this.dshocphanlv.Columns.Add("Phòng học", 150);
            this.dshocphanlv.Columns.Add("Số tín chỉ", 150);
            this.dshocphanlv.Columns.Add("Số sinh viên hiện tại", 150);

            var dshocphan = new BLL.BLL().LayDSMonhocDuocmo(current_user);
            foreach(var hocphan in dshocphan)
            {
                String[] hp = new String[9];
                hp[0] = hocphan.malop;
                hp[1] = hocphan.mamonhoc;
                hp[2] = hocphan.tenmonhoc;
                hp[3] = hocphan.hocky.ToString();
                hp[4] = hocphan.namhoc;
                hp[5] = hocphan.giaoviengiangday;
                hp[6] = hocphan.phonghoc;
                if (hocphan.sotinchi > 0)
                    hp[7] = hocphan.sotinchi.ToString();
                else hp[7] = "";
                if (hocphan.sosvhientai > 0)
                    hp[8] = hocphan.sosvhientai.ToString();
                else hp[8] = "0";
                if (hocphan.sosvtoida > 0)
                    hp[8] += "/" + hocphan.sosvtoida.ToString();
                else hp[8] += "";

                ListViewItem item = new ListViewItem(hp);
                item.Tag = hocphan;
                this.dshocphanlv.Items.Add(item);
            }
                


            this.dshocphanlv.View = View.Details;
            this.dshocphanlv.FullRowSelect = true;
            this.dshocphanlv.EndUpdate();
        }

        private void LoadDSHocPhanDangkyListView()
        {
            this.dshocphandadangkylv.BeginUpdate();
            this.dshocphandadangkylv.Clear();

            this.dshocphandadangkylv.Columns.Add("Lớp", 150);
            this.dshocphandadangkylv.Columns.Add("Tên môn học", 250);
            this.dshocphandadangkylv.Columns.Add("Học kỳ", 150);
            this.dshocphandadangkylv.Columns.Add("Năm học", 200);

            var dsdangky = new BLL.BLL().LayDSSinhVienDangky(current_user);

            foreach(var dangky in dsdangky)
            {
                String[] dk = new String[2];
                dk[0] = dangky.malop; 
                dk[1] = dangky.monhoc;

                ListViewItem item = new ListViewItem(dk);
                item.Tag = dangky;
                dshocphandadangkylv.Items.Add(item);
            }
            this.dshocphandadangkylv.View = View.Details;
            this.dshocphandadangkylv.FullRowSelect = true;
            this.dshocphandadangkylv.EndUpdate();
        }

        private void dangkybttn_Click(object sender, EventArgs e)
        {
            if (this.dshocphanlv.SelectedItems.Count > 0)
            {
                ThoiKhoaBieu hocphan = (ThoiKhoaBieu)dshocphanlv.SelectedItems[0].Tag;
                var dangky = new BLL.BLL().DangkyHocphan(current_user, hocphan);

                if (dangky)
                {
                    ReLoadDSHocPhanDangkyListView(); 
                    MessageBox.Show("Đăng ký thành công");
                }
                else MessageBox.Show("Đăng ký không thành công. Vui lòng thử lại");
            }
            else MessageBox.Show("Vui lòng lựa chọn học phần để đăng ký");
        }

        private void huydangkybttn_Click(object sender, EventArgs e)
        {
            if (this.dshocphanlv.SelectedItems.Count > 0)
            {
                ThoiKhoaBieu hocphan = (ThoiKhoaBieu)dshocphandadangkylv.SelectedItems[0].Tag;
                var huydangky = new BLL.BLL().HuyDangkyHocphan(current_user, hocphan);

                if (huydangky)
                {
                    ReLoadDSHocPhanDangkyListView(); 
                    MessageBox.Show("Hủy thành công");
                }
                else MessageBox.Show("Hủy không thành công. Vui lòng thử lại");
            }
            else MessageBox.Show("Vui lòng lựa chọn học phần để hủy");
        }

        private void LoadHockyCB()
        {
            int[] hocky = { 1, 2, 3 };
            this.hockycb.BeginUpdate();
            foreach (var hk in hocky)
            {
                this.hockycb.Items.Add(hk);
            }
            this.hockycb.EndUpdate();
        }

        private void LoadNamhocCB()
        {
            DateTime basedate = DateTime.Now;
            List<String> nam = new List<String>();
            nam.Add(basedate.Year.ToString());
            for (int i = -1; i >= -10; i--)
            {
                nam.Add(basedate.AddYears(i).Year.ToString());
            }
            nam.Reverse();
            /*for (int i = 0; i < nam.Count() - 1; i++)
            {
                nam[i] = nam[i] + "-" + nam[i + 1];
            }
            nam.RemoveAt(nam.Count() - 1);
            */
            this.namhoccb.BeginUpdate();
            foreach (var namhoc in nam)
            {
                namhoccb.Items.Add(namhoc);
            }
            this.namhoccb.EndUpdate();
        }

        private void hockycb_SelectedIndexChanged(object sender, EventArgs e)
        {
            ReLoadDSHocPhanListView();
            ReLoadDSHocPhanDangkyListView();
        }

        private void namhoccb_SelectedIndexChanged(object sender, EventArgs e)
        {
            ReLoadDSHocPhanListView();
            ReLoadDSHocPhanDangkyListView();
        }

        private void ReLoadDSHocPhanListView()
        {
            this.dshocphanlv.BeginUpdate();
            this.dshocphanlv.Items.Clear();
            String nam = namhoccb.Text;
            int hk;
            if (hockycb.Text != "")
                hk = Int32.Parse(hockycb.Text);
            else hk = -1;
            var dshocphan = new BLL.BLL().LayDSMonhocDuocmo(current_user, hk, nam);


            foreach (var hocphan in dshocphan)
            {
                String[] hp = new String[9];
                hp[0] = hocphan.malop;
                hp[1] = hocphan.mamonhoc;
                hp[2] = hocphan.tenmonhoc;
                hp[3] = hocphan.hocky.ToString();
                hp[4] = hocphan.namhoc;
                hp[5] = hocphan.giaoviengiangday;
                hp[6] = hocphan.phonghoc;
                if (hocphan.sotinchi > 0)
                    hp[7] = hocphan.sotinchi.ToString();
                else hp[7] = "";
                if (hocphan.sosvhientai > 0)
                    hp[8] = hocphan.sosvhientai.ToString();
                else hp[8] = "0";
                if (hocphan.sosvtoida > 0)
                    hp[8] += "/" + hocphan.sosvtoida.ToString();
                else hp[8] += "";

                ListViewItem item = new ListViewItem(hp);
                item.Tag = hocphan;
                this.dshocphanlv.Items.Add(item);
            }



            this.dshocphanlv.View = View.Details;
            this.dshocphanlv.FullRowSelect = true;
            this.dshocphanlv.EndUpdate();
        }

        private void ReLoadDSHocPhanDangkyListView()
        {
            this.dshocphandadangkylv.BeginUpdate();
            this.dshocphandadangkylv.Items.Clear();

            String nam = namhoccb.Text;
            int hk;
            if (hockycb.Text != "")
                hk = Int32.Parse(hockycb.Text);
            else hk = -1;
            var dsdangky = new BLL.BLL().LayDSMonDaDangky(current_user, hk, nam);

            foreach (var dangky in dsdangky)
            {
                String[] dk = new String[2];
                dk[0] = dangky.malop;
                dk[1] = dangky.monhoc;

                ListViewItem item = new ListViewItem(dk);
                item.Tag = dangky;
                dshocphandadangkylv.Items.Add(item);
            }
            this.dshocphandadangkylv.View = View.Details;
            this.dshocphandadangkylv.FullRowSelect = true;
            this.dshocphandadangkylv.EndUpdate();
        }
    }


}
