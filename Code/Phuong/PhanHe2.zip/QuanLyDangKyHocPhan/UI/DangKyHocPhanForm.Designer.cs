﻿namespace UI
{
    partial class DangKyHocPhanForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dshocphanlv = new System.Windows.Forms.ListView();
            this.dshocphandadangkylv = new System.Windows.Forms.ListView();
            this.dangkybttn = new System.Windows.Forms.Button();
            this.huydangkybttn = new System.Windows.Forms.Button();
            this.dshocphanlb = new System.Windows.Forms.Label();
            this.dshocphandadanglylb = new System.Windows.Forms.Label();
            this.hockylb = new System.Windows.Forms.Label();
            this.namhoclb = new System.Windows.Forms.Label();
            this.namhoccb = new System.Windows.Forms.ComboBox();
            this.hockycb = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // dshocphanlv
            // 
            this.dshocphanlv.HideSelection = false;
            this.dshocphanlv.Location = new System.Drawing.Point(32, 144);
            this.dshocphanlv.Name = "dshocphanlv";
            this.dshocphanlv.Size = new System.Drawing.Size(542, 395);
            this.dshocphanlv.TabIndex = 0;
            this.dshocphanlv.UseCompatibleStateImageBehavior = false;
            // 
            // dshocphandadangkylv
            // 
            this.dshocphandadangkylv.HideSelection = false;
            this.dshocphandadangkylv.Location = new System.Drawing.Point(600, 144);
            this.dshocphandadangkylv.Name = "dshocphandadangkylv";
            this.dshocphandadangkylv.Size = new System.Drawing.Size(357, 395);
            this.dshocphandadangkylv.TabIndex = 1;
            this.dshocphandadangkylv.UseCompatibleStateImageBehavior = false;
            // 
            // dangkybttn
            // 
            this.dangkybttn.Location = new System.Drawing.Point(218, 565);
            this.dangkybttn.Name = "dangkybttn";
            this.dangkybttn.Size = new System.Drawing.Size(168, 43);
            this.dangkybttn.TabIndex = 2;
            this.dangkybttn.Text = "Đăng ký";
            this.dangkybttn.UseVisualStyleBackColor = true;
            this.dangkybttn.Click += new System.EventHandler(this.dangkybttn_Click);
            // 
            // huydangkybttn
            // 
            this.huydangkybttn.Location = new System.Drawing.Point(705, 565);
            this.huydangkybttn.Name = "huydangkybttn";
            this.huydangkybttn.Size = new System.Drawing.Size(168, 43);
            this.huydangkybttn.TabIndex = 3;
            this.huydangkybttn.Text = "Hủy đăng ký";
            this.huydangkybttn.UseVisualStyleBackColor = true;
            this.huydangkybttn.Click += new System.EventHandler(this.huydangkybttn_Click);
            // 
            // dshocphanlb
            // 
            this.dshocphanlb.AutoSize = true;
            this.dshocphanlb.Location = new System.Drawing.Point(217, 103);
            this.dshocphanlb.Name = "dshocphanlb";
            this.dshocphanlb.Size = new System.Drawing.Size(179, 20);
            this.dshocphanlb.TabIndex = 4;
            this.dshocphanlb.Text = "Các môn có thể đăng ký";
            // 
            // dshocphandadanglylb
            // 
            this.dshocphandadanglylb.AutoSize = true;
            this.dshocphandadanglylb.Location = new System.Drawing.Point(710, 103);
            this.dshocphandadanglylb.Name = "dshocphandadanglylb";
            this.dshocphandadanglylb.Size = new System.Drawing.Size(153, 20);
            this.dshocphandadanglylb.TabIndex = 5;
            this.dshocphandadanglylb.Text = "Các môn đã đăng ký";
            // 
            // hockylb
            // 
            this.hockylb.AutoSize = true;
            this.hockylb.Location = new System.Drawing.Point(33, 47);
            this.hockylb.Name = "hockylb";
            this.hockylb.Size = new System.Drawing.Size(61, 20);
            this.hockylb.TabIndex = 16;
            this.hockylb.Text = "Học kỳ:";
            // 
            // namhoclb
            // 
            this.namhoclb.AutoSize = true;
            this.namhoclb.Location = new System.Drawing.Point(320, 47);
            this.namhoclb.Name = "namhoclb";
            this.namhoclb.Size = new System.Drawing.Size(76, 20);
            this.namhoclb.TabIndex = 15;
            this.namhoclb.Text = "Năm học:";
            // 
            // namhoccb
            // 
            this.namhoccb.FormattingEnabled = true;
            this.namhoccb.Location = new System.Drawing.Point(412, 44);
            this.namhoccb.Name = "namhoccb";
            this.namhoccb.Size = new System.Drawing.Size(231, 28);
            this.namhoccb.TabIndex = 14;
            this.namhoccb.SelectedIndexChanged += new System.EventHandler(this.namhoccb_SelectedIndexChanged);
            // 
            // hockycb
            // 
            this.hockycb.FormattingEnabled = true;
            this.hockycb.Location = new System.Drawing.Point(118, 44);
            this.hockycb.Name = "hockycb";
            this.hockycb.Size = new System.Drawing.Size(121, 28);
            this.hockycb.TabIndex = 13;
            this.hockycb.SelectedIndexChanged += new System.EventHandler(this.hockycb_SelectedIndexChanged);
            // 
            // DangKyHocPhanForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(996, 673);
            this.Controls.Add(this.hockylb);
            this.Controls.Add(this.namhoclb);
            this.Controls.Add(this.namhoccb);
            this.Controls.Add(this.hockycb);
            this.Controls.Add(this.dshocphandadanglylb);
            this.Controls.Add(this.dshocphanlb);
            this.Controls.Add(this.huydangkybttn);
            this.Controls.Add(this.dangkybttn);
            this.Controls.Add(this.dshocphandadangkylv);
            this.Controls.Add(this.dshocphanlv);
            this.Name = "DangKyHocPhanForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Đăng ký học phần";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DangKyHocPhanForm_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView dshocphanlv;
        private System.Windows.Forms.ListView dshocphandadangkylv;
        private System.Windows.Forms.Button dangkybttn;
        private System.Windows.Forms.Button huydangkybttn;
        private System.Windows.Forms.Label dshocphanlb;
        private System.Windows.Forms.Label dshocphandadanglylb;
        private System.Windows.Forms.Label hockylb;
        private System.Windows.Forms.Label namhoclb;
        private System.Windows.Forms.ComboBox namhoccb;
        private System.Windows.Forms.ComboBox hockycb;
    }
}