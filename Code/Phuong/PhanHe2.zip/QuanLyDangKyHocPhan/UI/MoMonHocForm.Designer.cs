﻿namespace UI
{
    partial class MoMonHocForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dsmonhoclv = new System.Windows.Forms.ListView();
            this.dsmonhocmodklv = new System.Windows.Forms.ListView();
            this.modangkybttn = new System.Windows.Forms.Button();
            this.huymomondkbttn = new System.Windows.Forms.Button();
            this.dongdkbttn = new System.Windows.Forms.Button();
            this.giaoviencb = new System.Windows.Forms.ComboBox();
            this.lopcb = new System.Windows.Forms.ComboBox();
            this.hockycb = new System.Windows.Forms.ComboBox();
            this.namhoccb = new System.Windows.Forms.ComboBox();
            this.loplb = new System.Windows.Forms.Label();
            this.giaovienlb = new System.Windows.Forms.Label();
            this.namhoclb = new System.Windows.Forms.Label();
            this.hockylb = new System.Windows.Forms.Label();
            this.phongtb = new System.Windows.Forms.TextBox();
            this.phonglb = new System.Windows.Forms.Label();
            this.svtoidalb = new System.Windows.Forms.Label();
            this.svtoidatb = new System.Windows.Forms.TextBox();
            this.momondkbttn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // dsmonhoclv
            // 
            this.dsmonhoclv.HideSelection = false;
            this.dsmonhoclv.Location = new System.Drawing.Point(61, 164);
            this.dsmonhoclv.Name = "dsmonhoclv";
            this.dsmonhoclv.Size = new System.Drawing.Size(359, 353);
            this.dsmonhoclv.TabIndex = 0;
            this.dsmonhoclv.UseCompatibleStateImageBehavior = false;
            this.dsmonhoclv.SelectedIndexChanged += new System.EventHandler(this.dsmonhoclv_SelectedIndexChanged);
            // 
            // dsmonhocmodklv
            // 
            this.dsmonhocmodklv.HideSelection = false;
            this.dsmonhocmodklv.Location = new System.Drawing.Point(512, 164);
            this.dsmonhocmodklv.Name = "dsmonhocmodklv";
            this.dsmonhocmodklv.Size = new System.Drawing.Size(650, 353);
            this.dsmonhocmodklv.TabIndex = 1;
            this.dsmonhocmodklv.UseCompatibleStateImageBehavior = false;
            // 
            // modangkybttn
            // 
            this.modangkybttn.Location = new System.Drawing.Point(61, 548);
            this.modangkybttn.Name = "modangkybttn";
            this.modangkybttn.Size = new System.Drawing.Size(162, 42);
            this.modangkybttn.TabIndex = 2;
            this.modangkybttn.Text = "Mở đăng ký";
            this.modangkybttn.UseVisualStyleBackColor = true;
            this.modangkybttn.Click += new System.EventHandler(this.modangkybttn_Click);
            // 
            // huymomondkbttn
            // 
            this.huymomondkbttn.Location = new System.Drawing.Point(971, 548);
            this.huymomondkbttn.Name = "huymomondkbttn";
            this.huymomondkbttn.Size = new System.Drawing.Size(191, 42);
            this.huymomondkbttn.TabIndex = 3;
            this.huymomondkbttn.Text = "Hủy mở môn đăng ký";
            this.huymomondkbttn.UseVisualStyleBackColor = true;
            this.huymomondkbttn.Click += new System.EventHandler(this.huymomondkbttn_Click);
            // 
            // dongdkbttn
            // 
            this.dongdkbttn.Location = new System.Drawing.Point(512, 548);
            this.dongdkbttn.Name = "dongdkbttn";
            this.dongdkbttn.Size = new System.Drawing.Size(169, 42);
            this.dongdkbttn.TabIndex = 4;
            this.dongdkbttn.Text = "Đỏng đăng ký";
            this.dongdkbttn.UseVisualStyleBackColor = true;
            this.dongdkbttn.Click += new System.EventHandler(this.dongdkbttn_Click);
            // 
            // giaoviencb
            // 
            this.giaoviencb.FormattingEnabled = true;
            this.giaoviencb.Location = new System.Drawing.Point(459, 40);
            this.giaoviencb.Name = "giaoviencb";
            this.giaoviencb.Size = new System.Drawing.Size(349, 28);
            this.giaoviencb.TabIndex = 5;
            // 
            // lopcb
            // 
            this.lopcb.FormattingEnabled = true;
            this.lopcb.Location = new System.Drawing.Point(126, 40);
            this.lopcb.Name = "lopcb";
            this.lopcb.Size = new System.Drawing.Size(141, 28);
            this.lopcb.TabIndex = 6;
            // 
            // hockycb
            // 
            this.hockycb.FormattingEnabled = true;
            this.hockycb.Location = new System.Drawing.Point(126, 98);
            this.hockycb.Name = "hockycb";
            this.hockycb.Size = new System.Drawing.Size(121, 28);
            this.hockycb.TabIndex = 7;
            this.hockycb.SelectedIndexChanged += new System.EventHandler(this.hockycb_SelectedIndexChanged);
            // 
            // namhoccb
            // 
            this.namhoccb.FormattingEnabled = true;
            this.namhoccb.Location = new System.Drawing.Point(459, 93);
            this.namhoccb.Name = "namhoccb";
            this.namhoccb.Size = new System.Drawing.Size(231, 28);
            this.namhoccb.TabIndex = 8;
            this.namhoccb.SelectedIndexChanged += new System.EventHandler(this.namhoccb_SelectedIndexChanged);
            // 
            // loplb
            // 
            this.loplb.AutoSize = true;
            this.loplb.Location = new System.Drawing.Point(57, 43);
            this.loplb.Name = "loplb";
            this.loplb.Size = new System.Drawing.Size(44, 20);
            this.loplb.TabIndex = 9;
            this.loplb.Text = "Lớp: ";
            // 
            // giaovienlb
            // 
            this.giaovienlb.AutoSize = true;
            this.giaovienlb.Location = new System.Drawing.Point(302, 43);
            this.giaovienlb.Name = "giaovienlb";
            this.giaovienlb.Size = new System.Drawing.Size(151, 20);
            this.giaovienlb.TabIndex = 10;
            this.giaovienlb.Text = "Giáo viên giảng dạy:";
            // 
            // namhoclb
            // 
            this.namhoclb.AutoSize = true;
            this.namhoclb.Location = new System.Drawing.Point(303, 101);
            this.namhoclb.Name = "namhoclb";
            this.namhoclb.Size = new System.Drawing.Size(76, 20);
            this.namhoclb.TabIndex = 11;
            this.namhoclb.Text = "Năm học:";
            // 
            // hockylb
            // 
            this.hockylb.AutoSize = true;
            this.hockylb.Location = new System.Drawing.Point(59, 101);
            this.hockylb.Name = "hockylb";
            this.hockylb.Size = new System.Drawing.Size(61, 20);
            this.hockylb.TabIndex = 12;
            this.hockylb.Text = "Học kỳ:";
            // 
            // phongtb
            // 
            this.phongtb.Location = new System.Drawing.Point(1004, 40);
            this.phongtb.Name = "phongtb";
            this.phongtb.Size = new System.Drawing.Size(158, 26);
            this.phongtb.TabIndex = 13;
            // 
            // phonglb
            // 
            this.phonglb.AutoSize = true;
            this.phonglb.Location = new System.Drawing.Point(853, 43);
            this.phonglb.Name = "phonglb";
            this.phonglb.Size = new System.Drawing.Size(89, 20);
            this.phonglb.TabIndex = 14;
            this.phonglb.Text = "Phòng học:";
            // 
            // svtoidalb
            // 
            this.svtoidalb.AutoSize = true;
            this.svtoidalb.Location = new System.Drawing.Point(853, 101);
            this.svtoidalb.Name = "svtoidalb";
            this.svtoidalb.Size = new System.Drawing.Size(141, 20);
            this.svtoidalb.TabIndex = 15;
            this.svtoidalb.Text = "Số sinh viên tối đa:";
            // 
            // svtoidatb
            // 
            this.svtoidatb.Location = new System.Drawing.Point(1004, 98);
            this.svtoidatb.Name = "svtoidatb";
            this.svtoidatb.Size = new System.Drawing.Size(142, 26);
            this.svtoidatb.TabIndex = 16;
            // 
            // momondkbttn
            // 
            this.momondkbttn.Location = new System.Drawing.Point(258, 548);
            this.momondkbttn.Name = "momondkbttn";
            this.momondkbttn.Size = new System.Drawing.Size(162, 42);
            this.momondkbttn.TabIndex = 17;
            this.momondkbttn.Text = "Mở môn đăng ký";
            this.momondkbttn.UseVisualStyleBackColor = true;
            this.momondkbttn.Click += new System.EventHandler(this.momondkbttn_Click);
            // 
            // MoMonHocForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1204, 622);
            this.Controls.Add(this.momondkbttn);
            this.Controls.Add(this.svtoidatb);
            this.Controls.Add(this.svtoidalb);
            this.Controls.Add(this.phonglb);
            this.Controls.Add(this.phongtb);
            this.Controls.Add(this.hockylb);
            this.Controls.Add(this.namhoclb);
            this.Controls.Add(this.giaovienlb);
            this.Controls.Add(this.loplb);
            this.Controls.Add(this.namhoccb);
            this.Controls.Add(this.hockycb);
            this.Controls.Add(this.lopcb);
            this.Controls.Add(this.giaoviencb);
            this.Controls.Add(this.dongdkbttn);
            this.Controls.Add(this.huymomondkbttn);
            this.Controls.Add(this.modangkybttn);
            this.Controls.Add(this.dsmonhocmodklv);
            this.Controls.Add(this.dsmonhoclv);
            this.Name = "MoMonHocForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MoMonHoc";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MoMonHocForm_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView dsmonhoclv;
        private System.Windows.Forms.ListView dsmonhocmodklv;
        private System.Windows.Forms.Button modangkybttn;
        private System.Windows.Forms.Button huymomondkbttn;
        private System.Windows.Forms.Button dongdkbttn;
        private System.Windows.Forms.ComboBox giaoviencb;
        private System.Windows.Forms.ComboBox lopcb;
        private System.Windows.Forms.ComboBox hockycb;
        private System.Windows.Forms.ComboBox namhoccb;
        private System.Windows.Forms.Label loplb;
        private System.Windows.Forms.Label giaovienlb;
        private System.Windows.Forms.Label namhoclb;
        private System.Windows.Forms.Label hockylb;
        private System.Windows.Forms.TextBox phongtb;
        private System.Windows.Forms.Label phonglb;
        private System.Windows.Forms.Label svtoidalb;
        private System.Windows.Forms.TextBox svtoidatb;
        private System.Windows.Forms.Button momondkbttn;
    }
}