﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity;

//Cua giao vu

namespace UI
{
    public partial class XemDanhSachDangKyMonHocForm : Form
    {
        User current_user;
        clsResize _form_resize;
        public XemDanhSachDangKyMonHocForm(User curuser)
        {
            InitializeComponent();
            current_user = curuser;
            LoadLopCB();
            LoadMonHocCB();
            LoadHockyCB();
            LoadNamhocCB();
            LoadDSDangky();

            _form_resize = new clsResize(this);
            this.Load += _Load;
            this.Resize += _Resize;
        }

        private void _Load(object sender, EventArgs e)
        {
            _form_resize._get_initial_size();
        }

        private void _Resize(object sender, EventArgs e)
        {
            _form_resize._resize();
        }

        private void XemDanhSachDangKyMonHocForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            GiaoVuMenuForm giaovumenu = new GiaoVuMenuForm(current_user);
            giaovumenu.ShowDialog();
            this.Close();
        }

        private void LoadLopCB()
        {
            this.lopcb.BeginUpdate();
            this.lopcb.Items.Clear();
            var dslop = new BLL.BLL().LayDSLop(current_user);
            foreach (var lop in dslop)
            {
                this.lopcb.Items.Add(lop.malop);
            }
            this.lopcb.EndUpdate();
        }

        private void LoadMonHocCB()
        {
            this.monhoccb.BeginUpdate();
            this.monhoccb.Items.Clear();
            var dsmon = new BLL.BLL().LayDSMonHoc(current_user);
            foreach (var mon in dsmon)
            {
                this.monhoccb.Items.Add(mon.tenmonhoc);
            }
            this.monhoccb.EndUpdate();
        }


        private void LoadHockyCB()
        {
            int[] hocky = { 1, 2, 3 };
            this.hockycb.BeginUpdate();
            foreach (var hk in hocky)
            {
                this.hockycb.Items.Add(hk);
            }
            this.hockycb.EndUpdate();
        }



        private void LoadNamhocCB()
        {
            DateTime basedate = DateTime.Now;
            List<String> nam = new List<String>();
            nam.Add(basedate.Year.ToString());
            for (int i = -1; i >= -10; i--)
            {
                nam.Add(basedate.AddYears(i).Year.ToString());
            }
            nam.Reverse();
            /*for (int i = 0; i < nam.Count() - 1; i++)
            {
                nam[i] = nam[i] + "-" + nam[i + 1];
            }
            nam.RemoveAt(nam.Count() - 1);
            */
            this.namhoccb.BeginUpdate();
            foreach (var namhoc in nam)
            {
                namhoccb.Items.Add(namhoc);
            }
            this.namhoccb.EndUpdate();
        }
        private void LoadDSDangky()
        {
            this.dsdangkylv.BeginUpdate();
            this.dsdangkylv.Clear();

            this.dsdangkylv.Columns.Add("Mã số sinh viên", 200);
            this.dsdangkylv.Columns.Add("Họ tên", 350);
            this.dsdangkylv.Columns.Add("Lớp", 150);
            this.dsdangkylv.Columns.Add("Môc học", 250);
            this.dsdangkylv.Columns.Add("Học kỳ", 150);
            this.dsdangkylv.Columns.Add("Năm học", 200);

            var dsdangky = new BLL.BLL().LayDSSinhVienDangky(current_user);
            var dssv = new BLL.BLL().LayDSSinhVien(current_user);

            foreach (var dk in dsdangky)
            {
                String[] dangky = new String[6];
                dangky[0] = dk.mssv;
                foreach (var sv in dssv)
                {
                    if (sv.mssv == dk.mssv)
                    {
                        dangky[1] = sv.hotensv;
                        break;
                    }
                }
                dangky[2] = dk.malop;
                dangky[3] = dk.monhoc;
                dangky[4] = dk.hocky.ToString();
                dangky[5] = dk.mssv;

                ListViewItem item = new ListViewItem(dangky);
                dsdangkylv.Items.Add(item);
            }


            this.dsdangkylv.View = View.Details;
            this.dsdangkylv.FullRowSelect = true;
            this.dsdangkylv.EndUpdate();
        }

        private void monhoccb_SelectedIndexChanged(object sender, EventArgs e)
        {
            ReloadDSDangky();
        }

        private void lopcb_SelectedIndexChanged(object sender, EventArgs e)
        {
            ReloadDSDangky();
        }

        private void hockycb_SelectedIndexChanged(object sender, EventArgs e)
        {
            ReloadDSDangky();
        }

        private void namhoccb_SelectedIndexChanged(object sender, EventArgs e)
        {
            ReloadDSDangky();
        }

        private void ReloadDSDangky()
        {
            this.dsdangkylv.BeginUpdate();
            this.dsdangkylv.Items.Clear();

            String lop = lopcb.Text;
            String nam = namhoccb.Text;
            String mon = monhoccb.Text;
            int hk;
            if (hockycb.Text != "")
                hk = Int32.Parse(hockycb.Text);
            else hk = -1;
            var dsdangky = new BLL.BLL().LayDSSinhVienDangky(current_user, mon, lop, hk, nam);
            var dssv = new BLL.BLL().LayDSSinhVien(current_user);

            foreach (var dk in dsdangky)
            {
                String[] dangky = new String[6];
                dangky[0] = dk.mssv;
                foreach (var sv in dssv)
                {
                    if (sv.mssv == dk.mssv)
                    {
                        dangky[1] = sv.hotensv;
                        break;
                    }
                }
                dangky[2] = dk.malop;
                dangky[3] = dk.monhoc;
                dangky[4] = dk.hocky.ToString();
                dangky[5] = dk.namhoc;

                ListViewItem item = new ListViewItem(dangky);
                dsdangkylv.Items.Add(item);
            }


            this.dsdangkylv.EndUpdate();
        }
    }
}
