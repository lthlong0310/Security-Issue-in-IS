﻿namespace UI
{
    partial class XemDanhSachSinhVienForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dssinhvienlv = new System.Windows.Forms.ListView();
            this.loplb = new System.Windows.Forms.Label();
            this.lopcb = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // dssinhvienlv
            // 
            this.dssinhvienlv.HideSelection = false;
            this.dssinhvienlv.Location = new System.Drawing.Point(46, 108);
            this.dssinhvienlv.Name = "dssinhvienlv";
            this.dssinhvienlv.Size = new System.Drawing.Size(708, 293);
            this.dssinhvienlv.TabIndex = 0;
            this.dssinhvienlv.UseCompatibleStateImageBehavior = false;
            // 
            // loplb
            // 
            this.loplb.AutoSize = true;
            this.loplb.Location = new System.Drawing.Point(43, 48);
            this.loplb.Name = "loplb";
            this.loplb.Size = new System.Drawing.Size(40, 20);
            this.loplb.TabIndex = 4;
            this.loplb.Text = "Lớp:";
            // 
            // lopcb
            // 
            this.lopcb.FormattingEnabled = true;
            this.lopcb.Location = new System.Drawing.Point(99, 45);
            this.lopcb.Name = "lopcb";
            this.lopcb.Size = new System.Drawing.Size(182, 28);
            this.lopcb.TabIndex = 3;
            this.lopcb.SelectedIndexChanged += new System.EventHandler(this.lopcb_SelectedIndexChanged);
            // 
            // XemDanhSachSinhVienForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.loplb);
            this.Controls.Add(this.lopcb);
            this.Controls.Add(this.dssinhvienlv);
            this.Name = "XemDanhSachSinhVienForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "XemDanhSachSinhVien";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView dssinhvienlv;
        private System.Windows.Forms.Label loplb;
        private System.Windows.Forms.ComboBox lopcb;
    }
}