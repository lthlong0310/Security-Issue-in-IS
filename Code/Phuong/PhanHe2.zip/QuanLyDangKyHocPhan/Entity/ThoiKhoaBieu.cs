﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entity
{
    public class ThoiKhoaBieu
    {
        public String malop { get; set; }
        public String mamonhoc { get; set; }
        public String tenmonhoc { get; set; }
        public int hocky { get; set; }
        public String namhoc { get; set; }
        public String phonghoc { get; set; }
        public String giaoviengiangday { get; set; }
        public int sotinchi { get; set; }
        public int sosvtoida { get; set; }
        public int sosvhientai { get; set; }

        public ThoiKhoaBieu() { }

        public ThoiKhoaBieu (String lop, String mamon, String tenmon, int hk, String nam, String phong, String gv, int tinchi, int svtoida, int svhientai)
        {
            malop = lop;
            mamonhoc = mamon;
            tenmonhoc = tenmon;
            hocky = hk;
            namhoc = nam;
            phonghoc = phong;
            giaoviengiangday = gv;
            sotinchi = tinchi;
            sosvtoida = svtoida;
            sosvhientai = svhientai;
        }

        public ThoiKhoaBieu(String lop, String mamon, String tenmon, int hk, String nam, String phong, String gv, int tinchi, int svtoida)
        {
            malop = lop;
            mamonhoc = mamon;
            tenmonhoc = tenmon;
            hocky = hk;
            namhoc = nam;
            phonghoc = phong;
            giaoviengiangday = gv;
            sotinchi = tinchi;
            sosvtoida = svtoida;
        }


    }
}
