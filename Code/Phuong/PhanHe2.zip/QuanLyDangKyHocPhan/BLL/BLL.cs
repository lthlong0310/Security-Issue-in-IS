﻿using System;
using System.Collections.Generic;
using System.Text;
using Entity;
using DAL;

namespace BLL
{
    public class BLL
    {
        public User Login(User current_user)
        {
            current_user = new DAL.DAL().Login(current_user);
            return current_user;
        }


        public List<Lop> LayDSLop(User current_user)
        {
            var dslop = new DAL.DAL().LayDSLopDB(current_user);
            return dslop;
        }

        //public List<GiaoVien> LayDSGiaovien(User current_user)
        //{
        //    var dsgvien = new DAL.DAL().LayDSGiaovienDB(current_user);
        //    return dsgvien;
        //}

        public List<TenMonHoc> LayDSTenMonHoc(User currrent_user)
        {
            List<TenMonHoc> tmh = new List<TenMonHoc>();
            DAL.DAL respon = new DAL.DAL();
            var ds_tenmonhoc = respon.LayDSTenMonHocDB(currrent_user);
            foreach(var ds in ds_tenmonhoc)
            {
                tmh.Add(ds);
            }
            return tmh;
        }

        public List<MonHoc> LayDSMonHoc(User currrent_user)
        {
            var dsmh = new DAL.DAL().LayDSMonHocDB(currrent_user);
            var dsbm = new DAL.DAL().LayDSBoMonDB(currrent_user);
            foreach(var mh in dsmh)
            {
                foreach (var bm in dsbm)
                    if (bm.mabomon == mh.bomon)
                        mh.bomon = bm.tenbomon;
            }
            return dsmh;
        }

        public List<GiaoVien> LayDSGiaoVienBoMon(User current_user, String bm)
        {
            var dsbm = new DAL.DAL().LayDSBoMonDB(current_user);
            foreach (var bomon in dsbm)
                if (bm == bomon.tenbomon)
                    bm = bomon.mabomon;
            
            var gvien = new DAL.DAL().LayDSGiaoVienBoMonDB(current_user, bm);
            return gvien;
        }

        public List<GiaoVien> LayDSTT_giaovien(User current_user)
        {
            List<GiaoVien> gv = new List<GiaoVien>();
            DAL.DAL respon = new DAL.DAL();
            var ds_gv = respon.LayDSGiaoVien_From_DB(current_user);
            foreach(var ds in ds_gv)
            {
                gv.Add(ds);
            }
            return gv;
        }

        public List<SinhVien> LayDSSinhVien(User current_user)
        {
            var dssv = new DAL.DAL().LayDSSinhVienDB(current_user);
            return dssv;
        }

        public List<SinhVien> LayDSSinhVien(User current_user, String lop)
        {
            var dssv = new DAL.DAL().LayDSSinhVienDB(current_user);
            int c = dssv.Count;
            for (int i = 0; i < c; i++)
            {
                var sv = dssv[i];
                if (sv.lopsv != lop)
                {
                    dssv.RemoveAt(i);
                    i--;
                    c--;
                }
            }
            return dssv;
        }

            public List<Diem> LayDSSinhVienDangky(User current_user)
        {
            var dsdangky = new DAL.DAL().LayDSSinhVienDangkyDB(current_user);
            var dsmonhoc = new DAL.DAL().LayDSMonHocDB(current_user);
            foreach (var dk in dsdangky)
            {
                foreach (var mon in dsmonhoc)
                {
                    if (dk.monhoc == mon.mamonhoc)
                        dk.monhoc = mon.tenmonhoc;
                }
            }
            return dsdangky;
        }

        public List<ThoiKhoaBieu> LayDSMonhocDuocmo(User current_user)
        {
            var dsmonduocmo = new DAL.DAL().LayDSMonhocDuocmoDB(current_user);
            return dsmonduocmo;
        }

        public List<ThoiKhoaBieu> LayDSMonhocDuocmo(User current_user, int hk, String nam)
        {
            var dsmonduocmo = new DAL.DAL().LayDSMonhocDuocmoDB(current_user);
            int c = dsmonduocmo.Count;
            for (int i = 0; i < c; i++)
            {
                var monduocmo = dsmonduocmo[i];
                if (hk > 0 && nam != "")
                {
                    if (monduocmo.hocky != hk || monduocmo.namhoc != nam)
                    {
                        dsmonduocmo.RemoveAt(i);
                        i--;
                        c--;
                    }
                }
                else if (hk > 0 && nam == "")
                {
                    if (monduocmo.hocky != hk)
                    {
                        dsmonduocmo.RemoveAt(i);
                        i--;
                        c--;
                    }
                }
                else if (hk <= 0 && nam != "")
                {
                    if (monduocmo.namhoc != nam)
                    {
                        dsmonduocmo.RemoveAt(i);
                        i--;
                        c--;
                    }
                }
            }
            return dsmonduocmo;
        }

        public bool DangkyHocphan (User current_user, ThoiKhoaBieu hp)
        {
            var dangky = new DAL.DAL().DangkyHocphanDB(current_user, hp);
            return dangky;
        }

        public bool HuyDangkyHocphan(User current_user, ThoiKhoaBieu hp)
        {
            var huydangky = new DAL.DAL().HuyDangkyHocphanDB(current_user, hp);
            return huydangky;
        }

        public bool MoHocPhanDangky(User current_user, ThoiKhoaBieu hp)
        {
            var dsgvien = new DAL.DAL().LayDSGiaoVienDB(current_user);
            foreach(var gv in dsgvien)
            {
                if (gv.tengv == hp.giaoviengiangday)
                    hp.giaoviengiangday = gv.magv;
            }
            var momonhoc = new DAL.DAL().MoHocphanDB(current_user, hp);
            return momonhoc;
        }

        public bool HuyMoHocPhanDangky(User current_user, ThoiKhoaBieu hp)
        {
            
            var huymomonhoc = new DAL.DAL().HuyMoHocphanDB(current_user, hp);
            return huymomonhoc;
        }

        public bool MoDangky(User current_user)
        {
            var modangky = new DAL.DAL().MoDangkyDB(current_user);
            return modangky;
        }

        public bool DongDangky(User current_user)
        {
            var dongdangky = new DAL.DAL().DongDangkyDB(current_user);
            return dongdangky;
        }

        public List<Diem> LayDSSinhVienDangky(User current_user, String mon, String lop, int hk, String nam)
        {
            var dsdangky = new DAL.DAL().LayDSSinhVienDangkyDB(current_user);
            var dsmonhoc = new DAL.DAL().LayDSMonHocDB(current_user);
            foreach (var dk in dsdangky)
            {
                foreach(var mh in dsmonhoc)
                {
                    if (dk.monhoc == mh.mamonhoc)
                        dk.monhoc = mh.tenmonhoc;
                }
            }
            int c = dsdangky.Count;
            for (int i = 0; i < c; i++)
            {
                var dangky = dsdangky[i];
                if (hk > 0 && nam != "" && mon != "" && lop != "")
                {
                    if (dangky.hocky != hk || dangky.namhoc != nam || dangky.monhoc != mon || dangky.malop != lop)
                    {
                        dsdangky.RemoveAt(i);
                        i--;
                        c--;
                    }
                }
                else if (hk > 0 && nam == "" && mon != "" && lop != "")
                {
                    if (dangky.hocky != hk || dangky.monhoc != mon || dangky.malop != lop)
                    {
                        dsdangky.RemoveAt(i);
                        i--;
                        c--;
                    }
                }
                else if (hk > 0 && nam != "" && mon == "" && lop != "")
                {
                    if (dangky.hocky != hk || dangky.namhoc != nam || dangky.malop != lop)
                    {
                        dsdangky.RemoveAt(i);
                        i--;
                        c--;
                    }
                }
                else if (hk > 0 && nam != "" && mon != "" && lop == "")
                {
                    if (dangky.hocky != hk || dangky.namhoc != nam || dangky.monhoc != mon)
                    {
                        dsdangky.RemoveAt(i);
                        i--;
                        c--;
                    }
                }
                else if (hk <= 0 && nam != "" && mon != "" && lop != "")
                {
                    if (dangky.namhoc != nam || dangky.monhoc != mon || dangky.malop != lop)
                    {
                        dsdangky.RemoveAt(i);
                        i--;
                        c--;
                    }
                }
                else if (hk <= 0 && nam == "" && mon != "" && lop != "")
                {
                    if (dangky.monhoc != mon || dangky.malop != lop)
                    {
                        dsdangky.RemoveAt(i);
                        i--;
                        c--;
                    }
                }
                else if (hk <= 0 && nam != "" && mon == "" && lop != "")
                {
                    if (dangky.namhoc != nam || dangky.malop != lop)
                    {
                        dsdangky.RemoveAt(i);
                        i--;
                        c--;
                    }
                }
                else if (hk <= 0 && nam != "" && mon != "" && lop == "")
                {
                    if (dangky.namhoc != nam || dangky.monhoc != mon)
                    {
                        dsdangky.RemoveAt(i);
                        i--;
                        c--;
                    }
                }
                else if (hk > 0 && nam == "" && mon == "" && lop != "")
                {
                    if (dangky.hocky != hk || dangky.malop != lop)
                    {
                        dsdangky.RemoveAt(i);
                        i--;
                        c--;
                    }
                }
                else if (hk > 0 && nam == "" && mon != "" && lop == "")
                {
                    if (dangky.hocky != hk || dangky.monhoc != mon)
                    {
                        dsdangky.RemoveAt(i);
                        i--;
                        c--;
                    }
                }
                else if (hk > 0 && nam != "" && mon == "" && lop == "")
                {
                    if (dangky.hocky != hk || dangky.namhoc != nam)
                    {
                        dsdangky.RemoveAt(i);
                        i--;
                        c--;
                    }
                }
                else if (hk <= 0 && nam == "" && mon == "" && lop != "")
                {
                    if (dangky.malop != lop)
                    {
                        dsdangky.RemoveAt(i);
                        i--;
                        c--;
                    }
                }
                else if (hk <= 0 && nam == "" && mon != "" && lop == "")
                {
                    if (dangky.monhoc != mon)
                    {
                        dsdangky.RemoveAt(i);
                        i--;
                        c--;
                    }
                }
                else if (hk <= 0 && nam != "" && mon == "" && lop == "")
                {
                    if (dangky.namhoc != nam)
                    {
                        dsdangky.RemoveAt(i);
                        i--;
                        c--;
                    }
                }
                else if (hk > 0 && nam == "" && mon == "" && lop == "")
                {
                    if (dangky.hocky != hk)
                    {
                        dsdangky.RemoveAt(i);
                        i--;
                        c--;
                    }
                }
            }
            return dsdangky;
        }

        public List<Diem> LayDSMonDaDangky(User current_user, int hk, String nam)
        {
            var dsdangky = new DAL.DAL().LayDSSinhVienDangkyDB(current_user);
            int c = dsdangky.Count;
            for (int i = 0; i < c; i++)
            {
                var dangky = dsdangky[i];
                if (hk > 0 && nam != "")
                {
                    if (dangky.hocky != hk || dangky.namhoc != nam)
                    {
                        dsdangky.RemoveAt(i);
                        i--;
                        c--;
                    }
                }
                else if (hk > 0 && nam == "")
                {
                    if (dangky.hocky != hk)
                    {
                        dsdangky.RemoveAt(i);
                        i--;
                        c--;
                    }
                }
                else if (hk <= 0 && nam != "")
                {
                    if (dangky.namhoc != nam)
                    {
                        dsdangky.RemoveAt(i);
                        i--;
                        c--;
                    }
                }
            }
            return dsdangky;
        }
    }
}
