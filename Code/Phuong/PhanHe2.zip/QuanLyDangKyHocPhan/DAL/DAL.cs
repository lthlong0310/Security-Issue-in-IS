﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using Entity;
using Oracle.ManagedDataAccess.Client;

namespace DAL
{
    public class DAL
    {
        public OracleConnection Connect(User current_user)
        {
            //Create a connection String to Oracle
            //string connectionString = "User Id=ot; password=yourpassword;" +

            //Connect Format is [hostname]:[port]/[service_name]
            //"Data Source=localhost:1521/xe; Pooling=false;";
            OracleConnection con = new OracleConnection();
            OracleConnectionStringBuilder cnstr = new OracleConnectionStringBuilder();
            cnstr.UserID = current_user.username;
            cnstr.Password = current_user.password;
            cnstr.DataSource = "localhost:1521/xe";
            //con.ConnectionString = connectionString;
            con.ConnectionString = cnstr.ConnectionString;
            return con;
        }

        public User Login(User current_user)
        {
            OracleConnection conn = new OracleConnection();
            conn = Connect(current_user);
            try
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand();
                cmd.Connection = conn;
                cmd.CommandText = $"select usertype from sec_admin.taikhoan where username = :usn";
                cmd.Parameters.Add(new OracleParameter("usn", current_user.username));
                var er = cmd.ExecuteReader();
                er.Read();
                current_user.usertype = er.GetString(0);
                conn.Close();
                return current_user;
            }
            catch(OracleException)
            {
                conn.Close();
                return current_user;
            }
            finally
            {
                conn.Close();
                
            }
        }

        public List<Lop> LayDSLopDB(User current_user)
        {
            OracleConnection conn = new OracleConnection();
            conn = Connect(current_user);
            List<Lop> dslop = new List<Lop>();
            try
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand();
                cmd.Connection = conn;
                cmd.CommandText = $"Select * from sec_admin.lop";

                var er = cmd.ExecuteReader();
                
                while(er.Read())
                {
                    String malop;
                    if (er.IsDBNull(0))
                        malop = "";
                    else malop = er.GetString(0);
                    String tenlop;
                    if (er.IsDBNull(1))
                        tenlop = "";
                    else tenlop = er.GetString(1);

                    var lop = new Lop(malop, tenlop);
                    dslop.Add(lop);
                }
                conn.Close();
                return dslop;
            }
            catch
            {
                conn.Close();
                return dslop;
            }
            finally
            {
                conn.Close();
            }
        }

        public List<BoMon> LayDSBoMonDB(User current_user)
        {
            OracleConnection conn = new OracleConnection();
            conn = Connect(current_user);
            List<BoMon> dsbm = new List<BoMon>();
            try
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand();
                cmd.Connection = conn;
                cmd.CommandText = $"Select * from sec_admin.bomon";

                var er = cmd.ExecuteReader();

                while (er.Read())
                {
                    String mabm;
                    if (er.IsDBNull(0))
                        mabm = "";
                    else mabm = er.GetString(0);
                    String tenbm;
                    if (er.IsDBNull(1))
                        tenbm = "";
                    else tenbm = er.GetString(1);

                    var bm = new BoMon(mabm, tenbm);
                    dsbm.Add(bm);
                }
                conn.Close();
                return dsbm;
            }
            catch
            {
                conn.Close();
                return dsbm;
            }
            finally
            {
                conn.Close();
            }
        }

        //public List<GiaoVien> LayDSGiaovienDB(User current_user)
        //{
        //    OracleConnection conn = new OracleConnection();
        //    conn = Connect(current_user);
        //    List<GiaoVien> dsgvien = new List<GiaoVien>();
        //    try
        //    {
        //        conn.Open();
        //        OracleCommand cmd = new OracleCommand();
        //        cmd.Connection = conn;
        //        cmd.CommandText = $"Select * from sec_admin.lop where loaigiaovien = '0'";

        //        var er = cmd.ExecuteReader();

        //        while (!er.Read())
        //        {
        //            String magiaovien;
        //            if (!er.IsDBNull(0))
        //                magiaovien = "";
        //            else magiaovien = er.GetString(0);
        //            String tengiaovien;
        //            if (!er.IsDBNull(1))
        //                tengiaovien = "";
        //            else tengiaovien = er.GetString(1);
        //            String dob;
        //            if (!er.IsDBNull(2))
        //                dob = null;
        //            else dob = er.GetDateTime(2).ToString();
        //            String dchi;
        //            if (!er.IsDBNull(2))
        //                dchi = "";
        //            else dchi = er.GetString(2);
        //            String gt;
        //            if (!er.IsDBNull(3))
        //                gt = "";
        //            else gt = er.GetString(3);
        //            String cmnd;
        //            if (!er.IsDBNull(4))
        //                cmnd = "";
        //            else cmnd = er.GetString(4);
        //            String sdt;
        //            if (!er.IsDBNull(5))
        //                sdt = "";
        //            else sdt = er.GetString(5);
        //            String email;
        //            if (!er.IsDBNull(6))
        //                email = "";
        //            else email = er.GetString(6);
        //            String bomon;
        //            if (!er.IsDBNull(7))
        //                bomon = "";
        //            else bomon = er.GetString(7);
        //            String trgbm;
        //            if (!er.IsDBNull(8))
        //                trgbm = "";
        //            else trgbm = er.GetString(8);

        //            var gvien = new GiaoVien(magiaovien, tengiaovien, dob, dchi, gt, cmnd, sdt, email, bomon, trgbm);
        //            dsgvien.Add(gvien);
        //        }
        //        conn.Close();
        //        return dsgvien;
        //    }
        //    catch(OracleException)
        //    {
        //        conn.Close();
        //        return dsgvien;
        //    }
        //    finally
        //    {
        //        conn.Close();
        //    }
        //}

        public List<TenMonHoc> LayDSTenMonHocDB(User current_user)
        {
            OracleConnection conn = new OracleConnection();
            conn = Connect(current_user);
            List<TenMonHoc> dsmonhoc_duocmo = new List<TenMonHoc>();
            try
            {
                conn.Open();
                OracleCommand orc = new OracleCommand();
                orc.Connection = conn;
                orc.CommandText = "select * from sec_admin.monhocduocmo";
                var er = orc.ExecuteReader();
                while (er.Read())
                {
                    dsmonhoc_duocmo.Add(new TenMonHoc(er.GetString(0)));
                }
                conn.Close();
                return dsmonhoc_duocmo;
            }
            catch(OracleException)
            {
                conn.Close();
                return dsmonhoc_duocmo;
            }
            finally
            {
                conn.Close();
            }
        }

        public List<MonHoc> LayDSMonHocDB(User current_user)
        {
            OracleConnection conn = new OracleConnection();
            conn = Connect(current_user);
            List<MonHoc> dsmonhoc = new List<MonHoc>();
            try
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand();
                cmd.Connection = conn;
                cmd.CommandText = $"select * from sec_admin.monhoc";
                var er = cmd.ExecuteReader();
                while (er.Read())
                {
                    String ma;
                    if (er.IsDBNull(0))
                        ma = "";
                    else ma = er.GetString(0);
                    String ten;
                    if (er.IsDBNull(1))
                        ten = "";
                    else ten = er.GetString(1);
                    String bm;
                    if (er.IsDBNull(2))
                        bm = "";
                    else bm = er.GetString(2);
                    int tc;
                    if (er.IsDBNull(3))
                        tc = -1;
                    else tc = er.GetInt32(3);
                    dsmonhoc.Add(new MonHoc(ma, ten, bm, tc));
                }
                conn.Close();
                return dsmonhoc;
            }
            catch(OracleException)
            {
                conn.Close();
                return dsmonhoc;
            }
            finally
            {
                conn.Close();
            }
        }


        public List<GiaoVien> LayDSGiaoVien_From_DB(User current_user)
        {
            OracleConnection conn = new OracleConnection();
            conn = Connect(current_user);
            List<GiaoVien> dsgv = new List<GiaoVien>();
            try
            {
                conn.Open();
                OracleCommand orc = new OracleCommand();
                orc.Connection = conn;
                orc.CommandText = "select * from sec_admin.giaovien";
                var er = orc.ExecuteReader();
                while (er.Read())
                {
                    dsgv.Add(new GiaoVien(er.GetString(0), er.GetString(1), er.GetString(2), er.GetString(3), er.GetString(4), er.GetString(5), er.GetString(6), er.GetString(7), er.GetString(8), er.GetString(9), er.GetString(10)));
                }
                conn.Close();
                return dsgv;
            }
            catch(OracleException)
            {
                conn.Close();
                return dsgv;
            }
            finally
            {
                conn.Close();
            }
        }


        public List<GiaoVien> LayDSGiaoVienBoMonDB(User current_user, String bm)
        {
            OracleConnection conn = new OracleConnection();
            conn = Connect(current_user);
            List<GiaoVien> dsgv = new List<GiaoVien>();
            try
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand();
                cmd.Connection = conn;
                cmd.CommandText = "select * from sec_admin.giaovien where mabomon = :bm";
                cmd.Parameters.Add(new OracleParameter("bm", bm));
                var er = cmd.ExecuteReader();
                while (er.Read())
                {
                    String ma;
                    if (er.IsDBNull(0))
                        ma = "";
                    else ma = er.GetString(0);
                    String ten;
                    if (er.IsDBNull(1))
                        ten = "";
                    else ten = er.GetString(1);
                    String mon;
                    if (er.IsDBNull(8))
                        mon = "";
                    else mon = er.GetString(8);
                    dsgv.Add(new GiaoVien(ma, ten, mon));
                }
                conn.Close();
                return dsgv;
            }
            catch (OracleException)
            {
                conn.Close();
                return dsgv;
            }
            finally
            {
                conn.Close();
            }
        }

        public List<GiaoVien> LayDSGiaoVienDB(User current_user)
        {
            OracleConnection conn = new OracleConnection();
            conn = Connect(current_user);
            List<GiaoVien> dsgv = new List<GiaoVien>();
            try
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand();
                cmd.Connection = conn;
                cmd.CommandText = "select * from sec_admin.giaovien";
                var er = cmd.ExecuteReader();
                while (er.Read())
                {
                    String ma;
                    if (er.IsDBNull(0))
                        ma = "";
                    else ma = er.GetString(0);
                    String ten;
                    if (er.IsDBNull(1))
                        ten = "";
                    else ten = er.GetString(1);
                    String mon;
                    if (er.IsDBNull(8))
                        mon = "";
                    else mon = er.GetString(8);
                    dsgv.Add(new GiaoVien(ma, ten, mon));
                }
                conn.Close();
                return dsgv;
            }
            catch (OracleException)
            {
                conn.Close();
                return dsgv;
            }
            finally
            {
                conn.Close();
            }
        }

        public List<SinhVien> LayDSSinhVienDB(User current_user)
        {
            OracleConnection conn = new OracleConnection();
            conn = Connect(current_user);
            List<SinhVien> dssv = new List<SinhVien>();
            try
            {
                conn.Open();
                OracleCommand orc = new OracleCommand();
                orc.Connection = conn;
                orc.CommandText = "select * from sec_admin.sinhvien";
                var er = orc.ExecuteReader();
                while (er.Read())
                {
                    String mssv;
                    if (er.IsDBNull(0))
                        mssv = "";
                    else mssv = er.GetString(0);
                    String ten;
                    if (er.IsDBNull(1))
                        ten = "";
                    else ten = er.GetString(1);
                    String lop;
                    if (er.IsDBNull(2))
                        lop = "";
                    else lop = er.GetString(2);

                    dssv.Add(new SinhVien(mssv, ten, lop));
                }
                conn.Close();
                return dssv;
            }
            catch (OracleException)
            {
                conn.Close();
                return dssv;
            }
            finally
            {
                conn.Close();
            }
        }
        public List<Diem> LayDSSinhVienDangkyDB(User current_user)
        {
            OracleConnection conn = new OracleConnection();
            conn = Connect(current_user);
            List<Diem> dssvdangky = new List<Diem>();
            try
            {
                conn.Open();
                OracleCommand orc = new OracleCommand();
                orc.Connection = conn;
                orc.CommandText = "select * from sec_admin.dangky";
                var er = orc.ExecuteReader();
                while (er.Read())
                {
                    String mssv;
                    if (er.IsDBNull(0))
                        mssv = "";
                    else mssv = er.GetString(0);
                    String lop;
                    if (er.IsDBNull(1))
                        lop = "";
                    else lop = er.GetString(1);
                    String mon;
                    if (er.IsDBNull(2))
                        mon = "";
                    else mon = er.GetString(2);
                    int hk;
                    if (er.IsDBNull(3))
                        hk = -1;
                    else hk = er.GetInt32(3);
                    String nam;
                    if (er.IsDBNull(4))
                        nam = "";
                    else nam = er.GetString(4).Trim();

                    dssvdangky.Add(new Diem(mssv, lop, mon, hk, nam));
                }
                conn.Close();
                return dssvdangky;
            }
            catch (OracleException)
            {
                conn.Close();
                return dssvdangky;
            }
            finally
            {
                conn.Close();
            }
        }
        public List<ThoiKhoaBieu> LayDSMonhocDuocmoDB(User current_user)
        {
            List<ThoiKhoaBieu> dsmonduocmo = new List<ThoiKhoaBieu>();
            OracleConnection conn = new OracleConnection();
            conn = Connect(current_user);
            try
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand();
                cmd.Connection = conn;
                cmd.CommandText = $"select * from sec_admin.monhocduocmo";

                var er = cmd.ExecuteReader();
                while (er.Read())
                {
                    String malop;
                    if (er.IsDBNull(0))
                        malop = "";
                    else malop = er.GetString(0);
                    String mamon;
                    if (er.IsDBNull(1))
                        mamon = "";
                    else mamon = er.GetString(1);
                    String tenmon;
                    if (er.IsDBNull(2))
                        tenmon = "";
                    else tenmon = er.GetString(2);
                    int hk;
                    if (er.IsDBNull(3))
                        hk = -1;
                    else hk = er.GetInt32(3);
                    String nam;
                    if (er.IsDBNull(4))
                        nam = "";
                    else nam = er.GetString(4).Trim();
                    String phong;
                    if (er.IsDBNull(5))
                        phong = "";
                    else phong = er.GetString(5);
                    String gv;
                    if (er.IsDBNull(6))
                        gv = "";
                    else gv = er.GetString(6);
                    int tinchi;
                    if (er.IsDBNull(7))
                        tinchi = -1;
                    else tinchi = er.GetInt32(7);
                    int svtoida;
                    if (er.IsDBNull(8))
                        svtoida = -1;
                    else svtoida = er.GetInt32(8);
                    int svhientai;
                    if (er.IsDBNull(9))
                        svhientai = -1;
                    else svhientai = er.GetInt32(9);

                    dsmonduocmo.Add(new ThoiKhoaBieu(malop, mamon, tenmon, hk, nam, phong, gv, tinchi, svtoida, svhientai));
                }

                conn.Close();
                return dsmonduocmo;
            }
            catch(OracleException)
            {
                conn.Close();
                return dsmonduocmo;
            }
            finally
            {
                conn.Close();
            }

        }

        public bool DangkyHocphanDB (User current_user, ThoiKhoaBieu hp)
        {
            OracleConnection conn = new OracleConnection();
            conn = Connect(current_user);
            try
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand();
                cmd.Connection = conn;
                cmd.CommandText = $"insert into sec_admin.dangky (mssv, malop, mamonhoc, hocky, namhoc) values (:id, :lop, :mon, :hk, :nam)";
                cmd.Parameters.Add(new OracleParameter("id", current_user.username));
                cmd.Parameters.Add(new OracleParameter("lop", hp.malop));
                cmd.Parameters.Add(new OracleParameter("mon", hp.mamonhoc));
                cmd.Parameters.Add(new OracleParameter("hk", hp.hocky));
                cmd.Parameters.Add(new OracleParameter("nam", hp.namhoc));
                var en = cmd.ExecuteNonQuery();

                conn.Close();
                return en == 1;
            }
            catch (OracleException)
            {
                conn.Close();
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public bool HuyDangkyHocphanDB(User current_user, ThoiKhoaBieu hp)
        {
            OracleConnection conn = new OracleConnection();
            conn = Connect(current_user);
            try
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand();
                cmd.Connection = conn;
                cmd.CommandText = $"delete from sec_admin.dangky where mssv = :id and malop = :lop and mamonhoc = :mon and hocky = :hk and namhoc = :nam";
                cmd.Parameters.Add(new OracleParameter("id", current_user.username));
                cmd.Parameters.Add(new OracleParameter("lop", hp.malop));
                cmd.Parameters.Add(new OracleParameter("mon", hp.mamonhoc));
                cmd.Parameters.Add(new OracleParameter("hk", hp.hocky));
                cmd.Parameters.Add(new OracleParameter("nam", hp.namhoc));
                var en = cmd.ExecuteNonQuery();

                conn.Close();
                return en == 1;
            }
            catch (OracleException)
            {
                conn.Close();
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public bool MoHocphanDB(User current_user, ThoiKhoaBieu hp)
        {
            OracleConnection conn = new OracleConnection();
            conn = Connect(current_user);
            try
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand();
                cmd.Connection = conn;
                cmd.CommandText = $"insert into sec_admin.thoikhoabieu (malop, mamonhoc, hocky, namhoc, phonghoc, giaoviengiangday, sosinhvientoida) values (:lop, :mon, :hk, :nam, :phong, :gvien, :svtoida)";
                cmd.Parameters.Add(new OracleParameter("lop", hp.malop));
                cmd.Parameters.Add(new OracleParameter("mon", hp.mamonhoc));
                cmd.Parameters.Add(new OracleParameter("hk", hp.hocky));
                cmd.Parameters.Add(new OracleParameter("nam", hp.namhoc));
                if (hp.phonghoc != "")
                    cmd.Parameters.Add(new OracleParameter("phong", hp.phonghoc));
                else cmd.Parameters.Add(new OracleParameter("phong", DBNull.Value)); 
                if (hp.giaoviengiangday != "")
                    cmd.Parameters.Add(new OracleParameter("gvien", hp.giaoviengiangday));
                else cmd.Parameters.Add(new OracleParameter("gvien", DBNull.Value));
                if (hp.sosvtoida != -1)
                    cmd.Parameters.Add(new OracleParameter("svtoida", hp.sosvtoida));
                else cmd.Parameters.Add(new OracleParameter("svtoida", DBNull.Value));
                var en = cmd.ExecuteNonQuery();

                conn.Close();
                return en == 1;
            }
            catch (OracleException)
            {
                conn.Close();
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public bool HuyMoHocphanDB(User current_user, ThoiKhoaBieu hp)
        {
            OracleConnection conn = new OracleConnection();
            conn = Connect(current_user);
            try
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand();
                cmd.Connection = conn;
                cmd.CommandText = $"delete from sec_admin.thoikhoabieu where malop = :lop and mamonhoc = :mon and hocky = :hk  and namhoc = :nam";
                cmd.Parameters.Add(new OracleParameter("lop", hp.malop));
                cmd.Parameters.Add(new OracleParameter("mon", hp.mamonhoc));
                cmd.Parameters.Add(new OracleParameter("hk", hp.hocky));
                cmd.Parameters.Add(new OracleParameter("nam", hp.namhoc));
                var en = cmd.ExecuteNonQuery();

                conn.Close();
                return en == 1;
            }
            catch (OracleException)
            {
                conn.Close();
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public bool MoDangkyDB(User current_user)
        {
            OracleConnection conn = new OracleConnection();
            conn = Connect(current_user);
            try
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand();
                cmd.Connection = conn;
                cmd.CommandText = $"grant select on sec_admin.monhocduocmo to svien";
                var en = cmd.ExecuteNonQuery();
                cmd.CommandText = $"grant select on sec_admin.dangky to svien";
                en = cmd.ExecuteNonQuery();
                cmd.CommandText = $"grant insert on sec_admin.dangky to svien";
                en = cmd.ExecuteNonQuery();
                cmd.CommandText = $"grant delete on sec_admin.dangky to svien";
                en = cmd.ExecuteNonQuery();
                conn.Close();
                return true;
            }
            catch (OracleException)
            {
                conn.Close();
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public bool DongDangkyDB(User current_user)
        {
            OracleConnection conn = new OracleConnection();
            conn = Connect(current_user);
            try
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand();
                cmd.Connection = conn;
                cmd.CommandText = $"revoke select on sec_admin.monhocduocmo from svien";
                var en = cmd.ExecuteNonQuery();
                cmd.CommandText = $"revoke select on sec_admin.dangky from svien";
                en = cmd.ExecuteNonQuery();
                cmd.CommandText = $"revoke insert on sec_admin.dangky from svien";
                en = cmd.ExecuteNonQuery();
                cmd.CommandText = $"revoke delete on sec_admin.dangky from svien";
                en = cmd.ExecuteNonQuery();
                conn.Close();
                return true;
            }
            catch (OracleException)
            {
                conn.Close();
                return false;
            }
            finally
            {
                conn.Close();
            }
        }


        /*public List<Diem> LayDSDangkyDB(User current_user)
        {

            List<Diem> dssvdangky = new List<Diem>();
            OracleConnection conn = new OracleConnection();
            conn = Connect(current_user);
            try
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand();
                cmd.Connection = conn;
                cmd.CommandText = $"select * from sec_admin.dangky";

                var er = cmd.ExecuteReader();
                while (er.Read())
                {
                    String mssv;
                    if (er.IsDBNull(0))
                        mssv = "";
                    else mssv = er.GetString(0);
                    String malop;
                    if (er.IsDBNull(1))
                        malop = "";
                    else malop = er.GetString(1);
                    String mamon;
                    if (er.IsDBNull(2))
                        mamon = "";
                    else mamon = er.GetString(2);
                    int hk;
                    if (er.IsDBNull(3))
                        hk = -1;
                    else hk = er.GetInt32(3);
                    String nam;
                    if (er.IsDBNull(4))
                        nam = "";
                    else nam = er.GetString(4).Trim();
                    

                    dssvdangky.Add(new Diem(mssv, malop, mamon, hk, nam));
                }

                conn.Close();
                return dssvdangky;
            }
            catch (OracleException)
            {
                conn.Close();
                return dssvdangky;
            }
            finally
            {
                conn.Close();
            }
        }*/
    }
}
