alter session set "_ORACLE_SCRIPT"=true;
/

create user sec_admin identified by sec_admin
        default tablespace users
        TEMPORARY TABLESPACE temp
        Quota 10M on users;
/

create user sec_mgr identified by sec_mgr
        default tablespace users
        TEMPORARY TABLESPACE temp
        Quota 10M on users;
/
        
grant create session, dba to sec_admin;
/

grant create session , dba to sec_mgr;
/

--

--User : SinhVien
create user sv1 identified by sv1
        default tablespace users
        TEMPORARY TABLESPACE temp
        Quota 10M on users;
/

create user sv2 identified by sv2
        default tablespace users
        TEMPORARY TABLESPACE temp
        Quota 10M on users;
/

create user sv3 identified by sv3
        default tablespace users
        TEMPORARY TABLESPACE temp
        Quota 10M on users;
/

create user sv4 identified by sv4
        default tablespace users
        TEMPORARY TABLESPACE temp
        Quota 10M on users;
/

create user sv5 identified by sv5
        default tablespace users
        TEMPORARY TABLESPACE temp
        Quota 10M on users;
/
--User: GiaoVu

create user gvu_ntmthu identified by gvu_ntmthu
        default tablespace users
        TEMPORARY TABLESPACE temp
        Quota 10M on users;

--User: GiaoVien
create user gvktpm_lbluan identified by lbluan
        default tablespace users
        TEMPORARY TABLESPACE temp
        Quota 10M on users;

create user gvhttt_nahoang identified by nahoang
        default tablespace users
        TEMPORARY TABLESPACE temp
        Quota 10M on users;

create user gvkhmt_ltlinh identified by ltlinh
        default tablespace users
        TEMPORARY TABLESPACE temp
        Quota 10M on users;

-----Phan quyen cho sec_mgr de tao chinh sach cho cac bang cua sec_admin - con loi
--grant select on sec_admin.bomon to sec_mgr with grant option;
--/
--grant select on sec_admin.diem to sec_mgr with grant option;
--/
--grant select on sec_admin.giaovien to sec_mgr with grant option;
--/
--grant select on sec_admin.lop to sec_mgr with grant option;
--/
--grant select on sec_admin.monhoc to sec_mgr with grant option;
--/
--grant select on sec_admin.sinhvien to sec_mgr with grant option;
--/
--grant select on sec_admin.taikhoan to sec_mgr with grant option;
--/
--grant select on sec_admin.thoikhoabieu to sec_mgr with grant option;
--/
--grant select on sec_admin.thongbao to sec_mgr with grant option;
--/



create role svien;
/

create role gvien;
/

create role gvu;
/

create role trgbm;
/

create role trgkhoa;
/



--Tai khoan
insert into taikhoan values ('sv1', 'svien');
/
insert into taikhoan values ('sv2', 'svien');
/
insert into taikhoan values ('sv3', 'svien');
/
insert into taikhoan values ('sv4', 'svien');
/
insert into taikhoan values ('sv5', 'svien');
/
insert into taikhoan values ('gvktpm_lbluan', 'gvien');
/
insert into taikhoan values ('gvhttt_nahoang', 'gvien');
/
insert into taikhoan values ('gvkhmt_ltlinh', 'gvien');
/
insert into taikhoan values ('gvu_ntmthu', 'gvu');
/
---Lop
insert into Lop values('17CLC', 'Chat luong cao');
insert into Lop values('17VP', 'Viet phap');
--BoMon
insert into bomon values('httt', N'He thong thong tin', NULL);
insert into bomon values('ktpm', N'Ky thuat phan mem', NULL);
insert into bomon values('khmt', N'Khoa hoc may tinh', NULL);
--
---GiaoVien
insert into Giaovien values('gvhttt_nahoang', N'Nguyen Anh Hoang', to_date('02-11-1960', 'dd-mm-yyyy'),N'332 Nguyen Thai Hoc, Tp HCM', 'Nam', '123456781', '987654321', 'hoang@gmail.com', 'httt', '0', '1' );
insert into GiaoVien values('gvu_ntmthu', N'Nguyen Tuan My Thu', to_date('08-02-1962','dd-mm-yyyy'), N'80 Le Hong Phong, Tp HCM', 'Nam', '123456123', '987654322', 'khai@gmail.com', NULL, '0', '0');
insert into GiaoVien values('gvktpm_lbluan', N'Ly Ba Luan', to_date('02-01-1967','dd-mm-yyyy'), N'34 Mai Thi Lu, Tp HCM', 'Nam', '123456124', '987654323', 'luan@gmail.com', 'ktpm', '0', '1');
insert into GiaoVien values('gvkhmt_ltlinh', N'Ly Tu Linh', to_date('03-04-1967','dd-mm-yyyy'), N'95 Ba ria Vung Tau', 'Nam', '123456125', '987654324', 'linh@gmail.com', 'khmt', '0', '1');
---Mon hoc
insert into monhoc values('CSC1',	'An toan bao mat', 'httt', 	4);
insert into monhoc values('CSC2','Ky thuat lap trinh',	'ktpm',	5);
insert into monhoc values('CSC3','Nhap mon lap trinh','ktpm',4);
insert into monhoc values('CSC4','He thong nhung','khmt',	4);
insert into thoikhoabieu values('17CLC',	'CSC1',	1,	'2019','I.12', 'gvhttt_nahoang',	30);
insert into thoikhoabieu values('17CLC',	'CSC2'	,1,	'2019','I.13','gvktpm_lbluan', 30);
insert into thoikhoabieu values('17CLC',	'CSC1',	2,	'2020','I.12', 'gvhttt_nahoang',	30);
insert into thoikhoabieu values('17CLC',	'CSC2'	,2,	'2020','I.13','gvktpm_lbluan', 30);
insert into thoikhoabieu values('17CLC',	'CSC1',	3,	'2020','I.12', 'gvhttt_nahoang',	30);
insert into thoikhoabieu values('17CLC',	'CSC2'	,3,	'2020','I.13','gvktpm_lbluan', 30);

insert into sinhvien (mssv, lop) values ('sv1', '17CLC');
insert into sinhvien (mssv, lop) values ('sv2', '17CLC');
insert into sinhvien (mssv, lop) values ('sv3', '17CLC');
insert into sinhvien (mssv, lop) values ('sv4', '17CLC');
insert into sinhvien (mssv, lop) values ('sv5', '17CLC');

insert into diem (mssv, malop, mamonhoc, hocky, namhoc) values ('sv1', '17CLC',	'CSC1',	1,	'2019');
insert into diem (mssv, malop, mamonhoc, hocky, namhoc) values ('sv2', '17CLC',	'CSC1',	1,	'2019');
insert into diem (mssv, malop, mamonhoc, hocky, namhoc) values ('sv3', '17CLC',	'CSC1',	1,	'2019');
insert into diem (mssv, malop, mamonhoc, hocky, namhoc) values ('sv4', '17CLC',	'CSC1',	1,	'2019');
insert into diem (mssv, malop, mamonhoc, hocky, namhoc) values ('sv5', '17CLC',	'CSC1',	1,	'2019');
insert into diem (mssv, malop, mamonhoc, hocky, namhoc) values ('sv1', '17CLC',	'CSC2',	1,	'2019');
insert into diem (mssv, malop, mamonhoc, hocky, namhoc) values ('sv2', '17CLC',	'CSC2',	1,	'2019');
insert into diem (mssv, malop, mamonhoc, hocky, namhoc) values ('sv3', '17CLC',	'CSC2',	1,	'2019');
insert into diem (mssv, malop, mamonhoc, hocky, namhoc) values ('sv1', '17CLC',	'CSC2',	2,	'2020');
insert into diem (mssv, malop, mamonhoc, hocky, namhoc) values ('sv2', '17CLC',	'CSC2',	3,	'2020');
insert into diem (mssv, malop, mamonhoc, hocky, namhoc) values ('sv3', '17CLC',	'CSC2',	3,	'2020');
/



--Phan quyen co ban - chi tinh cac quyen can thiet cho cac chuc nang day lam, khong phai toan bo
grant connect to svien, gvien, gvu, trgbm, trgkhoa;
/
grant select on sec_admin.taikhoan to svien, gvien, gvu, trgbm, trgkhoa;
/
grant svien to sv1, sv2, sv3, sv4, sv5;
/
grant gvien to gvktpm_lbluan, gvhttt_nahoang, gvkhmt_ltlinh;
/
grant gvu to gvu_ntmthu;
/

grant select on sec_admin.lop to gvu;
/
grant select on sec_admin.monhoc to gvu;
/
grant select on sec_admin.giaovien to gvu;
/
grant select on sec_admin.bomon to gvu;
/
grant select on sec_admin.sinhvien to gvu;
/
grant select on sec_admin.diem to gvu;
/
grant select on sec_admin.lop to svien;
/
grant select on sec_admin.monhoc to svien;
/

--Tao view cho giao vu va sinh vien xem danh sach cac mon hoc duoc mo
create or replace view monhocduocmo as
select tkb.malop, tkb.mamonhoc, mh.tenmonhoc, tkb.hocky, tkb.namhoc, tkb.phonghoc, gv.hoten_giaovien, mh.sotinchi, tkb.sosinhvientoida, count(d.mssv) as sosvhientai
from sec_admin.thoikhoabieu tkb join sec_admin.monhoc mh on mh.mamonhoc= tkb.mamonhoc join giaovien gv on tkb.giaoviengiangday = gv.magiaovien
                        left join sec_admin.diem d on (tkb.malop = d.malop and tkb.mamonhoc = d.mamonhoc and tkb.hocky = d.hocky and tkb.namhoc = d.namhoc)
group by tkb.malop, tkb.mamonhoc, mh.tenmonhoc, tkb.hocky, tkb.namhoc, tkb.phonghoc, gv.hoten_giaovien, mh.sotinchi, tkb.sosinhvientoida
order by tkb.malop, tkb.mamonhoc, tkb.hocky, tkb.namhoc asc;


grant select, insert, delete, update(phonghoc, giaoviengiangday, sosinhvientoida) on sec_admin.thoikhoabieu to gvu;
/
--user sec grant select with grant option cho user gvu
grant select on sec_admin.monhocduocmo to gvu_ntmthu with grant option

--user gvu grant select cho svien khi mo dang ky
--grant select on sec_admin.monhocduocmo to svien
--cai nay lam tren giao dien

--user gvu revoke select cua svien khi dong dang ky
--revoke select on sec_admin.monhocduocmo from svien
--cai nay lam tren giao dien




--Tao view cho giao vu va sinh vien xem danh sach dang ky mon hoc
create or replace view dangky as
select d.mssv, d.malop, d.mamonhoc, d.hocky, d.namhoc
from sec_admin.diem d
where d.diemgiuaky = null and d.diemcuoiky = null and d.diemkhac = null and d.diemtong = null;

--user sec grant select, insert, delete with grant option cho user gvu
grant select, insert, delete on sec_admin.dangky to gvu_ntmthu with grant option;
/

--user gvu grant select, insert, update tren dangky cho svien khi mo dang ky
--grant select, insert, delete on sec_admin.dangky to svien;
--cai nay lam tren giao dien

--user gvu revoke select, insert, update tren dangky cua svien khi dong dang ky
--revoke select, insert, delete on sec_admin.dangky from svien;
--cai nay lam tren giao dien


--Tao chinh sach sinh vien chi duoc xem, them, xoa cac dang ky cua chinh minh 
create or replace function sv_thaotac_dangky (p_schema varchar2, p_obj varchar2)
return  varchar2
as utype varchar2(32); return_val varcahr2(200);
begin
    select usertype into utype from sec_admin.taikhoan where username = user;
    
    if (utype = 'svien')
    then return_val := 'mssv = ' || user ||'';
    else return_val := '';
    end if;
    return return_val;
end;
/

BEGIN 
DBMS_RLS.add_policy 
(object_schema => 'sec_admin',
object_name => 'dangky',
policy_name => 'vpd_sv_thaotac_dangky',
policy_function => 'sv_thaotac_dangky',
statement_types => 'select, insert, delete',
update_check => true);
END;
/

BEGIN 
DBMS_RLS.drop_policy 
(object_schema => 'sec_admin',
object_name => 'dangky',
policy_name => 'vpd_sv_thaotac_dangky');
END;
/

