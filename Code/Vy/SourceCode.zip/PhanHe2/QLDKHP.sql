-- dang nhap duoi quyen sec_admin
alter session set "_ORACLE_SCRIPT"=true;
create user sec_mgr identified by sec_mgr
        default tablespace users
        TEMPORARY TABLESPACE temp
        Quota 10M on users;
        
grant create session , create user, create table ,
insert any table, update any table, select any table, 
alter any procedure, alter any table, create any procedure, 
create any table, create view, drop any procedure, drop any table, drop user, 
execute any procedure, create role, connect to sec_mgr with admin option;




--Sinhvien
delete sinhvien;
INSERT INTO sinhvien VALUES ('SV1', 'Nguyen Van A', '17CLC', '17 May,2010', 'Ho Chi Minh', 'Nam', '123456789', '123456789', null);
INSERT INTO sinhvien VALUES ('SV2', 'Nguyen Van B', '17CLC', '17 May,2010', 'Ho Chi Minh', 'Nam', '12345678', '12345678', null);

--Diem
delete diem;
INSERT INTO diem VALUES ('SV1', '17CLC', 'CSC1', 1, 2019, 9, 9, 9, 9);
INSERT INTO diem VALUES ('SV1', '17CLC', 'CSC2', 2, 2018, 9, 9, 9, 9);
INSERT INTO diem VALUES ('SV2', '17CLC', 'CSC1', 1, 2019, 8, 8, 9, 9);

grant select on sec_admin.diem to svien;
grant select on sec_admin.sinhvien to svien;
grant select on sec_admin.thoikhoabieu to svien;
grant select on sec_admin.monhoc to svien;

-- Tao view cho sinh vien chi duoc xem diem cua chinh minh
create or replace view xemthongtindiem as
select * from diem d
where d.mssv = sys_context('USERENV', 'SESSION_USER');
/
grant select on  sec_admin.xemthongtindiem to svien;
-- select * from SEC_ADMIN.xemthongtindiem;


-- dang nhap duoi quyen sec_mgr
--Tao chinh sach sinh vien chi duoc xem va chinh sua thong tin ca nhan cua minh.

create or replace function sv_xemchinhsua_thongtincanhan (p_schema varchar2, p_obj varchar2)
return  varchar2
as utype varchar2(32); 
    return_val varchar2(200);
begin
    select usertype into utype from sec_admin.taikhoan where username = user;
    
    if (utype = 'svien')
    then return_val := 'mssv = ' || user ||'';
    else return_val := '';
    end if;
    return return_val;
end;

begin
DBMS_RLS.add_policy 
(object_schema => 'sec_admin',
object_name => 'sinhvien',
policy_name => 'vpd_sv_xemchinhsua_thongtincanhan',
policy_function => 'sv_xemchinhsua_thongtincanhan',
statement_types => 'select, update',
update_check => true);
end;
