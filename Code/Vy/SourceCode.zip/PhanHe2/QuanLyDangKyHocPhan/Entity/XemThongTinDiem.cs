﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class XemThongTinDiem
    {
        public string MSSV { get; set; }
        public string MALOP { get; set; }
        public string MAMONHOC { get; set; }
        public string TENMONHOC { get; set; }
        public int HOCKY { get; set; }
        public string NAMHOC { get; set; }
        public string DIEMGIUAKY { get; set; }
        public string DIEMCUOIKY { get; set; }
        public string DIEMKHAC { get; set; }
        public string DIEMTONG { get; set; }
    }
}
