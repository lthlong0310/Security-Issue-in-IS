﻿namespace UI
{
    partial class ThongTinCaNhan_SV
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Birthday = new System.Windows.Forms.DateTimePicker();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.FemaleRBtn = new System.Windows.Forms.RadioButton();
            this.MaleRBtn = new System.Windows.Forms.RadioButton();
            this.DiaChiTextBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.SDTTextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.CMNDTextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.EmailTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.LopTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.HoTenTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.MSSVTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.EditBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Birthday
            // 
            this.Birthday.Location = new System.Drawing.Point(559, 70);
            this.Birthday.Name = "Birthday";
            this.Birthday.Size = new System.Drawing.Size(200, 22);
            this.Birthday.TabIndex = 74;
            // 
            // CancelBtn
            // 
            this.CancelBtn.Location = new System.Drawing.Point(808, 289);
            this.CancelBtn.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(180, 42);
            this.CancelBtn.TabIndex = 73;
            this.CancelBtn.Text = "Thoát";
            this.CancelBtn.UseVisualStyleBackColor = true;
            this.CancelBtn.Click += new System.EventHandler(this.CancelBtn_Click);
            // 
            // FemaleRBtn
            // 
            this.FemaleRBtn.AutoSize = true;
            this.FemaleRBtn.Location = new System.Drawing.Point(779, 119);
            this.FemaleRBtn.Name = "FemaleRBtn";
            this.FemaleRBtn.Size = new System.Drawing.Size(47, 21);
            this.FemaleRBtn.TabIndex = 72;
            this.FemaleRBtn.TabStop = true;
            this.FemaleRBtn.Text = "Nữ";
            this.FemaleRBtn.UseVisualStyleBackColor = true;
            // 
            // MaleRBtn
            // 
            this.MaleRBtn.AutoSize = true;
            this.MaleRBtn.Location = new System.Drawing.Point(559, 119);
            this.MaleRBtn.Name = "MaleRBtn";
            this.MaleRBtn.Size = new System.Drawing.Size(58, 21);
            this.MaleRBtn.TabIndex = 71;
            this.MaleRBtn.TabStop = true;
            this.MaleRBtn.Text = "Nam";
            this.MaleRBtn.UseVisualStyleBackColor = true;
            // 
            // DiaChiTextBox
            // 
            this.DiaChiTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DiaChiTextBox.Location = new System.Drawing.Point(95, 224);
            this.DiaChiTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.DiaChiTextBox.Name = "DiaChiTextBox";
            this.DiaChiTextBox.Size = new System.Drawing.Size(884, 30);
            this.DiaChiTextBox.TabIndex = 70;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(20, 231);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(61, 20);
            this.label9.TabIndex = 69;
            this.label9.Text = "Địa chỉ";
            // 
            // SDTTextBox
            // 
            this.SDTTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SDTTextBox.Location = new System.Drawing.Point(559, 172);
            this.SDTTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.SDTTextBox.Name = "SDTTextBox";
            this.SDTTextBox.Size = new System.Drawing.Size(420, 30);
            this.SDTTextBox.TabIndex = 68;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(496, 181);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(42, 20);
            this.label8.TabIndex = 67;
            this.label8.Text = "SĐT";
            // 
            // CMNDTextBox
            // 
            this.CMNDTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CMNDTextBox.Location = new System.Drawing.Point(95, 172);
            this.CMNDTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.CMNDTextBox.Name = "CMNDTextBox";
            this.CMNDTextBox.Size = new System.Drawing.Size(341, 30);
            this.CMNDTextBox.TabIndex = 66;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(11, 179);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 20);
            this.label7.TabIndex = 65;
            this.label7.Text = "CMND";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(467, 123);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 20);
            this.label6.TabIndex = 64;
            this.label6.Text = "Giới tính";
            // 
            // EmailTextBox
            // 
            this.EmailTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmailTextBox.Location = new System.Drawing.Point(95, 120);
            this.EmailTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.EmailTextBox.Name = "EmailTextBox";
            this.EmailTextBox.Size = new System.Drawing.Size(341, 30);
            this.EmailTextBox.TabIndex = 63;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(10, 127);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 20);
            this.label5.TabIndex = 62;
            this.label5.Text = "Email";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(455, 73);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 20);
            this.label4.TabIndex = 61;
            this.label4.Text = "Ngày sinh";
            // 
            // LopTextBox
            // 
            this.LopTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LopTextBox.Location = new System.Drawing.Point(95, 68);
            this.LopTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.LopTextBox.Name = "LopTextBox";
            this.LopTextBox.Size = new System.Drawing.Size(341, 30);
            this.LopTextBox.TabIndex = 60;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(34, 75);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 20);
            this.label3.TabIndex = 59;
            this.label3.Text = "Lớp";
            // 
            // HoTenTextBox
            // 
            this.HoTenTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HoTenTextBox.Location = new System.Drawing.Point(559, 16);
            this.HoTenTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.HoTenTextBox.Name = "HoTenTextBox";
            this.HoTenTextBox.Size = new System.Drawing.Size(420, 30);
            this.HoTenTextBox.TabIndex = 58;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(479, 23);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 20);
            this.label2.TabIndex = 57;
            this.label2.Text = "Họ tên";
            // 
            // MSSVTextBox
            // 
            this.MSSVTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MSSVTextBox.Location = new System.Drawing.Point(95, 16);
            this.MSSVTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.MSSVTextBox.Name = "MSSVTextBox";
            this.MSSVTextBox.Size = new System.Drawing.Size(341, 30);
            this.MSSVTextBox.TabIndex = 56;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 23);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 20);
            this.label1.TabIndex = 55;
            this.label1.Text = "MSSV";
            // 
            // EditBtn
            // 
            this.EditBtn.Location = new System.Drawing.Point(559, 289);
            this.EditBtn.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.EditBtn.Name = "EditBtn";
            this.EditBtn.Size = new System.Drawing.Size(180, 42);
            this.EditBtn.TabIndex = 54;
            this.EditBtn.Text = "Chỉnh sửa";
            this.EditBtn.UseVisualStyleBackColor = true;
            this.EditBtn.Click += new System.EventHandler(this.EditBtn_Click);
            // 
            // ThongTinCaNhan_SV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(999, 346);
            this.Controls.Add(this.Birthday);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(this.FemaleRBtn);
            this.Controls.Add(this.MaleRBtn);
            this.Controls.Add(this.DiaChiTextBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.SDTTextBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.CMNDTextBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.EmailTextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.LopTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.HoTenTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.MSSVTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.EditBtn);
            this.Name = "ThongTinCaNhan_SV";
            this.Text = "ThongTinCaNhan_SV";
            this.Load += new System.EventHandler(this.ThongTinCaNhan_SV_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker Birthday;
        private System.Windows.Forms.Button CancelBtn;
        private System.Windows.Forms.RadioButton FemaleRBtn;
        private System.Windows.Forms.RadioButton MaleRBtn;
        private System.Windows.Forms.TextBox DiaChiTextBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox SDTTextBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox CMNDTextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox EmailTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox LopTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox HoTenTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox MSSVTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button EditBtn;
    }
}