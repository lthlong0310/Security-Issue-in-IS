﻿using Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class ThongTinCaNhan_SV : Form
    {
        private User current_user;
        private BLL.BLL bll;
        private bool flag;
        public ThongTinCaNhan_SV(User current_user)
        {
            InitializeComponent();
            bll = new BLL.BLL();
            this.current_user = current_user;
            MSSVTextBox.Enabled = HoTenTextBox.Enabled = LopTextBox.Enabled
                = Birthday.Enabled = MaleRBtn.Enabled
                = FemaleRBtn.Enabled = CMNDTextBox.Enabled = false;
            flag = false;
        }

        private void ThongTinCaNhan_SV_Load(object sender, EventArgs e)
        {
            var sv = bll.LayThongTinSinhVien(current_user);
            MSSVTextBox.Text = sv.mssv;
            HoTenTextBox.Text = sv.hotensv;
            LopTextBox.Text = sv.lopsv;
            EmailTextBox.Text = sv.emailsv;
            CMNDTextBox.Text = sv.cmndsv;
            SDTTextBox.Text = sv.sdtsv;
            DiaChiTextBox.Text = sv.diachisv;
            Birthday.Value = DateTime.Parse(sv.dobsv);
            MaleRBtn.Checked = sv.gioitinhsv.ToLower().TrimEnd().Equals("nam") ? true : false;
            FemaleRBtn.Checked = !MaleRBtn.Checked;
            SetEnableTextBox(flag);
        }

        private void SetEnableTextBox(bool flag)
        {
            EmailTextBox.Enabled = SDTTextBox.Enabled
                = DiaChiTextBox.Enabled = flag;
        }

        private void EditBtn_Click(object sender, EventArgs e)
        {
            var btn = sender as Button;
            if (flag)
            {
                var sv = bll.ChinhSuaThongTinSinhVien(current_user, EmailTextBox.Text, SDTTextBox.Text, DiaChiTextBox.Text);
                btn.Text = "Chỉnh sửa";
                flag = !flag;
                SetEnableTextBox(flag);
                if (sv)
                {
                    MessageBox.Show("Chỉnh sửa thông tin thành công");
                }
                else
                {
                    MessageBox.Show("Có lỗi xảy ra vui lòng thử lại sau");
                }
            }
            else
            {
                btn.Text = "Xác nhận";
                flag = !flag;
                SetEnableTextBox(flag);
            }
        }

        private void CancelBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
