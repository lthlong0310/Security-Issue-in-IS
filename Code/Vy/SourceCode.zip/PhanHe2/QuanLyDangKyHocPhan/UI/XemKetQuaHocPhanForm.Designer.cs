﻿namespace UI
{
    partial class XemKetQuaHocPhanForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.namhoccb = new System.Windows.Forms.ComboBox();
            this.hockycb = new System.Windows.Forms.ComboBox();
            this.hockylb = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.kqhocphanlv = new System.Windows.Forms.ListView();
            this.XemDiemBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // namhoccb
            // 
            this.namhoccb.FormattingEnabled = true;
            this.namhoccb.Location = new System.Drawing.Point(432, 20);
            this.namhoccb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.namhoccb.Name = "namhoccb";
            this.namhoccb.Size = new System.Drawing.Size(236, 24);
            this.namhoccb.TabIndex = 0;
            // 
            // hockycb
            // 
            this.hockycb.FormattingEnabled = true;
            this.hockycb.Location = new System.Drawing.Point(137, 20);
            this.hockycb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.hockycb.Name = "hockycb";
            this.hockycb.Size = new System.Drawing.Size(86, 24);
            this.hockycb.TabIndex = 1;
            // 
            // hockylb
            // 
            this.hockylb.AutoSize = true;
            this.hockylb.Location = new System.Drawing.Point(74, 22);
            this.hockylb.Name = "hockylb";
            this.hockylb.Size = new System.Drawing.Size(59, 17);
            this.hockylb.TabIndex = 2;
            this.hockylb.Text = "Học kỳ: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(351, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Năm học:";
            // 
            // kqhocphanlv
            // 
            this.kqhocphanlv.HideSelection = false;
            this.kqhocphanlv.Location = new System.Drawing.Point(33, 59);
            this.kqhocphanlv.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.kqhocphanlv.Name = "kqhocphanlv";
            this.kqhocphanlv.Size = new System.Drawing.Size(650, 278);
            this.kqhocphanlv.TabIndex = 4;
            this.kqhocphanlv.UseCompatibleStateImageBehavior = false;
            // 
            // XemDiemBtn
            // 
            this.XemDiemBtn.Location = new System.Drawing.Point(574, 357);
            this.XemDiemBtn.Name = "XemDiemBtn";
            this.XemDiemBtn.Size = new System.Drawing.Size(109, 42);
            this.XemDiemBtn.TabIndex = 5;
            this.XemDiemBtn.Text = "Xem Điểm";
            this.XemDiemBtn.UseVisualStyleBackColor = true;
            this.XemDiemBtn.Click += new System.EventHandler(this.XemDiemBtn_Click);
            // 
            // XemKetQuaHocPhanForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(709, 411);
            this.Controls.Add(this.XemDiemBtn);
            this.Controls.Add(this.kqhocphanlv);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.hockylb);
            this.Controls.Add(this.hockycb);
            this.Controls.Add(this.namhoccb);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "XemKetQuaHocPhanForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "XemKetQuaHocPhanForm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.XemKetQuaHocPhanForm_FormClosing);
            this.Load += new System.EventHandler(this.XemKetQuaHocPhanForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox namhoccb;
        private System.Windows.Forms.ComboBox hockycb;
        private System.Windows.Forms.Label hockylb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView kqhocphanlv;
        private System.Windows.Forms.Button XemDiemBtn;
    }
}