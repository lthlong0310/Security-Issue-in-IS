﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entity
{
    public class Lop
    {
        public String malop { get; set; }
        public String tenlop { get; set; }

        public Lop (String ma, String ten)
        {
            malop = ma;
            tenlop = ten;
        }

    }
}
